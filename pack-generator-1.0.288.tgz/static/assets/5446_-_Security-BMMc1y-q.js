var e=[{_time:1653060999,cribl_breaker:`Break on newlines`,_raw:`05/20/2022 10:36:39 AM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=5446\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
TaskCategory=Filtering Platform Policy Change\r
OpCode=Info\r
RecordNumber=12356318\r
Keywords=Audit Success\r
Message=A Windows Filtering Platform callout has been changed.\r\r
	\r\r
Subject:\r\r
	Security ID:		NT AUTHORITY\\SYSTEM\r\r
	Account Name:		NT AUTHORITY\\SYSTEM\r\r
\r\r
Process Information:\r\r
	Process ID:	4\r\r
\r\r
Provider Information:\r\r
	ID:		{3AE7A917-2CB2-12B4-12BE-5AB05B9FE98D}\r\r
	Name:		TrendMicro EagleEye Provider\r\r
\r\r
Change Information:\r\r
	Change Type:	Add\r\r
\r\r
Callout Information:\r\r
	ID:		{4FE00F12-121C-48F4-1234-136E4D0D2FA3}\r\r
	Name:		TMEE_CALLOUT_DATAGRAMDATA_V6\r\r
	Type:		Persistent\r\r
	Run-Time ID:	123\r\r
\r\r
Layer Information:\r\r
	ID:		{FA45FE2F-3CBA-4412-87FC-57B9A4B12D00}\r\r
	Name:		Datagram Data v6 Layer\r\r
	Run-Time ID:	26`}];export{e as default};