var e=[{_raw:`dn: CN=Administrator,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: Administrator
description: Built-in account for administering the computer/domain
distinguishedName: CN=Administrator,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029173922.0Z
whenChanged: 20251029180720.0Z
uSNCreated: 8196
memberOf: CN=Group Policy Creator Owners,CN=Users,DC=MCG,DC=local
memberOf: CN=Domain Admins,CN=Users,DC=MCG,DC=local
memberOf: CN=Enterprise Admins,CN=Users,DC=MCG,DC=local
memberOf: CN=Schema Admins,CN=Users,DC=MCG,DC=local
memberOf: CN=Administrators,CN=Builtin,DC=MCG,DC=local
uSNChanged: 16525
name: Administrator
objectGUID:: NomCOp30DEqRRsAW3CHuSQ==
userAccountControl: 66048
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 134062414909195955
lastLogoff: 0
lastLogon: 134063108281687276
pwdLastSet: 134062312245622642
primaryGroupID: 513
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwT9AEAAA==
adminCount: 1
accountExpires: 9223372036854775807
logonCount: 9
sAMAccountName: Administrator
sAMAccountType: 805306368
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
isCriticalSystemObject: TRUE
dSCorePropagationData: 20251029180720.0Z
dSCorePropagationData: 20251029180720.0Z
dSCorePropagationData: 20251029174017.0Z
dSCorePropagationData: 16010101181216.0Z
lastLogonTimestamp: 134062333239513113
`,_time:1761874411.096,cribl_breaker:`LDIF`},{_raw:`dn: CN=Guest,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: Guest
description: Built-in account for guest access to the computer/domain
distinguishedName: CN=Guest,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029173922.0Z
whenChanged: 20251029173922.0Z
uSNCreated: 8197
memberOf: CN=Guests,CN=Builtin,DC=MCG,DC=local
uSNChanged: 8197
name: Guest
objectGUID:: yhW1CEBql0qivRrk8iopMg==
userAccountControl: 66082
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 0
lastLogoff: 0
lastLogon: 0
pwdLastSet: 0
primaryGroupID: 514
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwT9QEAAA==
accountExpires: 9223372036854775807
logonCount: 0
sAMAccountName: Guest
sAMAccountType: 805306368
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
isCriticalSystemObject: TRUE
dSCorePropagationData: 20251029174017.0Z
dSCorePropagationData: 16010101000001.0Z
`,_time:1761874411.096,cribl_breaker:`LDIF`},{_raw:`dn: CN=krbtgt,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: krbtgt
description: Key Distribution Center Service Account
distinguishedName: CN=krbtgt,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029174016.0Z
whenChanged: 20251029180720.0Z
uSNCreated: 12324
memberOf: CN=Denied RODC Password Replication Group,CN=Users,DC=MCG,DC=local
uSNChanged: 16543
showInAdvancedViewOnly: TRUE
name: krbtgt
objectGUID:: wc4BVgIHCUiaEXq76j3fOQ==
userAccountControl: 514
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 0
lastLogoff: 0
lastLogon: 0
pwdLastSet: 134062332166278412
primaryGroupID: 513
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwT9gEAAA==
adminCount: 1
accountExpires: 9223372036854775807
logonCount: 0
sAMAccountName: krbtgt
sAMAccountType: 805306368
servicePrincipalName: kadmin/changepw
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
isCriticalSystemObject: TRUE
dSCorePropagationData: 20251029180720.0Z
dSCorePropagationData: 20251029174017.0Z
dSCorePropagationData: 16010101000416.0Z
msDS-SupportedEncryptionTypes: 0
`,_time:1761874411.096,cribl_breaker:`LDIF`},{_raw:`dn: CN=Moe Stooge,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: Moe Stooge
sn: Stooge
givenName: Moe
distinguishedName: CN=Moe Stooge,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029175902.0Z
whenChanged: 20251029175902.0Z
displayName: Moe Stooge
uSNCreated: 16484
uSNChanged: 16490
name: Moe Stooge
objectGUID:: 5MW3MvioBUmyHZbAYI+LzQ==
userAccountControl: 512
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 0
lastLogoff: 0
lastLogon: 0
pwdLastSet: 0
primaryGroupID: 513
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwTUAQAAA==
accountExpires: 9223372036854775807
logonCount: 0
sAMAccountName: moe
sAMAccountType: 805306368
userPrincipalName: moe@MCG.local
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
dSCorePropagationData: 16010101000000.0Z
`,_time:1761874411.096,cribl_breaker:`LDIF`},{_raw:`dn: CN=Larry Stooge,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: Larry Stooge
sn: Stooge
givenName: Larry
distinguishedName: CN=Larry Stooge,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029175925.0Z
whenChanged: 20251029175925.0Z
displayName: Larry Stooge
uSNCreated: 16492
uSNChanged: 16498
name: Larry Stooge
objectGUID:: IwdAyZyJCES5LQEUNtUhTw==
userAccountControl: 512
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 0
lastLogoff: 0
lastLogon: 0
pwdLastSet: 0
primaryGroupID: 513
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwTUQQAAA==
accountExpires: 9223372036854775807
logonCount: 0
sAMAccountName: larry
sAMAccountType: 805306368
userPrincipalName: larry@MCG.local
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
dSCorePropagationData: 16010101000000.0Z
`,_time:1761874411.096,cribl_breaker:`LDIF`},{_raw:`dn: CN=Curly Stooge,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: Curly Stooge
sn: Stooge
givenName: Curly
distinguishedName: CN=Curly Stooge,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029175950.0Z
whenChanged: 20251029175951.0Z
displayName: Curly Stooge
uSNCreated: 16500
uSNChanged: 16506
name: Curly Stooge
objectGUID:: DbXVtB0IgECuz67BDcH5Ig==
userAccountControl: 512
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 0
lastLogoff: 0
lastLogon: 0
pwdLastSet: 0
primaryGroupID: 513
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwTUgQAAA==
accountExpires: 9223372036854775807
logonCount: 0
sAMAccountName: curly
sAMAccountType: 805306368
userPrincipalName: curly@MCG.local
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
dSCorePropagationData: 16010101000000.0Z
`,_time:1761874411.096,cribl_breaker:`LDIF`},{_raw:`dn: CN=Michael Donnelly,CN=Users,DC=MCG,DC=local
objectClass: top
objectClass: person
objectClass: organizationalPerson
objectClass: user
cn: Michael Donnelly
sn: Donnelly
givenName: Michael
distinguishedName: CN=Michael Donnelly,CN=Users,DC=MCG,DC=local
instanceType: 4
whenCreated: 20251029180030.0Z
whenChanged: 20251029180720.0Z
displayName: Michael Donnelly
uSNCreated: 16508
memberOf: CN=Domain Admins,CN=Users,DC=MCG,DC=local
uSNChanged: 16528
name: Michael Donnelly
objectGUID:: dDvCuBv950es+LTbGfrLfg==
userAccountControl: 66048
badPwdCount: 0
codePage: 0
countryCode: 0
badPasswordTime: 134062346815597715
lastLogoff: 0
lastLogon: 134063183313618725
pwdLastSet: 134062344304671898
primaryGroupID: 513
objectSid:: AQUAAAAAAAUVAAAAS946lwmnh9LGdpwTUwQAAA==
adminCount: 1
accountExpires: 9223372036854775807
logonCount: 3
sAMAccountName: mdonnelly
sAMAccountType: 805306368
userPrincipalName: mdonnelly@MCG.local
objectCategory: CN=Person,CN=Schema,CN=Configuration,DC=MCG,DC=local
dSCorePropagationData: 20251029180720.0Z
dSCorePropagationData: 16010101000000.0Z
lastLogonTimestamp: 134062345160503529

`,_time:1761874411.096,cribl_breaker:`LDIF`}];export{e as default};