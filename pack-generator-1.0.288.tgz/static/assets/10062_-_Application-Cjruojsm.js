var e=[{_time:1653503685,cribl_breaker:`Break on newlines`,_raw:`05/26/2022 12:04:45 AM
LogName=Application
SourceName=Custom System Service
EventCode=10062
EventType=2
Type=Error
ComputerName=myhost.acme.com
TaskCategory=None
OpCode=Info
RecordNumber=1804388
Keywords=Classic
Message=The BarTender System Service failed an attempt to find information.\r
\r
Table: MessageLog, Command: SELECT [MessageEventID] FROM  dbo.MessageLog WITH (TABLOCKX,XLOCK)  WHERE [GUID] = '12fdd8e8-2f50-4fe5-aee4-8a59a65d25cd'; Inner Message: Execution Timeout Expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.; Inner Message: The wait operation timed out`}];export{e as default};