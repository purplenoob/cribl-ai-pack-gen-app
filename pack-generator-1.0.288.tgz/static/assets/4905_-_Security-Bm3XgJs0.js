var e=[{_time:1653578262,cribl_breaker:`Break on newlines`,_raw:`05/26/2022 08:47:42 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4905
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Audit Policy Change
OpCode=Info
RecordNumber=3599371
Keywords=Audit Success
Message=An attempt was made to unregister a security event source.\r
\r
Subject\r
	Security ID:		NT AUTHORITY\\SYSTEM\r
	Account Name:		SomeUser$\r
	Account Domain:		ACME\r
	Logon ID:		0x3E7\r
\r
Process:\r
	Process ID:	0x1070\r
	Process Name:	C:\\Windows\\System32\\VSSVC.exe\r
\r
Event Source:\r
	Source Name:	VSSAudit\r
	Event Source ID:	0x2C65C089`}];export{e as default};