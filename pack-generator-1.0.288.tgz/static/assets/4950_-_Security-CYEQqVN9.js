var e=[{_time:1665770616,cribl_breaker:`Break on newlines`,_raw:`10/14/2022 11:33:36 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4950
EventType=0
Type=Information
ComputerName=myhost
TaskCategory=MPSSVC Rule-Level Policy Change
OpCode=Info
RecordNumber=1234609445
Keywords=Audit Success
Message=A Windows Firewall setting was changed.\r
	\r
Changed Profile:	Public\r
\r
New Setting:\r
	Type:	Maximum Log File Size\r
	Value:	4096`}];export{e as default};