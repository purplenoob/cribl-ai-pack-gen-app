var e=[{_time:1653682830,cribl_breaker:`Break on newlines`,_raw:`05/28/2022 01:50:30 AM
LogName=Application
SourceName=ABCDE
EventCode=54432
EventType=3
Type=Warning
ComputerName=myhost.acme.com
TaskCategory=%1
OpCode=Info
RecordNumber=8755297
Keywords=Classic
Message=System Processing Warning: Processing warning occurred.\r
File Definition: '812 The Text Memo - Public'...Inactive.`}];export{e as default};