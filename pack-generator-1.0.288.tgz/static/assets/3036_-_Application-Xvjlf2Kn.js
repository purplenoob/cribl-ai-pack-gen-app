var e=[{_time:1653735731,cribl_breaker:`Break on newlines`,_raw:`05/28/2022 04:32:11 PM
LogName=Application
SourceName=Microsoft-Windows-Search
EventCode=3036
EventType=3
Type=Warning
ComputerName=myhost.acme.com
TaskCategory=Gatherer
OpCode=NOTE:  This dummy error message is necessary to force MC to output        the above defines inside the FACILITY_WINDOWS guard instead        of leaving it empty.
RecordNumber=19369757
Keywords=Classic
Message=Crawl could not be completed on content source <winrt://{S-1-5-21-2184843080-1234357790-3623606500-253054}/>.

Context:  Application, SystemIndex Catalog

Details:
	The parameter is incorrect.  (HRESULT : 0x80070057) (0x80070057)`}];export{e as default};