var e=[{_time:1653545364,cribl_breaker:`Break on newlines`,_raw:`05/26/2022 11:39:24 AM
LogName=System
SourceName=User32
EventCode=1076
EventType=3
Type=Warning
ComputerName=myhost.acme.com
User=NOT_TRANSLATED
Sid=S-1-5-21-2184843080-1234357790-3623606500-382023
SidType=0
TaskCategory=None
OpCode=The operation completed successfully.
RecordNumber=1323185
Keywords=Classic
Message=The reason supplied by user ACME\\a0001234 for the last unexpected shutdown of this computer is: Other (Unplanned)\r
 Reason Code: 0xa000000\r
 Problem ID: \r
 Bugcheck String: \r
 Comment:`}];export{e as default};