var e=[{_time:1665815380,cribl_breaker:`Break on newlines`,_raw:`10/15/2022 11:59:40 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5144
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=File Share
OpCode=Info
RecordNumber=141777657
Keywords=Audit Success
Message=A network share object was deleted.\r
	\r
Subject:\r
	Security ID:		NT AUTHORITY\\SYSTEM\r
	Account Name:		SomeName$\r
	Account Domain:		ACME\r
	Logon ID:		0x3E7\r
\r
Share Information:	\r
	Share Name:		\\\\*\\SomeShare\r
	Share Path:		SomePath,LocalsplOnly`}];export{e as default};