var e=[{_time:1661886167,cribl_breaker:`Break on newlines`,_raw:`08/30/2022 12:02:47 PM\r
LogName=Security\r
SourceName=AD FS Auditing\r
EventCode=410\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
User=NOT_TRANSLATED\r
Sid=S-1-5-21-359538278-52765162-1231038576-184163\r
SidType=0\r
TaskCategory=Printers\r
OpCode=Info\r
RecordNumber=68106996\r
Keywords=Audit Success, Classic\r
Message=Following request context headers present : \r\r
\r\r
Activity ID: 99b98444-b933-1232-311d-0080011000d4  \r\r
\r\r
X-MS-Client-Application: - \r\r
X-MS-Client-User-Agent: - \r\r
client-request-id: - \r\r
X-MS-Endpoint-Absolute-Path: /adfs/oauth2/token \r\r
X-MS-Forwarded-Client-IP: - \r\r
X-MS-Proxy: - \r\r
X-MS-ADFS-Proxy-Client-IP: -`,source:`WinEventLog:Security`,host:`myhost.acme.com`,sourcetype:`WinEventLog:Security`,index:`wineventlog`}];export{e as default};