var e=[{_time:1657804826,cribl_breaker:`Break on newlines`,_raw:`07/14/2022 06:50:26 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5889
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=System Integrity
OpCode=Info
RecordNumber=1237373
Keywords=Audit Success
Message=An object was deleted from the COM+ Catalog.\r
\r
Subject:\r
	Security ID:		NT AUTHORITY\\SYSTEM\r
	Account Name:		SYSTEM\r
	Account Domain:		NT AUTHORITY\r
	Logon ID:		0x1E7\r
\r
Object:\r
	COM+ Catalog Collection:	Applications\r
	Object Name:			\r
		ID = {12D97E10-23C9-4E2A-87BC-AD6D7EBF4B38}\r
		AppPartitionID = {41E90F3E-56C1-1234-81C3-6E8BAC8BDD70}\r
	Object Details:			\r
		Name = VMware Snapshot Provider\r
		ApplicationProxyServerName = \r
		ProcessType = 2\r
		CommandLine = \r
		ServiceName = vmvss\r
		RunAsUserType = 1\r
		Identity = LocalSystem\r
		Description = VMware Snapshot Provider\r
		IsSystem = N\r
		Authentication = 6\r
		ShutdownAfter = 3\r
		RunForever = N\r
		Password = ********\r
		Activation = Local\r
		Changeable = Y\r
		Deleteable = Y\r
		CreatedBy = \r
		AccessChecksLevel = 1\r
		ApplicationAccessChecksEnabled = 0\r
		cCOL_SecurityDescriptor = <Opaque>\r
		ImpersonationLevel = 2\r
		AuthenticationCapability = 2\r
		CRMEnabled = 0\r
		3GigSupportEnabled = 0\r
		QueuingEnabled = 0\r
		QueueListenerEnabled = N\r
		EventsEnabled = 1\r
		ProcessFlags = 0\r
		ThreadMax = 0\r
		ApplicationProxy = 0\r
		CRMLogFile = \r
		DumpEnabled = 0\r
		DumpOnException = 0\r
		DumpOnFailfast = 0\r
		MaxDumpCount = 5\r
		DumpPath = %systemroot%\\system32\\com\\dmp\r
		IsEnabled = 1\r
		AppPartitionID = {12E90F3E-56C1-1234-81C3-6E8BAC8BDD70}\r
		ConcurrentApps = 1\r
		RecycleLifetimeLimit = 0\r
		RecycleCallLimit = 0\r
		RecycleActivationLimit = 0\r
		RecycleMemoryLimit = 0\r
		RecycleExpirationTimeout = 15\r
		QCListenerMaxThreads = 0\r
		QCAuthenticateMsgs = 0\r
		ApplicationDirectory = \r
		SRPTrustLevel = 123144\r
		SRPEnabled = 0\r
		SoapActivated = 0\r
		SoapVRoot = \r
		SoapMailTo = \r
		SoapBaseUrl = \r
		Replicable = 1\r
This event occurs when an object is deleted from the COM+ catalog.`}];export{e as default};