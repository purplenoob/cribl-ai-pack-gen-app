import{cn as e,i as t,l as n,n as r,u as i}from"./sanitizer-core-B4Yw9UF_.js";import{on as a,un as o}from"./ai-core-u7201jQQ.js";import{a as s}from"./main-DmEZ-wKX.js";import c from"./golden-pipelines-CImx-sz6.js";import{t as l}from"./samples-pool-index-GxD56PE8.js";function u(){let t=i.global||{},u=l.samples||[],d=c.pipelines||{},f=Object.keys(d).filter(e=>!e.startsWith(`_`)),p=0,m=0,h=0,g=new Set,_=new Set;for(let e of f){e.includes(`__extraction__`)?p++:e.includes(`__mapping__`)?m++:h++;let t=e.split(`::`);t[0]&&g.add(s(t[0])),t[1]&&!t[1].startsWith(`__`)&&_.add(t[1])}let v=e.parsers||{},y=Array.isArray(v)?v:Object.values(v),b=0,x=0,S=0;for(let e of y){let t=e&&e.dataFormat||``;t===`raw`?b++:t===`delimited`?x++:t===`kvp`&&S++}let C=o.formats||{},w=Object.keys(C),T=new Set,E=0,D=0;for(let e of w)T.add(e.split(`#`)[0]),e.startsWith(`asim#`)&&E++,e.startsWith(`ocsf#`)&&D++;return{goldenTotal:f.length,goldenFull:h,goldenExtraction:p,goldenMapping:m,goldenSourcetypes:g.size,goldenFormats:_.size,searchParsers:y.length,searchRaw:b,searchDelimited:x,searchKvp:S,formatSpecs:w.length,formatFamilies:T.size,asimSchemas:E,ocsfClasses:D,sourceSamples:Object.keys(a).length,vendorSamples:u.length,vendorVerified:u.filter(e=>e.confidence===`verified`).length,vendorAtFloor:u.filter(e=>(e.events||0)>=10).length,vendorMerged:u.filter(e=>(e.fixtures||1)>1).length,vendorEvents:u.reduce((e,t)=>e+(t.events||0),0),secretFields:(t.secretFields||[]).length,piiFields:(t.piiFields||[]).length,suspectFields:(t.suspectFields||[]).length,vocabularyFields:(t.neverReplaceFields||[]).length,secretRules:n(r.items||[]).rules.length,secretRulesTotal:(r.items||[]).length}}var d=u(),f=884,p=`<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pack Generator — Onboarding &amp; Scoring Reference</title>
<style>
  :root{--teal:#00b8b8;--teal-d:#006d6d;--ink:#1a1a2e;--grey:#4b5563;--mut:#8c94a0;--line:#e6e9ee;--bg:#f5f7fa;--ok:#237804;--warn:#d48806;--fail:#cf1322}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',-apple-system,BlinkMacSystemFont,sans-serif;color:var(--ink);background:var(--bg);line-height:1.55;padding:26px}
  .page{max-width:920px;margin:0 auto;background:#fff;border:1px solid var(--line);border-radius:16px;padding:32px 40px;box-shadow:0 4px 24px rgba(0,0,0,.05)}
  header{display:flex;align-items:center;gap:14px;border-bottom:2px solid var(--teal);padding-bottom:16px;margin-bottom:8px}
  h1{font-size:23px;font-weight:800}h1 span{color:var(--teal-d)}
  .sub{font-size:12.5px;color:var(--grey);margin-top:3px}
  .badge{margin-left:auto;background:linear-gradient(135deg,var(--teal),#0095a8);color:#fff;font-size:11px;font-weight:700;letter-spacing:.4px;text-transform:uppercase;padding:7px 13px;border-radius:20px}
  .toc{background:#fbfdfe;border:1px solid var(--line);border-radius:12px;padding:14px 18px;margin:18px 0 4px}
  .toc b{font-size:11px;letter-spacing:.5px;text-transform:uppercase;color:var(--mut)}
  .toc ol{margin:8px 0 0 20px}
  .toc li{font-size:13px;color:var(--teal-d);font-weight:600;margin-bottom:3px}
  .toc a{color:inherit;text-decoration:none;border-bottom:1px solid transparent}
  .toc a:hover,.toc a:focus{border-bottom-color:var(--teal);color:var(--teal)}
  .toc .fmts{list-style:none;margin:4px 0 6px 0;display:flex;flex-wrap:wrap;gap:5px}
  .toc .fmts li{margin:0;font-size:11px;font-weight:700}
  .toc .fmts a{display:inline-block;background:#f0fbfc;border:1px solid #cdeef0;border-radius:20px;padding:2px 9px}
  .toc .fmts a:hover{background:var(--teal);color:#fff;border-color:var(--teal)}
  .tools{display:none;gap:8px;margin-left:auto;align-items:center}
  .tools button{font-family:inherit;font-size:11.5px;font-weight:700;color:var(--teal-d);background:#fff;border:1px solid var(--teal);border-radius:20px;padding:6px 13px;cursor:pointer}
  .tools button:hover{background:var(--teal);color:#fff}
  .totop{position:fixed;right:18px;bottom:18px;background:var(--teal-d);color:#fff;text-decoration:none;font-size:11.5px;font-weight:700;padding:8px 13px;border-radius:20px;box-shadow:0 2px 10px rgba(0,0,0,.18);opacity:.85}
  .totop:hover{opacity:1}
  html{scroll-behavior:smooth}
  .chap{margin-top:34px;padding-top:6px;scroll-margin-top:14px}
  h2,h3{scroll-margin-top:14px}
  .chap-h{display:flex;align-items:center;gap:12px;border-bottom:2px solid var(--line);padding-bottom:10px;margin-bottom:14px}
  .chap-n{flex:0 0 auto;width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,var(--teal),#0095a8);color:#fff;font-size:17px;font-weight:800;display:flex;align-items:center;justify-content:center}
  .chap-t{font-size:18px;font-weight:800}
  h2{font-size:15px;font-weight:800;margin:24px 0 11px;display:flex;align-items:center;gap:9px}
  h2 .d{width:9px;height:9px;border-radius:50%;background:var(--teal)}
  h3{font-size:13px;font-weight:800;color:var(--teal-d);margin:16px 0 6px}
  p{font-size:13px;color:var(--grey);margin-bottom:10px}
  ul,ol.steps{margin:0 0 12px 20px}
  li{font-size:12.5px;color:var(--grey);margin-bottom:5px}
  code{background:#f0f3f6;border-radius:4px;padding:1px 5px;font-family:ui-monospace,Menlo,monospace;font-size:11.5px;color:var(--teal-d)}
  .formula{background:var(--ink);color:#d4f5d4;border-radius:8px;padding:12px 16px;font-family:ui-monospace,Menlo,monospace;font-size:13px;margin:8px 0 14px;overflow-x:auto}
  .stages{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:6px 0 4px}
  .stage{border:1px solid var(--line);border-radius:12px;overflow:hidden}
  .stage .sh{color:#fff;font-size:13px;font-weight:800;padding:9px 12px}
  .stage.ex .sh{background:#0095a8}.stage.mp .sh{background:#531dab}.stage.op .sh{background:#237804}
  .stage .sb{padding:11px 13px;font-size:11.5px;color:var(--grey)}
  .stage .sb b{color:var(--ink)}
  .flow{display:flex;align-items:stretch;gap:0;margin:10px 0 16px;flex-wrap:wrap}
  .flow .step{flex:1 1 0;min-width:120px;border:1px solid var(--line);border-radius:10px;padding:10px 12px;position:relative;background:#fbfdfe}
  .flow .step .rank{font-size:10px;font-weight:800;color:var(--mut);letter-spacing:.5px}
  .flow .step .nm{font-size:13px;font-weight:800;color:var(--ink);margin:2px 0 3px}
  .flow .step .ds{font-size:11px;color:var(--grey)}
  .flow .arr{align-self:center;color:var(--mut);font-size:18px;padding:0 6px;font-weight:800}
  .bands{display:flex;gap:8px;margin:6px 0 14px;flex-wrap:wrap}
  .band{border-radius:20px;padding:4px 12px;font-size:11.5px;font-weight:700}
  .band.g{background:#f6ffed;color:var(--ok);border:1px solid #b7eb8f}
  .band.w{background:#fffbe6;color:var(--warn);border:1px solid #ffe58f}
  .band.f{background:#fff1f0;color:var(--fail);border:1px solid #ffccc7}
  .note{border:1px solid #ffe08a;background:#fffbe6;border-radius:12px;padding:13px 16px;font-size:12.5px;color:#6a5200;margin:12px 0}
  .note b{color:#8a6d00}
  table{width:100%;border-collapse:collapse;margin:8px 0 14px;font-size:12px}
  th,td{border:1px solid var(--line);padding:7px 10px;text-align:left}
  th{background:#fbfdfe;color:var(--teal-d);font-weight:700}
  .stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:10px 0 18px}
  .stat{border:1px solid var(--line);border-radius:12px;padding:14px 16px;text-align:center;background:linear-gradient(180deg,#fbfdfe,#fff)}
  .stat .n{font-size:30px;font-weight:800;color:var(--teal-d);line-height:1}
  .stat .l{font-size:11px;color:var(--grey);margin-top:6px;font-weight:600}
  .stat .s{font-size:10px;color:var(--mut);margin-top:2px}
  footer{margin-top:30px;padding-top:14px;border-top:1px solid var(--line);font-size:11px;color:#9aa2ad}
  @media print{body{background:#fff;padding:0}.page{border:0;box-shadow:none}h2,.stages,.note,table,.chap,.flow,.stat-grid{break-inside:avoid}.tools,.totop{display:none!important}}
  @media(max-width:720px){.stages,.stat-grid{grid-template-columns:1fr 1fr}.flow{flex-direction:column}.flow .arr{transform:rotate(90deg)}}
</style></head><body>
<div class="page">
  <header>
    <div>
      <h1>Pack Generator — <span>Onboarding &amp; Scoring Reference</span></h1>
      <div class="sub">How a new source is turned into a scored, deployable pipeline — and how every number is calculated.</div>
    </div>
    <div class="tools" id="tools">
      <button type="button" id="dl">⤓ Download</button>
      <button type="button" id="pr">🖨 Print / PDF</button>
    </div>
    <div class="badge">Reference</div>
  </header>

  <div class="toc" id="contents">
    <b>Contents</b>
    <ol>
      <li><a href="#ch1">Onboarding a new source — extraction, mapping &amp; output shaping (incl. first-time approach)</a></li>
      <li><a href="#ch2">Sourcetype recognition — the tier ladder, statuses, hints &amp; interactive search</a></li>
      <li><a href="#ch3">Where the sample comes from — real logs first, verification &amp; request-time extension</a></li>
      <li><a href="#ch4">Sanitising the sample — local pseudonymisation before any sample text reaches a model</a></li>
      <li><a href="#ch5">The resolution sequence — golden → Search → schematizer → AI</a></li>
      <li><a href="#ch6">Extraction &amp; mapping — the canonical field model, how fields are pulled &amp; projected, and <b>every export format tile by tile</b></a>
        <ul class="fmts">
          <li><a href="#fmt-nextgen">CrowdStrike NG SIEM</a></li>
          <li><a href="#fmt-ocsf">OCSF 1.9</a></li>
          <li><a href="#fmt-cef">CEF</a></li>
          <li><a href="#fmt-sentinel">Sentinel</a></li>
          <li><a href="#fmt-cim">Splunk CIM</a></li>
          <li><a href="#fmt-ecs">Elastic ECS</a></li>
          <li><a href="#fmt-asim">ASIM</a></li>
          <li><a href="#fmt-chronicle">Chronicle UDM</a></li>
          <li><a href="#fmt-xsiam">Cortex XSIAM</a></li>
          <li><a href="#fmt-passthrough">Passthrough (raw copy)</a></li>
          <li><a href="#fmt-json">Clean JSON</a></li>
        </ul>
      </li>
      <li><a href="#ch7">How scoring works — value coverage, stage checks &amp; the deployment score</a></li>
      <li><a href="#ch8">Knowledge-base stats — how many goldens, Search parsers, real samples &amp; format specs</a></li>
    </ol>
  </div>

  <!-- ============================ CHAPTER 1 ============================ -->
  <section class="chap" id="ch1">
    <div class="chap-h"><div class="chap-n">1</div><div class="chap-t">Onboarding a new source</div></div>
    <p>A pack is built in <b>three sequential stages</b>. Each does one job, and each is scored on that job alone so a weak stage can't hide behind a strong one.</p>
    <div class="stages">
      <div class="stage ex"><div class="sh">1 · Extraction</div><div class="sb"><b>Pull the values out of <code>_raw</code>.</b> Turns the raw log line into named fields (<code>src_ip</code>, <code>query_name</code>, <code>event_code</code>…) using a serde, a regex chain, or a stock parser.</div></div>
      <div class="stage mp"><div class="sh">2 · Mapping</div><div class="sb"><b>Land those fields in the destination schema.</b> Renames/re-shapes the extracted fields into OCSF, CIM, ECS, ASIM, CEF, Sentinel, Chronicle… and sets <code>_time</code>, severity, class ids.</div></div>
      <div class="stage op"><div class="sh">3 · Output shaping</div><div class="sb"><b>Enforce the destination envelope.</b> Compacts the payload and strips scratch (<code>__</code>) fields while protecting everything the mapping produced. Optional event suppression is not applied here.</div></div>
    </div>

    <h2><span class="d"></span>First time the app sees a source</h2>
    <p>The goal is to get the <b>first</b> pack right — not a weak draft that only the second pass fixes. When a sourcetype is <b>unknown or mislabeled</b> (no stored golden, no built-in parser), the app does not jump straight to the AI. It reads the <b>actual sample content</b> first:</p>
    <ol class="steps">
      <li><b>Schema class from the sample, not the name.</b> The destination schema variant (which OCSF class, which CIM data model, which ASim schema) is chosen from what the sample <i>contains</i> (<code>effectiveDataClass</code> → <code>inferDataClass</code>), not from the sourcetype string. An unknown source with DNS-shaped data lands on the DNS class on pass one; a correctly-labeled source is only flipped when the sample <i>overwhelmingly</i> disagrees — a higher confidence bar plus <b>two distinct signals</b> for the winning class, counted as signals rather than summed weight. One strong-but-incidental field can no longer decide it: a firewall's URL-filtering lines carry <code>url</code>, and that alone used to build OCSF HTTP Activity for a Cisco eStreamer connection event. Real HTTP evidence (a request target <i>and</i> client hints) still flips it.</li>
      <li><b>Extraction matched by shape.</b> Before falling back to AI, the app runs every Cribl <b>Search stock parser</b> against the real sample lines (<code>matchDatatypeParserBySample</code>) and keeps the best match by <i>content richness</i> + match-rate. A generic syslog envelope (<code>&lt;pri&gt; time host app …</code>) is explicitly rejected — it only counts a match if the parser pulls out <b>real content</b> fields, so a wrong parser can't win on the wrapper alone. That includes the whole RFC 5424 header and its structured-data wrapper (version, MSGID, <code>[id@enterprise …]</code>), which every RFC 5424 sender fills: a bare RFC 5424 parser used to claim Juniper structured syslog and Meraki as Infoblox at 100%. When a parser reads its content in a second step (NSX's firewall body, Infoblox's CEF payload), the matcher follows that chain and counts what it extracts. A parser for a format many sources share must also see the source's own token in the sample — the MSWinEventLog DHCP parser fits every Windows event forwarded that way, so it needs <code>DHCP</code>; Proofpoint TAP is recognised by its <code>tapmsg@21139</code> structured-data ID.</li>
      <li><b>AI only as the last resort.</b> If neither a golden, a built-in parser, nor a shape-matched stock parser fits, the LLM generates the stage. Its output is sanitized (single-expression eval, valid accessor field names) and then scored like any other candidate.</li>
    </ol>
    <div class="note"><b>Why this matters.</b> A never-before-seen sourcetype now gets its extraction and schema class from the <i>data itself</i> — deterministically, with no AI round-trip — so the first deployed pack is already correct instead of being a draft that needs a second repair pass.</div>
  </section>

  <!-- ============================ CHAPTER 2 ============================ -->
  <section class="chap" id="ch2">
    <div class="chap-h"><div class="chap-n">2</div><div class="chap-t">Sourcetype recognition</div></div>
    <p>Before anything is built, the app has to answer <b>“what is this source?”</b> from nothing but the label the customer gave it (<code>XmlWinEventLog:Security</code>, <code>pan_traffic</code>, <code>oraaudit_too_small</code>, <code>web03_nginx</code>…). Recognition (<i>what is it</i>) is deliberately kept <b>separate from buildability</b> (<i>do we have a golden for it</i>): a source can be fully recognized and still have no golden — it just builds via AI on its own name. Only a truly <b>unresolved</b> label blocks a batch row.</p>

    <h2><span class="d"></span>Five recognition statuses</h2>
    <table>
      <tr><th>Status</th><th>Meaning</th><th>Effect</th></tr>
      <tr><td><b>exact</b></td><td>The name is a canonical we build deterministically</td><td>✅ green — builds now</td></tr>
      <tr><td><b>alias</b></td><td>A known shorthand/vendor variant that maps to a canonical (<code>pan_traffic</code> → <code>palo_alto_traffic</code>)</td><td>✅ green — builds as the canonical</td></tr>
      <tr><td><b>catalogue_gap</b></td><td>Vendor / product / log-family identified (via a curated hint or an AI real-source confirmation) but no golden exists</td><td>🟠 amber — builds via AI on its own name, never force-mapped</td></tr>
      <tr><td><b>needs_confirmation</b></td><td>A fuzzy near-match; likely a typo of a known source</td><td>🟡 editable, pre-filled — non-blocking</td></tr>
      <tr><td><b>unresolved</b></td><td>No defensible candidate at all</td><td>🔴 the ONLY status that blocks the build</td></tr>
    </table>
    <div class="note"><b>Recognized ≠ buildable golden.</b> A named source only "resolves" if we can build it deterministically (a parser / stock datatype / data-class) <i>or</i> we ship a real sample for it. Everything else is either identified-by-hint (amber, AI-built) or left unresolved — the app never invents a canonical or force-maps a label to the wrong parser.</div>

    <h2><span class="d"></span>The tier ladder (cheapest first)</h2>
    <p>The recognizer tries a sequence of <b>deterministic, offline</b> tiers and stops at the first that yields a <i>known</i> hit. Each tier normalizes the label a little more, so real sources buried under prefixes, rotation counters, format suffixes and CamelCase all still resolve — without an AI call.</p>
    <ol class="steps">
      <li><b>Namespace / host-prefix strip.</b> A leading collector/tenant namespace (<code>ncsc:</code>, <code>custom::</code>) or a host-role token (<code>web03_</code>, <code>srv12_</code>, <code>vm2_</code>) is not a product — strip it and resolve the remainder.</li>
      <li><b>Exact / alias.</b> The name (or its alias remap) is a canonical we build. <code>SOURCETYPE_ALIASES</code> maps the many real-world spellings of a source (FortiGate traffic/utm/event, all the Windows <code>XmlWinEventLog:*</code> channels, Zscaler NSS variants…) onto one canonical.</li>
      <li><b>Rotation / size-marker strip.</b> <code>messages-45</code>, <code>cron-8</code>, <code>ssl_error_log-2</code>, <code>*-too_small</code> all collapse to their base — a rotated file is the same source as its base (accepted only if the base is known).</li>
      <li><b>Format / transport suffix strip.</b> <code>f5_bigip_syslog</code> → <code>f5_bigip</code> — remove a trailing transport token to reveal the real product (deterministic hits only).</li>
      <li><b>Squashed / CamelCase form.</b> A concatenated pipeline-name spelling (<code>XmlWinEventLogMicrosoftWindowsSysmonOperational_CIM</code>) carries the right tokens but no separators — squash both sides to their separator-free token form and take an exact hit, so it resolves to <code>windows_sysmon</code> instead of falling to slow AI on huge XML.</li>
      <li><b>Recognition hint (catalogue_gap).</b> A curated table (<code>RECOGNITION_HINTS</code>) of real vendor products we have no golden for — matched on the <i>normalized</i> token set (so <code>McAfee</code>→<code>mcafee</code>, F5→<code>bigip</code>), longest/most-specific match wins. Identifies the vendor/product/log-family so the row shows a real description and builds via AI, rather than reading "Unknown source type".</li>
      <li><b>Bounded fuzzy.</b> A Levenshtein match (edit distance ≤ 2) against the surface + canonical corpus catches typos (<code>aws_cloudwatchlogs_vpclow</code> → the real <code>vpcflow</code> canonical). High-confidence ⇒ near-exact; medium ⇒ <b>needs_confirmation</b>.</li>
      <li><b>Unresolved.</b> Nothing placed it → blocks the build (batch) / prompts for a real name (interactive).</li>
    </ol>
    <div class="note"><b>Glued prefixes &amp; tail validation.</b> Some vendors appear <i>concatenated</i> with a subtype (<code>aemaccess</code>, <code>trellixTIE</code>) where the tokenizer can't split them — a hint may opt in to matching a lone token that <i>starts with</i> the vendor token. For a short/greedy prefix like <code>ora</code>, a <code>gluedSuffixWords</code> guard requires the tail after the prefix to be a real log word (<code>oraaudit</code>, <code>oralistener</code> → Oracle ✓; <code>orange</code>, <code>oral</code> → stay unresolved). Per the field rule "when it starts with <code>ora</code>, it's mostly Oracle" — but only when the rest of the name agrees.</div>

    <h2><span class="d"></span>AI escalation (batch preflight)</h2>
    <p>In a batch, any name still <b>unresolved</b> after the deterministic ladder is sent <b>once</b> (deduped, cached) to the model for validation. The model's own knowledge — no web access — either maps it to a supported name, or flags it as a real source with no golden (<code>isRealSource</code>) so it's lifted to <b>catalogue_gap</b> and built on its own name, or leaves it unresolved. When it recognizes a real source it also returns a description / log-format / typical-fields, which are reused downstream to ground sample-generation so the model isn't queried twice.</p>

    <h2><span class="d"></span>Interactive picker — search on Confirm</h2>
    <p>The three interactive entry points (<b>Create Pack</b>, <b>Create Demo</b>, <b>Create Pipeline</b>) all share one confirmation flow so you always proceed with a <i>confirmed</i> sourcetype:</p>
    <ol class="steps">
      <li><b>Type a name and press Confirm / Add.</b> The local recognizer runs first (instant, offline — the same tier ladder as batch). An exact / alias / high-confidence match is accepted straight away.</li>
      <li><b>No exact match → the catalog is searched then and there.</b> <code>searchSupportedSourcetypes</code> returns every supported sourcetype whose name or description matches your term — ranked <b>name-prefix › name-substring › description</b>, with golden (★) sources first. It also merges in <b>vendor product families</b> (<code>PRODUCT_FAMILY_VARIANTS</code>): typing <code>sap</code> surfaces <code>sap_audit</code>★, <code>sap_syslog</code>, <code>sap_hana</code>, <code>sap_erp</code>…, and <code>f5</code> surfaces the whole BIG-IP family (LTM / ASM / APM / AFM / GTM), even though only some have a golden.</li>
      <li><b>Pick one → it's used directly.</b> The listed options come from the catalog and curated families, so they're valid by construction — clicking one confirms immediately (no second check). Prefer to refine the name yourself? Edit it and Confirm again; only free-form text is re-validated.</li>
    </ol>
    <div class="note"><b>Search runs on Confirm, not as-you-type.</b> The picker deliberately does not show results while you type — the list only appears after a Confirm attempt that didn't resolve, so a valid known name goes straight through and the vendor list only appears when you actually need to choose.</div>

    <h2><span class="d"></span>Recognition grounds sample generation</h2>
    <p>Confirming a sourcetype does more than unblock the wizard — it captures what the source <i>is</i> (<b>vendor · product · log family</b>, and for AI-validated sources a <b>typical wire format</b> and <b>field list</b>). That metadata is assembled into a <b>grounding context</b> (<code>buildSampleGroundingContext</code>) and passed to the AI sample generator in <i>both</i> run modes, so the model generates events that match the real product instead of only seeing a bare sourcetype string. It's layered <b>behind</b> a real reference sample and the static format spec — those still win when present; grounding is the win for recognized-but-not-golden sources.</p>

    <h2><span class="d"></span>Multi-format sources — confirm the format</h2>
    <p>A few vendors emit the <i>same</i> source in more than one wire format depending on how the feed is configured — Zscaler NSS (key=value / JSON / CEF), Corelight/Zeek (JSON / TSV), FortiGate (key=value / CEF), Check Point (key=value / CEF / LEEF), Blue Coat ProxySG (W3C ELF / SQUID). Guessing wrong here produces unparseable events (the classic Zscaler-scored-0 case). A curated table (<code>getMultiFormatSpec</code>, offline &amp; instant) flags these:</p>
    <ul>
      <li><b>Interactive:</b> when there's no real reference sample, a <b>format picker</b> appears in the sample step — you confirm which format your feed emits, and that choice is locked into the grounding context (<i>“emit ONLY this format”</i>).</li>
      <li><b>Batch &amp; Demo:</b> can't prompt mid-run, so the <b>most common</b> format is assumed and the row/log is <b>flagged</b> so the assumption is visible and correctable (rerun with a reference sample or via the interactive wizard to pick another).</li>
    </ul>
    <div class="note"><b>A real reference sample always wins.</b> When the app already has real events for a source, no format prompt is shown and no grounding format is forced — the real data removes all doubt.</div>

    <h2><span class="d"></span>Format first — a CEF sample names its own source</h2>
    <p>When you upload a sample, its <b>wire format is decided before its sourcetype</b>, and the sourcetype is then read from what that format carries. For CEF this is exact: every event names its own <b>Device Vendor</b> and <b>Device Product</b> in the header, so the source is <i>read</i>, never guessed from extension keys. A sample is CEF when at least 60% of its lines carry a CEF header, whether it starts the line or sits after a syslog frame (<code>&lt;189&gt;Jan 12 fw01 CEF:0|Fortinet|Fortigate|…</code>). The vendor's own sourcetype is chosen only where that vendor's parser reads its CEF at least as well as the generic CEF parser — <b>FortiGate</b> (its parser recovers the nanosecond event time, policy, VDOM and application) and <b>Check Point</b>. Every other vendor builds as <code>cef</code>, the generic CEF Key Dictionary parser, with the vendor named in the reason. The same recogniser runs in the wizard, the AI detector in both run modes and the Sample Sanitizer, and the AI detector is told the locally detected format and asked to decide the format first.</p>
    <div class="note"><b>What this fixes.</b> Syslog-framed CEF used to fall through to vendor pattern matching, which read extension keys and got the vendor wrong — framed Infoblox CEF matched the VMware NSX syslog parser at 100% confidence. A start-of-line CEF sample was always built as generic <code>cef</code>, even a FortiGate one whose own parser reads more of it.</div>
  </section>

  <!-- ============================ CHAPTER 3 ============================ -->
  <section class="chap" id="ch3">
    <div class="chap-h"><div class="chap-n">3</div><div class="chap-t">Where the sample comes from</div></div>
    <p>Everything downstream is decided by the sample: extraction is written against it, the destination schema variant is inferred from it, and <b>every score is measured on it</b> (Chapter 7). A sample in the wrong wire format produces a pipeline that extracts nothing; a one-line sample produces a pipeline that looks fine and has barely been tested. So the app treats sample resolution as its own stage, with one rule: <b>real logs first, synthetic last, and never a sample the source's own parser cannot read.</b></p>

    <h2><span class="d"></span>The tier ladder — real data wins, always</h2>
    <p>Tried in order; the first hit wins, so synthetic data can never shadow a real log.</p>
    <table>
      <tr><th>#</th><th>Tier</th><th>What it is</th><th>Real?</th></tr>
      <tr><td>1</td><td><b>Your own sample</b></td><td>Events you pasted / uploaded, or a sample already living in the worker group</td><td>✅ real</td></tr>
      <tr><td>2</td><td><b>Curated fallbacks</b></td><td>Hand-checked lines for the core sourcetypes we build deterministically</td><td>✅ real</td></tr>
      <tr><td>3</td><td><b>Reference logs</b></td><td>${d.sourceSamples} sourcetypes of real logs from the Splunk <code>security_content</code> corpus</td><td>✅ real</td></tr>
      <tr><td>4</td><td><b>Harvested vendor logs</b></td><td>${d.vendorSamples} sourcetypes lifted from a vendor corpus's own pipeline test fixtures, fetched from the shared samples pool (licence notices intact)</td><td>✅ real</td></tr>
      <tr><td>5</td><td><b>Verified AI samples</b></td><td>Previously generated samples that passed parser verification and were promoted into the repo</td><td>⚙ synthetic, checked</td></tr>
      <tr><td>6</td><td><b>Fresh AI generation</b></td><td>Generated now, grounded by the recognition metadata from Chapter 2 (vendor · product · wire format · typical fields)</td><td>⚙ synthetic</td></tr>
    </table>
    <div class="note"><b>A broken real sample is worse than a missing one.</b> Because these tiers short-circuit, an entry whose lines its own parser cannot read would shadow every good sample behind it — that is exactly how two sources silently built pipelines that extracted nothing. Such entries are now <b>skipped at resolution time</b> in both run modes, so resolution falls through to the next tier instead of serving them.</div>

    <h2><span class="d"></span>A batch row can bring its own sample</h2>
    <p>A batch file has no sample column. Each pre-flight row has a <b>Sample</b> column, before the sourcetype, with a <b>Choose sample</b> button. It opens the same modal as the sanitizer, in three steps: pick the events (the <b>Library sample</b> for the row's declared sourcetype, a <b>Saved sample</b> from the shared sanitised library, or your own events by upload, paste or capture), confirm the sourcetype read from them, then — for your own events — review the sanitisation and press <b>Sanitize &amp; use for this row</b> (optionally also saving it to the sample library). <b>Use without sanitising</b> is there too; with Settings → <i>Require sanitised samples</i> on, such a row's events never reach an AI prompt. The pick sets the sample and saves that sourcetype for the row, and for every row of the same pack and declared sourcetype, because a pack stores one <code>&lt;sourcetype&gt;_sample.log</code>. Up to 100 whole events (64 KB) are kept. A chosen sample <b>is</b> the row's sample — tier 1 above, labelled <code>uploaded</code> in the results — and no store sample is looked up, generated, or silently appended in its place; it is labelled thin only because a score from few events is less representative, never as “missing”. Choosing the library sample for the declared name leaves the row on the normal library resolution. A row with no chosen sample resolves through the library tiers when you continue; samples that must be generated or extended by AI are created at the start of the batch run, as its first stage (<b>Creating samples</b>), before any pack builds. Source confirmation and sample review are one pre-flight screen and one Next action, rather than two steps that can disagree. You never name the sample's format. Before anything is built, every row needs a canonical sourcetype saved in the pre-flight's <b>Canonical</b> column. Suggestions are already listed there: names the sample itself identifies (CEF header, stock datatype, JSON signature) under <b>From the sample</b>, catalog names close to the declared sourcetype under <b>Close names</b>, and names that already have a stored golden under <b>Has a golden</b> — a golden the catalog does not list is still offered when its name is close. Clicking one fills the field; it does not save. <b>Detect sourcetype</b> runs the same ladder as the single-pack wizard's button of that name — CEF header, stock datatype, JSON key signature, all offline — and only where those name nothing does it ask the model, which is then listed under <b>AI read the sample</b>. With Settings → <i>Require sanitised samples</i> on, a row's own unsanitised events are never sent for that: sanitise them in the picker, or type the name. Edit it when necessary and press <b>Save</b>. The corrected CSV, and the rest of the batch, stay unavailable until every row is saved, and the warning names each unsaved row (its number, declared sourcetype and pack) so you can jump to it. Two rows of one pack that end up with the same sourcetype but different samples are refused at Next.</p>
    <ul>
      <li><b>One uploaded event is thin only for scoring confidence.</b> It is used exactly as supplied and is not extended with generated events. A thin library sample may still be extended by the normal tier policy.</li>
      <li><b>Each different sample is its own sample.</b> Two rows of the same source with different lines — a FortiGate key=value pack and a FortiGate CEF pack — never share one, and in a background run a parser proven on one is never replayed on the other.</li>
      <li><b>One pack stores one sample per source</b> (<code>&lt;sourcetype&gt;_sample.log</code>), so two rows of the same pack and source with different samples are refused at upload, naming both rows. Put each variant in its own pack.</li>
      <li>A cell over 64 KB is refused (this is one event or a few, not a log file), and so is a quoted cell holding a line break — put each event on one line.</li>
    </ul>
    <div class="note"><b>Your own events are customer data.</b> With Settings → <i>Require sanitised samples</i> on, a row's own sample is never sent to the AI provider: it is not extended, it skips AI content classification, and its build runs <b>without any AI step</b> — only the golden, built-in parser and Search-datatype paths — and says so in the row's log. The same rule now covers a pasted or uploaded sample in the wizard, which used to skip only the AI parse and still sent the events to AI mapping. Sanitise the sample first (Chapter 4) to use the AI steps with it.</div>

    <h2><span class="d"></span>Every sample is labelled with its wire format</h2>
    <p>A number of sources ship in <b>more than one wire format</b> depending on how the feed was configured — Zscaler NSS as key=value, JSON or CEF; FortiGate as key=value or CEF; Corelight as JSON or TSV; Check Point as key=value, CEF or LEEF. The pack is built around the shape of the sample it was given, so <b>choosing a sample is choosing a format</b>: a CEF sample for a feed that really emits key=value produces a pipeline that looks perfect against the sample and extracts nothing in production.</p>
    <p>So every place a sample is offered states its format, detected deterministically (no AI, instant): each sample in the worker-group list carries a badge, the recommended reference sample carries one, and once a sample is loaded its format is spelled out under the preview — JSON, XML, CEF, LEEF, key=value, CSV/TSV/PSV with the column count, syslog or free text. A sample whose lines are not all the same shape is marked <b>mixed</b>, because that changes what the pipeline has to handle.</p>
    <p>The label answers the question a human is actually asking, so it reports <b>structure, not transport</b>: Corelight over syslog reads <code>JSON (syslog-framed)</code> and Aruba CX reads <code>PSV (6 cols, syslog-framed)</code> — the payload decides the extraction, and the frame is named because it has to come off first. Check Point's <code>time=…|hostname=…|action=…</code> reads <b>key=value</b>, not 18 pipe-separated columns, because a pipe there separates pairs rather than fields. A column count is only claimed when at least 70% of the lines split into the <i>same</i> number of fields — otherwise any long free-text line with a few commas would masquerade as CSV.</p>
    <div class="note"><b>The sample decides the variant.</b> For a multi-format source the wizard adopts the loaded sample's format instead of the default it guessed from the name, and says which variant it recognised. If the events match <i>none</i> of the known variants, it says that too — that is the signal to check the sample before building. And when a mixed sample carries <i>two</i> of the source's variants — the Corelight reference sample really does hold syslog-framed JSON records <i>and</i> Zeek TSV rows — both are named, because a pack built for one silently drops the other.</div>

    <h2><span class="d"></span>Verification — a sample is only kept if the parser can read it</h2>
    <p>A generated (or harvested) sample is replayed through the sourcetype's <i>real</i> parse functions before it is trusted. Three verdicts: <b>pass</b> (fields came out), <b>fail</b> (the parser read nothing — the sample is the wrong format), and <b>unverified</b> (we own no parser for this source, so it cannot be measured — which is <i>not</i> counted as a failure). For a source we <i>do</i> own a parser for, "couldn't check it" is evidence against the sample. A failure is fed back into the retry prompt, so the model is told <i>why</i> instead of being asked the same question again.</p>

    <h2><span class="d"></span>Thin real samples are extended at the moment of use</h2>
    <p>A vendor's own test fixture holds one line per case, so most real samples are short: <b>${d.vendorSamples-d.vendorAtFloor} of ${d.vendorSamples}</b> harvested sources ship fewer than 10 events. Rather than store padded data, the stores keep whatever real lines exist and the app <b>tops the sample up when a build actually needs it</b>, targeting 20 events.</p>
    <ol class="steps">
      <li><b>The real lines are the specification.</b> They go into the prompt verbatim, together with the exact field names, the envelope (JSON / key=value / CEF / delimited / free text), the column count and the real line length. The model's only licence is to <b>vary values</b> — timestamps, IPs, users, ports, ids, outcomes.</li>
      <li><b>The rules are enforced in code, not by the prompt.</b> Every generated line is checked against the real ones and dropped if it adds a field, changes the envelope, changes a delimited line's column count, uses vocabulary absent from the real free-text lines, duplicates an existing line, or falls outside the real length band. For a source whose parser reads <i>every</i> real line, a generated line that same parser cannot read is dropped too.</li>
      <li><b>At most two model calls, and the second is told what failed.</b> The retry asks for fewer lines and receives the rejection reasons, which is what recovers both real failure modes: a model that got the wire format wrong, and one that ran out of budget thinking.</li>
      <li><b>Every failure degrades to the real sample</b> with a visible note. Extension is an improvement, never a dependency — it can't fail a build.</li>
    </ol>
    <div class="note"><b>Why the guards are strict.</b> Generated values are counted in the value-coverage denominator (Chapter 7) exactly like real ones. That is only fair because a hallucinated field is impossible: if one slipped through, it would be scored as a value the pipeline failed to extract and would send repair rounds chasing a field the vendor never emits. Nothing generated is ever written into the shipped stores — extensions are cached against the real lines' fingerprint for the session and die with it.</div>

  </section>

  <!-- ============================ CHAPTER 4 ============================ -->
  <section class="chap" id="ch4">
    <div class="chap-h"><div class="chap-n">4</div><div class="chap-t">Sanitising the sample</div></div>
    <p>Everything in Chapter 3 is about getting a <i>real</i> sample. Tier 1 of that ladder is <b>your own log</b> — and a real production log is customer data before it is anything else. Because the pipeline is written, mapped and scored against this sample, it cannot simply be redacted; it has to stay a working specimen of the source while every identity in it is replaced. That is what this chapter is about, and all of it happens <b>in the browser, with no network call</b>.</p>

    <h2><span class="d"></span>The sample is customer data before it is anything else</h2>
    <p>A real production log is full of the estate that produced it: hostnames, accounts, addresses, subscriber numbers, and often a live credential. The app puts sample lines into AI prompts at roughly a dozen call sites, so the sample is the one thing in this tool that can leave the building. It is pseudonymised <b>in the browser, with no network call</b>, before it can.</p>
    <p>It is not a button anyone has to remember. The mapping is planned <b>the moment a real sample lands</b> and put on screen while the reviewer is still looking at the events. Nothing is rewritten until Apply, Apply has a single-level undo, and neither the plan nor the original is ever persisted — the un-sanitised text must not outlive the tab.</p>

    <h2><span class="d"></span>Apply is advisory in the wizard, strict in the sample library</h2>
    <p>One compute plans and applies the whole sequence — replace the values, check the wire format survived, re-parse before and after to prove the identities changed, and re-verify against the source parser (<code>runSanitisation</code> in <code>sanitised-sample-workflow.ts</code>). It never throws; each caller applies its own policy over the same numbers, so the two flows can never silently diverge:</p>
    <ul>
      <li><b>The pack-generation wizard is advisory.</b> Apply writes the sanitised events straight back so you can build with them. If a replacement shifted a delimiter or whitespace boundary the wire format is genuinely broken and Apply is refused — but a parser that now reads the events a little less cleanly only raises a <b>warning banner</b>: build with it anyway, or Undo and narrow the picks that changed the shape. A privacy step must not strand someone with a sample they cannot use.</li>
      <li><b>The sample library is strict.</b> Saving a reusable sanitised sample crosses a trust boundary — the original is discarded and only the sanitised text is kept — so <code>applyAndVerifySanitisation</code> throws on any failing gate (nothing changed, structure broken, identity coverage unproven, or a genuine parser regression) and the save is rejected.</li>
    </ul>
    <div class="note"><b>The source's own noise is never blamed on the sanitiser.</b> A real access log carries lines its own parser cannot read — scanner probes, TLS handshakes on the HTTP port, <code>408</code> timeouts with an empty request — so the <i>raw</i> sample already fails a strict parse-ratio check before anything is touched. The apply step verifies the parser against the events <b>before and after</b> and only warns (or, in the library, blocks) on a genuine <b>regression</b>: the original parsed and the sanitised copy no longer does. Sanitising a noisy Apache log therefore raises no warning at all, because sanitisation did not degrade what was already imperfect.</div>

    <h3>One door, and it is locked</h3>
    <p>Every call site used to write its own <code>sampleEvents.split('\\n').slice(0, 15)</code>, which meant there was no single place where "may this leave the building?" could be asked or found. <code>aiSampleSnippet</code> is now the only sanctioned path from sample text to prompt text, and it <b>throws</b> rather than returning empty — a silent empty snippet would have the model answer confidently about nothing and produce a pack that is quietly worthless. Vendor, reference and AI-generated samples are exempt by source: they are public or came out of a model in the first place, and a guard that blocks safe work is a guard people switch off.</p>

    <h3>What it finds, and on what evidence</h3>
    <table>
      <tr><th>Tier</th><th>Evidence</th><th>Reaches</th></tr>
      <tr><td><b>Parser fields</b></td><td>The parser that reads this format <i>names</i> the field</td><td>The only tier that can find a bare name. In an Apache line <code>jsmith</code> is a word between an IP and a bracket and no regex can know better — the parser calls it <code>user</code> and settles it. ${t} field names carry a known identity meaning.</td></tr>
      <tr><td><b>Patterns</b></td><td>The value's own shape</td><td>IPv4 / IPv6 (by class), email, MAC, <code>DOMAIN\\user</code>, FQDN.</td></tr>
      <tr><td><b>Field names</b></td><td>The name in front of the value, whatever the value looks like</td><td>${d.secretFields} credential field names and ${d.piiFields} personal / device ones. A handset serial or a postcode carries no pattern to match on, so the field name is the only thing that identifies it.</td></tr>
      <tr><td><b>Secret patterns</b></td><td>A public-source library of credential / sensitive-data patterns</td><td>Bundled from gitleaks and Microsoft Presidio (both MIT) plus vendor-published token shapes — nothing proprietary, so the Sample Sanitizer can publish its source for review. Filtered before use: rules that are only a character class and a length match every git SHA, and blunter IP/MAC/email/URL rules would displace ours. ${d.secretRules} of the ${d.secretRulesTotal} bundled rules survive that filter. Always present, in both run modes — no network call, no minimum platform version.</td></tr>
      <tr><td><b>Shape &amp; variance</b></td><td>A guess, and labelled one</td><td>Ships <b>unticked</b>. A guess that quietly rewrites a sample is worse than a guess the reviewer declines.</td></tr>
    </table>
    <div class="note"><b>The field name outranks the value's shape.</b> Tested against Cribl's own <code>businessevent.log</code>, six of eighteen card numbers survived the pattern tiers, because every card rule keys on an allocated brand prefix and these were test numbers. A partial pass is worse than none — it reads like success. A field called <code>cardNumber</code> is now settled on its name alone.</div>

    <h3>Four properties, because the pipeline is scored against this sample</h3>
    <p>A sanitised sample is not a redacted one. It has to stay a working specimen of the source, or the pack built from it is built against fiction:</p>
    <ul>
      <li><b>Consistent</b> — one alias per distinct value, applied everywhere. Per-occurrence randomness would turn forty events about one host into forty hosts.</li>
      <li><b>Class-preserving</b> — internal addresses stay internal in their own range, public ones land in the RFC5737 documentation blocks and never on a real organisation's address.</li>
      <li><b>Shape-preserving</b> — label counts, <code>DOMAIN\\user</code>, delimiters, column counts and JSON keys survive, because a parser is generated and regex-matched against these lines. Scrambling is repertoire-aware: a hex serial stays hex, ten digits stay ten digits.</li>
      <li><b>Collision-free</b> — no alias may already appear in the sample, or two real machines silently merge into one.</li>
    </ul>

    <h3>Credentials are reported differently, because the action is different</h3>
    <p>Every other row in the review list is a privacy judgement the reviewer gets to weigh. A credential is not: it is live in whatever system produced the log, whatever is decided about this copy. Credentials lead the list, in their own colour, and are <b>scrambled character-for-character rather than blanked</b> so length, delimiters, auth scheme and URI structure survive for scoring. The warning says the part that matters — <i>treat the original as exposed and rotate it; sanitising this copy does not revoke anything.</i></p>

    <h3>What is deliberately left alone</h3>
    <ul>
      <li><b>Product and device vocabulary</b> — ${d.vocabularyFields} field names whose values are catalogue, not identity. A phone model code (<code>SGS5</code>, <code>IP6P-64</code>) is not a hostname, and the generated pipeline extracts that field.</li>
      <li><b>Business identifiers</b> — ${d.suspectFields} field names holding an order, quote, invoice or policy number. Not personal data, but they correlate to a customer in whatever system issued them, and a pipeline may well be meant to key on them. They are named in a warning <b>with counts</b> rather than as one row per value, and the choice is left to the reviewer.</li>
      <li><b>Structural placeholders</b> — <code>NA</code>, <code>null</code>, <code>localhost</code> and their kin. Replacing one changes how the line parses.</li>
    </ul>

    <h3>Reviewing it — grouped, and painted onto the sample</h3>
    <p>A real log carries a distinct account number, handset serial and mobile number on <i>every</i> line, so "one row per value" is thousands of rows: 5,000 events produced 26,000 entries. The decision was never per value anyway — it is "yes, replace the postcodes", made once against a group with a count on it. So the list is <b>grouped by kind and folded shut</b>, with tick-all per group, and rows are only mounted when a group is opened.</p>
    <p>The reviewer's real question is "is <i>that</i> card number handled?", and a list of values below a box of raw text does not answer it. So the findings are <b>highlighted on the sample itself</b>, coloured by group, with a legend and with found-but-unticked values outlined rather than filled. The highlights come from the sanitiser rather than a second opinion about what looks sensitive, so a highlight cannot promise cover the apply step will not deliver.</p>

    <h3>Anything missed can be picked by hand — by value, or by field</h3>
    <ol class="steps">
      <li><b>Highlight a value.</b> The selection grows to whole-token edges, because replacement is whole-token and a half-selected <code>acme</code> inside <code>acme-corp.com</code> would match nothing and vanish with no explanation.</li>
      <li><b>Or take the whole field.</b> Highlighting <code>51015341</code> inside <code>quoteNumber=51015341</code> offers <i>all</i> values of <code>quoteNumber</code>. This is the only way to reach a value that differs on every event: there is no literal to add, and the number alone is genuinely unsafe to replace, since the same digits are a port or a counter elsewhere in the sample. Picking the field also reaches the events further down that nobody scrolled to.</li>
      <li><b>Both land in one editable list</b>, so a pick can be removed again — a value as itself, a field as <code>field:quoteNumber</code>.</li>
    </ol>
    <div class="note"><b>An explicit pick overrules the defaults.</b> Business identifiers and product vocabulary are skipped <i>by default</i>, and those defaults are exactly what a reviewer is overruling when they pick the field — so the pick is honoured ahead of both. Values picked this way keep their shape (eight digits come back as eight different digits) and are minted fresh, so two different quotes never collapse into one.</div>

    <h2><span class="d"></span>Where the sample comes from — including live capture</h2>
    <p>A sample reaches the sanitiser four ways: <b>upload a file</b>, <b>paste</b> the events, <b>pull an existing group sample</b>, or <b>capture live traffic</b> off a worker group. Getting the sample is the one part of this flow that <i>does</i> talk to Cribl — the pseudonymisation that follows still happens entirely in the browser. So the network step is "fetch the events", never "send the un-sanitised events anywhere".</p>
    <p>Live capture is the interesting one, because a capture is only as good as the traffic behind it:</p>
    <ul>
      <li><b>Only groups with a connected worker are offered.</b> An empty group captures nothing and would read as a broken feature; the picker is filtered to groups that actually have a worker (counted from <code>/master/workers</code>), and says so plainly when none do.</li>
      <li><b>Events stream in, in short windows.</b> The capture runs as a series of brief windows rather than one long request — both because the App Platform's iframe fetch proxy buffers a whole response and abandons anything that runs too long, and because a reviewer wants to <i>see</i> events arriving, not wait blind. Each window's events are appended to a live preview with a running count and a <b>Stop</b> control, and exact-duplicate lines are de-duplicated across windows so overlapping windows never double-count.</li>
      <li><b>You confirm the right events before moving on.</b> The point of the live view is to answer "is this the data I meant?" while it is still cheap to change the filter or the group — before the source is identified and the pipeline is built against it.</li>
    </ul>

    <h2><span class="d"></span>The standalone Sample Sanitizer app</h2>
    <p>Not everyone who needs a de-identified log is building a pack. The same sanitise engine is therefore compiled a second time as its own App Platform app, <b>Sample Sanitizer</b> — a single-purpose tool for "make this log shareable" with no pack, no destination, and no AI key to configure.</p>
    <p>It is a <b>second build target of this one repository, never a fork</b>. The wizard, the plan-and-apply compute and the review UI are shared source, so every change described in this chapter lands in both apps at once. What differs is only the <i>bundle</i>: the sanitizer ships without the AI client, the goldens, the source-sample corpus or any schema code, and a build-time reachability guard <b>fails the build</b> if any AI module ever becomes reachable from it. That is what lets the app carry an "AI-Free" badge honestly — it is a property of the module graph, not a promise in a footer.</p>

    <h2><span class="d"></span>Where a sanitised sample is saved</h2>
    <p>On the save step you can tick any combination of destinations — the sanitised copy is the only thing written; the original is never persisted:</p>
    <ul>
      <li><b>Add to this generator's sample library.</b> Keeps it local to this app installation so the pack generator will reach for it as a real-format sample for that sourcetype (on disk in <code>config/sanitised-samples/</code> when standalone, in App KV in the iframe).</li>
      <li><b>Upload to worker group.</b> Creates or replaces a group-level sample under the worker group's own system samples (<code>/m/*/system/samples</code>). This is the <b>shared</b> destination: both the pack generator and the standalone Sample Sanitizer can reuse it, and a <b>Stream pipeline can read it directly</b> from Routes / QuickConnect — the de-identified copy becomes real tooling, not just a file in this app.</li>
      <li><b>Publish to the shared sample pool.</b> Standalone-only, and gated on a dedicated repository configured in Settings. It is <b>hidden entirely in the iframe</b>, because publishing runs on the local dev server — an option that could never fire there is worse than no option at all.</li>
    </ul>
    <div class="note"><b>One shared library, not two.</b> An earlier build offered a separate "add to shared sanitised library" checkbox alongside "Upload to worker group". They wrote to the same place, so the redundant one was removed: the worker-group upload already gives every consumer — both apps and Stream itself — one reusable, de-identified sample per source.</div>
  </section>

  <!-- ============================ CHAPTER 5 ============================ -->
  <section class="chap" id="ch5">
    <div class="chap-h"><div class="chap-n">5</div><div class="chap-t">The resolution sequence</div></div>
    <p>Each stage tries several <b>candidates</b> and keeps the one that <b>scores highest</b> — priority only breaks ties. A higher-priority source can never <i>lower</i> quality, and if a stage scores below its threshold an extra AI-improvement candidate runs to try to beat it. The winning source is shown on the stage card.</p>

    <h3>Extraction candidates (in order tried)</h3>
    <div class="flow">
      <div class="step"><div class="rank">1st</div><div class="nm">🏆 Golden</div><div class="ds">A verified, stored pipeline for this sourcetype, replayed when the sample's format matches.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">2nd</div><div class="nm">🔍 Search datatype</div><div class="ds">A Cribl Search stock parser (matched by name, or by <b>sample shape</b> for unknown sources).</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">3rd</div><div class="nm">⚙ Built-in / pack</div><div class="ds">A static parser emitting the canonical field model, or one from an existing Cribl pack.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">4th</div><div class="nm">🤖 AI</div><div class="ds">The configured LLM generates the parse stage.</div></div>
    </div>
    <div class="note"><b>Order flips by destination.</b> Extraction is scored on value coverage, which is <i>name-agnostic</i> — two parsers that pull the same values out of <code>_raw</code> score identically even if one names a field <code>srcip</code> and the other <code>src_ip</code>. But the mapper reads a fixed <b>canonical field model</b> (<code>src_ip</code>, <code>dest_port</code>…). So for a <b>mapped schema destination</b> the curated golden/built-in parsers (which emit those canonical names) are tried <i>before</i> the stock Search datatype, whose vendor-native names would leave the mapper with nothing to read. For <b>JSON / raw</b> (no mapping step) the Search datatype is tried first, since its native names <i>are</i> the desired output.</div>
    <div class="note"><b>Computed once per pack.</b> When you pick several destinations for one sourcetype, the pack builds one pipeline per destination — but extraction is <i>destination-independent within a class</i>, so it is resolved and scored <b>once</b> and reused across the sibling pipelines instead of re-running the candidate loop (and any AI call) per format. There are two classes because of the ordering above: the <b>mapped-schema</b> parser (canonical names) and the <b>raw/JSON</b> parser (native names) differ, so each class resolves at most once. The pack also stores <b>one sample per sourcetype</b> (<code>&lt;sourcetype&gt;_sample.log</code>, not one per destination) — every pipeline parses the same sample. Passthrough destinations add no parser, so they skip extraction entirely.</div>

    <h3>Mapping candidates (in order tried)</h3>
    <div class="flow">
      <div class="step"><div class="rank">1st</div><div class="nm">🏆 Golden</div><div class="ds">A stored, verified mapping for this <code>sourcetype::format</code>.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">2nd</div><div class="nm">🐐 Cribl schematizer</div><div class="ds">Cribl Copilot's own agent builds OCSF / ECS / UDM pipelines.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">3rd</div><div class="nm">🤖 AI (grounded)</div><div class="ds">For Sentinel &amp; CIM: AI grounded on the exact target table / data-model columns.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">4th</div><div class="nm">Static</div><div class="ds">Deterministic golden-format spec assembly as the floor.</div></div>
    </div>
    <ul>
      <li><b>OCSF · ECS · Chronicle UDM</b> — delegated to Cribl's <b>schematizer agent</b>, which returns one complete parse+map+enrich pipeline (observables, <code>unmapped</code>, <code>type_uid</code>, the exact versioned class like <code>ocsf@v1.8.0-network_activity-4001</code>). The app enforces the family you chose and caches a high-scoring result as golden so future builds skip the ~1–2 min agent call.</li>
      <li><b>Microsoft Sentinel</b> — pick a native <b>table</b> (CommonSecurityLog, SecurityEvent, ASim…); the mapping is grounded on that table's DCR columns and scored against them.</li>
      <li><b>Splunk CIM</b> — pick a <b>data model</b> (Network Traffic, Authentication, Endpoint…); grounded on that model's exact CIM field names and scored source-relative.</li>
    </ul>

    <h3>Output shaping</h3>
    <p>Fully <b>deterministic</b> — the destination's required envelope, cleanup and compaction are applied after mapping. There is no AI step or optional raw-source noise-drop catalog here. Event suppression exists only in the separate <b>OCSF Post-Processing</b> workflow, where qualified OCSF rules are evaluated against already-normalized events.</p>

    <h3>Second-model retry</h3>
    <p>If an <b>AI-generated</b> stage still scores <b>below its golden threshold</b> (set per stage in Settings), the app makes <b>one</b> extra attempt using the <b>second model</b> configured in Settings, and keeps whichever result scores higher. This replaces the old multi-pass repair loop with a single, targeted retry.</p>

    <h3>Mid-build health gates (automatic)</h3>
    <p>Between stages, the app detects two common failure modes and <b>self-heals</b> without extra user action:</p>
    <ol class="steps">
      <li><b>Empty extraction → auto-retry.</b> If extraction finishes with <b>zero named fields</b> (regex didn't match the sample format at all), the app immediately retries with a fresh AI parse. This catches cases where the initial parser was built for a different log format than what's in the actual sample.</li>
      <li><b>Real field names → mapping.</b> The AI mapping stage receives the <b>actual field names</b> produced by extraction (e.g. <code>src_ip</code>, <code>dest_port</code>, <code>duration</code>), not a static list. For AI-parsed unknown sources where no built-in parser exists, this prevents the mapper from inventing field references that don't exist in the pipeline.</li>
      <li><b>Empty-value detection → mapping retry.</b> After mapping scores, if more than 50% of the output values are empty strings or null (the mapper referenced wrong field names), the app detects the mismatch and retries the mapping with the correct extracted fields. This catches stale goldens or first-AI mappings built against different extraction output.</li>
    </ol>
    <div class="note"><b>Why this matters for batch runs.</b> In a batch of 200+ sources, these gates mean that even completely unknown sourcetypes get a correct first-attempt pipeline autonomously — without manual intervention or a second-pass repair. The first AI attempt that fails is caught, diagnosed, and fixed <i>before</i> the pipeline is committed.</div>

    <h3>Where the AI runs, and what that costs it</h3>
    <p>On localhost the AI calls go through the app's own backend, which has no per-call time limit. <b>Inside the Cribl UI they run in your browser</b> through the platform's fetch proxy, and that proxy <b>cancels any request that has not answered within 30 seconds</b> — a ceiling the app cannot raise. So work that needs a long answer is split into small asks: sample generation goes out in batches of a few events, a batch that times out is retried smaller, and whatever earlier batches produced is kept rather than thrown away.</p>
    <div class="note"><b>Reasoning models spend your token allowance on thinking.</b> On Gemini 2.5 and later — and on Claude's extended-thinking models — the token limit covers the model's internal reasoning <i>and</i> its visible answer, so a model that thinks hard can use the whole allowance and return nothing at all. The app sets a low thinking level and adds room for the answer on top of it, but if you are choosing a model for this workload, a <b>flash / fast</b> model is both quicker and more reliable here: parsing and mapping are structured extraction, not the kind of problem deeper reasoning improves.</div>
  </section>

  <!-- ============================ CHAPTER 6 ============================ -->
  <section class="chap" id="ch6">
    <div class="chap-h"><div class="chap-n">6</div><div class="chap-t">Extraction &amp; mapping</div></div>
    <p>Chapter 5 showed <i>which</i> source wins each stage. This chapter is the mechanics: <b>what extraction and mapping actually do to your events</b>, and the one thing that lets any parser feed any destination — the <b>canonical field model</b>.</p>

    <h2><span class="d"></span>The canonical field model — the pivot between the two stages</h2>
    <p>Extraction and mapping never talk to each other directly. They meet on a fixed, vendor-neutral vocabulary: <b>extraction's job is to land values under canonical names, mapping's job is to read those names.</b> A PAN parser, a Search stock parser and an AI parser can each pull an IP address out of a completely different log shape — as long as they all call it <code>src_ip</code>, the mapper doesn't care which one ran.</p>
    <table>
      <tr><th>Canonical field</th><th>Holds</th><th>Where it lands downstream</th></tr>
      <tr><td><code>src_ip</code> · <code>dest_ip</code></td><td>Source / destination address</td><td>OCSF <code>src_endpoint.ip</code>, CIM <code>src</code>/<code>dest</code>, ECS <code>source.ip</code>, ASim <code>SrcIpAddr</code></td></tr>
      <tr><td><code>src_port</code> · <code>dest_port</code></td><td>Ports</td><td>OCSF <code>*.port</code>, CIM <code>src_port</code>, CEF <code>spt</code>/<code>dpt</code></td></tr>
      <tr><td><code>user</code> · <code>src_user</code></td><td>Acting / source principal</td><td>OCSF <code>actor.user.name</code>, CIM <code>user</code>, ASim <code>ActorUsername</code></td></tr>
      <tr><td><code>action</code> · <code>severity</code></td><td>Outcome &amp; weight</td><td>OCSF <code>activity_id</code>/<code>severity_id</code>, CIM <code>action</code>, ASim <code>EventResult</code></td></tr>
      <tr><td><code>log_time</code></td><td>The event's own timestamp</td><td>The single field every golden spec reads to set <code>_time</code></td></tr>
      <tr><td><code>bytes_in</code> · <code>bytes_out</code> · <code>protocol</code> · <code>host</code> · <code>message</code></td><td>Traffic, transport, device, free text</td><td>The matching field in each schema</td></tr>
    </table>
    <div class="note"><b><code>log_time</code> is the one canonical name for time.</b> Every destination spec assembles <code>_time</code> from <code>log_time</code> and nothing else. If a parser captures the timestamp under any other name (<code>timestamp</code>, <code>epoch</code>, <code>ids_timestamp</code>), a self-healing alias step detects the timestamp-shaped field and copies it to <code>log_time</code> — otherwise every event would share one static processing-time. This is why a source can extract a date perfectly and still show a wrong <code>_time</code> unless it reaches <code>log_time</code>.</div>

    <h2><span class="d"></span>Extraction — pulling values out of <code>_raw</code></h2>
    <p>Extraction reads the raw log line (<code>_raw</code>) and produces named fields. Three deterministic techniques cover almost every structured source; AI is only the fallback (Chapter 5). The technique is chosen from the <b>shape of the sample</b>, not the sourcetype name:</p>
    <div class="stages">
      <div class="stage ex"><div class="sh">serde — structured</div><div class="sb"><b>kvp / json / csv / cef.</b> A single Cribl <code>serde</code> function splits a whole class of formats at once — <code>key=value</code> pairs, JSON objects, delimited columns. E.g. SAP audit is one kvp serde (<code>delimChar:' '</code>, <code>quoteChar:'"'</code>) that yields <code>USER</code>, <code>TCODE</code>, <code>TEXT</code>… in one step.</div></div>
      <div class="stage mp"><div class="sh">regex_extract — text</div><div class="sb"><b>Unstructured / syslog lines.</b> Named capture groups pull fields out of prose (<code>Cisco ASA</code>, firewall syslog). Per the field rule this is preferred over code functions — a chain of <code>regex_extract</code> + <code>eval</code>, never a JS <code>function</code>.</div></div>
      <div class="stage op"><div class="sh">eval — normalize</div><div class="sb"><b>Rename to canonical.</b> After the serde/regex, an <code>eval</code> maps the vendor-native names onto the canonical model (<code>SUNAME</code>→<code>src_user</code>, <code>TERMINAL</code>→<code>src_ip</code>) and builds <code>log_time</code>. One expression per field — Cribl allows no statements.</div></div>
    </div>
    <p>Two Cribl constraints shape every extraction stage the app emits:</p>
    <ul>
      <li><b>One expression per <code>eval</code> field.</b> No <code>=&gt;</code>, <code>function</code>, <code>return</code>, <code>;</code> or <code>?.</code> — only ternaries, <code>||</code> chains, <code>.match()</code>, <code>Date.parse</code>, String/Number/Math. AI output is passed through a sanitizer that drops anything that isn't a safe single expression.</li>
      <li><b>Accessor-safe field names.</b> Hyphens, spaces, <code>@</code> and leading digits break Cribl's property-accessor build (SAP's <code>SY-MANDT</code> is the classic crash). A kvp/csv serde is forced to <code>cleanFields:true</code> and any bracket reads / keep-drop lists are realigned to the cleaned name.</li>
    </ul>
    <div class="note"><b>Values that stay in <code>_raw</code> don't count.</b> Extraction is scored on what it pulls <i>out</i> — a JSON parser pointed at a CSV extracts nothing and correctly scores low, even though the data is "right there" in <code>_raw</code>. That's the health gate in Chapter 5: zero named fields ⇒ automatic AI retry.</div>

    <h2><span class="d"></span>Mapping — projecting the canonical fields into the destination</h2>
    <p>Mapping takes the canonical fields and lands them in the destination schema — renaming, re-shaping, and adding the fields the schema requires. What it does depends on the schema family:</p>
    <ul>
      <li><b>Flat schemas (CIM · ECS · CommonSecurityLog · ASIM · CEF).</b> A set of <code>eval</code>s copies each canonical field to its schema name (<code>src_ip</code> → CIM <code>src</code>, ASim <code>SrcIpAddr</code>) and sets <code>_time</code> from <code>log_time</code>. CEF/CIM then serialize the model into <code>_raw</code>; ASIM keeps the fields top-level.</li>
      <li><b>Nested schemas (OCSF · ECS objects).</b> The output is an object tree (<code>src_endpoint.ip</code>, <code>actor.user.name</code>). A Cribl eval can only assign a dotted path once its <b>parent object exists</b>, so the mapper creates <code>src_endpoint = {}</code> before setting <code>src_endpoint.ip</code>. OCSF also gets its enrichment literals — <code>class_uid</code>, <code>type_uid</code>, <code>severity_id</code>, the versioned class id.</li>
      <li><b>Grounded schemas (Sentinel table · Splunk CIM data model).</b> Mapping is generated against the <i>exact</i> column set of the table/data-model you picked, so the field names match the target's DCR / data-model definitions rather than a generic guess.</li>
    </ul>

    <h3>Golden mapping vs AI mapping</h3>
    <div class="flow">
      <div class="step"><div class="rank">golden</div><div class="nm">🏆 Deterministic spec</div><div class="ds">A stored <code>golden-formats.json</code> spec assembles the output field-by-field from the canonical model. No AI, byte-stable, instant.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">agent</div><div class="nm">🐐 Schematizer</div><div class="ds">Cribl Copilot builds OCSF/ECS/UDM; a high score is cached as a golden so it isn't re-run.</div></div>
      <div class="arr">›</div>
      <div class="step"><div class="rank">ai</div><div class="nm">🤖 Grounded AI</div><div class="ds">Receives the <b>real extracted field names</b> and the target's column list, so it can't invent references that don't exist.</div></div>
    </div>
    <div class="note"><b>The mapper only ever reads canonical names.</b> This is why, for a mapped destination, curated parsers that emit the canonical model are tried before a stock Search parser whose vendor-native names the mapper couldn't read (Chapter 5). If mapping shows &gt;50% empty output values, it means the mapping referenced field names extraction never produced — the app detects this and retries mapping against the real extracted fields.</div>

    <h2><span class="d"></span>The sample-structure guard — why a golden can be <i>refused</i></h2>
    <p>A golden pipeline is only replayed when the <b>sample actually matches the format the golden expects</b> (<code>goldenPathMatchesSample</code>). Each golden source carries an expectation — its wire format (<code>kvp</code>/<code>cef</code>/<code>json</code>/<code>unstructured</code>) plus a few critical keys. Before the golden runs, the app fingerprints your real sample and compares:</p>
    <ol class="steps">
      <li><b>Format agrees →</b> golden runs.</li>
      <li><b>Golden expects a structured format but the sample fingerprints as unstructured →</b> the app requires at least one critical key to appear as a real delimited pair in the raw sample (<code>key=</code> for kvp/cef, <code>"key":</code> for json). If none do, the golden is <b>refused</b> and the source falls to AI.</li>
    </ol>
    <div class="note"><b>Concrete failure this prevents.</b> A SAP-audit pack whose samples were actually generic Linux SSH/syslog lines: the correct SAP kvp parser had no <code>USER=</code>/<code>TCODE=</code> pairs to read, so it output only enrichment constants and scored ~0 extraction. The guard now detects the wrong-family sample and routes it to AI instead of silently running a golden that can't match — the durable fix for a broken source is a correct offline sample (so the golden has real data) <i>plus</i> this guard (so a wrong sample can never ride the golden path).</div>

    <h2><span class="d"></span>Goldens are filed per wire format</h2>
    <p>One source can ship in several wire formats, and a golden learned from one extracts nothing from another — a FortiGate key=value golden run on FortiGate CEF reads no fields. So a golden is keyed on the <b>sample's wire format</b> as well as the sourcetype, in every store (the app's own store, the bundled goldens and the shared pool) and for all three golden kinds (full pipeline, extraction part, mapping part):</p>
    <ul>
      <li><b>The source's own format keeps the plain key.</b> <code>fortinet_fortigate::cim</code> is still the key=value golden, so every existing golden keeps serving the data it was built from.</li>
      <li><b>Any other format gets its own variant.</b> A FortiGate CEF build is filed and looked up as <code>fortinet_fortigate@cef::cim</code> and never replays the key=value golden, even when no CEF golden exists yet — it builds fresh and stores its own.</li>
      <li><b>A custom source</b> (one with no declared format) is always filed under its variant (<code>acme_app@json</code>). It still reuses a golden stored before variants existed, unless that golden's recorded sample was visibly a different format (CEF or JSON).</li>
      <li><b>A mixed or empty sample</b> (no shape on more than half the lines) is filed under the plain key, exactly as before — an unknown format is never guessed.</li>
      <li><b>The sourcetype part is the canonical name</b> (build 815). A typed <code>checkpoint_firewall_cef</code> reads and writes <code>checkpoint_firewall@cef</code>, so it shares the goldens every other Check Point CEF build learned instead of starting a second set. A part stored under the typed name before this is still found as a fallback.</li>
    </ul>
    <p style="font-size:11.5px;color:var(--mut)">The knowledge-base counts in Chapter 8 count a variant under its source, so <code>fortinet_fortigate@cef</code> does not add a sourcetype.</p>

    <h2><span class="d"></span>The export formats — one sub-chapter per tile</h2>
    <p>Everything above is format-agnostic. This is what each <b>destination tile</b> in the wizard actually produces, how it is built, and the one thing worth knowing before you pick it. Three things apply to all of them:</p>
    <ul>
      <li><b>Pick several — get several pipelines.</b> Every selected tile is built as its own pipeline in the <i>same</i> pack (first one creates it, the rest are added), in one commit. Each is scored and quality-checked separately, so a source can go to CIM <i>and</i> Sentinel without one compromising the other.</li>
      <li><b>Three tiles are a family, not a format.</b> Sentinel, Splunk CIM and ASIM open a sub-selector at the bottom of the step: the tile is resolved to the <b>concrete</b> target you pick (a table name, a data model, an ASim schema) before anything is built.</li>
      <li><b>Output shape is a hard contract, not a preference.</b> Four shapes exist — <code>nested</code> (an object tree), <code>flat</code> (top-level columns), <code>raw</code> (a serialized string in <code>_raw</code>) and <code>passthrough</code> (the original event, tagged). Getting the shape wrong is how a pipeline that maps every field correctly still gets rejected by the destination.</li>
    </ul>
    <table>
      <tr><th>Tile</th><th>Output shape</th><th>Built by</th><th>Mapping stage scored?</th></tr>
      <tr><td><b>CrowdStrike NG SIEM</b></td><td>raw (the original <code>_raw</code>, alone)</td><td>Parser for drops and flags only; nothing mapped</td><td><b>No</b> — scored as raw fidelity instead</td></tr>
      <tr><td><b>OCSF 1.9</b></td><td>nested</td><td>Cribl schematizer → golden → AI</td><td>Yes</td></tr>
      <tr><td><b>CEF</b></td><td>raw (<code>_raw</code> string)</td><td>Golden spec → AI</td><td>Yes</td></tr>
      <tr><td><b>Microsoft Sentinel</b></td><td>flat (the table's columns)</td><td>Golden (CSL) or AI grounded on the DCR</td><td>Yes — through the real column list</td></tr>
      <tr><td><b>Splunk CIM</b></td><td>raw + metadata (fields <i>inside</i> <code>_raw</code>)</td><td>Golden spec → AI grounded on the data model</td><td>Yes</td></tr>
      <tr><td><b>Elastic ECS</b></td><td>nested</td><td>Cribl schematizer → golden → AI</td><td>Yes</td></tr>
      <tr><td><b>Sentinel ASIM</b></td><td>flat</td><td>Golden spec (per ASim schema) → AI</td><td>Yes</td></tr>
      <tr><td><b>Chronicle UDM</b></td><td>nested</td><td>Cribl schematizer → golden → AI</td><td>Yes</td></tr>
      <tr><td><b>Cortex XSIAM</b></td><td>passthrough</td><td>Deterministic tagging from the source catalog</td><td>Yes — as an all-or-nothing contract</td></tr>
      <tr><td><b>Passthrough (raw copy)</b></td><td>passthrough</td><td>None — events forwarded unchanged</td><td><b>No</b> — no transform, no schema</td></tr>
      <tr><td><b>Clean JSON</b></td><td>flat</td><td>Golden spec (rename only)</td><td><b>No</b> — no schema to map to</td></tr>
    </table>

    <h3 id="fmt-nextgen">CrowdStrike NG SIEM</h3>
    <p><b>What it is:</b> the original event, byte for byte, for the NG SIEM connector's <b>vendor parser</b> — one connector (and ingest token) per parser. NG SIEM parses only the HEC <code>event</code>, in the vendor's exact native shape, and bills the <b>whole payload</b>, so the pack sends <code>_raw</code> and nothing else (<code>_time</code> travels as the HEC <code>time</code>). There is no OCSF class to pick.</p>
    <p><b>How it works:</b> the pipeline copies <code>_raw</code> aside before anything runs, parses only so the source's own drops and flags can read fields, then puts the untouched copy back as its last step and removes every other field. Some parsers rewrite <code>_raw</code> on the way (Windows, Zscaler), which is why the copy exists. It is <b>not</b> delegated to Cribl's schematizer, and no golden, Copilot or AI mapping runs: there is nothing to map.</p>
    <p><b>Scored as raw fidelity, not value coverage.</b> The score is the share of output events whose <code>_raw</code> is an original sample line, unchanged, with no billable field beside it. Value coverage over an unchanged line measures only its own tokenizer (an identical Cisco ASA line scored 76), and an OCSF schema check would grade a shape the destination never receives. Internal <code>__</code> fields never leave Cribl and <code>cribl_*</code> is stamped by the platform after the pack, so neither counts against it. In the 3-stage build the Mapping card is N/A and the Optimization card carries this score, which is also the pipeline's overall score.</p>

    <h3 id="fmt-ocsf">OCSF 1.9</h3>
    <p><b>What it is:</b> the Open Cybersecurity Schema Framework — a nested object tree (<code>src_endpoint.ip</code>, <code>actor.user.name</code>) plus the numeric identifiers that make an OCSF event valid. <b>How it works:</b> the whole build is first delegated to <b>Cribl Copilot's schematizer</b>, which returns one combined parse+map+enrich pipeline; if its mapping scores below the threshold and we hold a deterministic golden for the source, the app falls back to the golden/AI path instead. A high-scoring agent result is cached as golden sub-parts so the agent isn't re-run on the next build.</p>
    <p><b>Mapping is scored against the real OCSF schema.</b> The app vendors the published OCSF schema (currently 1.9.0, all 87 classes) and grades the Mapping card against it: required attributes present, coded values that are legal OCSF enum members, <code>type_uid</code> = <code>class_uid</code> × 100 + <code>activity_id</code>, and — new in build 683 — that populated attributes carry the right JSON type (a numeric/timestamp/boolean/object field emitted as a string, e.g. <code>severity_id:"1"</code> or <code>metadata</code> as a bare string, is the classic interop bug an OCSF consumer like Amazon Security Lake rejects; it costs at most a 10% haircut and a clean event is scored exactly as before). Attributes that are not in the class schema at all are listed as advisory (no score penalty — OCSF allows vendor-specific carry-over under <code>unmapped</code>). Crucially the class is read from the <code>class_uid</code> the pipeline <i>actually produced</i>, not from the destination we guessed — so a schematizer pipeline that correctly built Authentication is no longer penalised for not matching an API-Activity template. Profile-gated attributes (<code>cloud</code>, <code>osint</code>, …) are not counted as required unless the pipeline opts into that profile.</p>
    <p><b>Shape and carry are scored together.</b> A schema-perfect event that drops most of the source's values is still a bad mapping, so the Mapping card blends the schema score 50/50 with <b>value carry</b>: of the sample values extraction delivered, each one that lands in a typed OCSF attribute of the event's class earns full credit, one kept only under <code>unmapped</code> earns a quarter (preserved, but not normalized), and one that vanished earns nothing. <code>raw_data</code> and routing fields never count. The whole-pipeline score uses the same weighting for its value-coverage lens. Every OCSF mapping now ends with an <b>output shaping</b> step: only the class's own attributes stay at the top level, every other extracted vendor field is folded into <code>unmapped</code>, and numeric attributes (<code>*_id</code>, ports, byte counts) are typed as numbers. The Mapping card scores this shaped event, which is the exact event the pack ships.</p>
    <p><b>The class is chosen from your data, not from a menu.</b> OCSF models different activity with different classes, so the spec is keyed by data class: <code>network</code> → Network Activity (<code>class_uid</code> 4001), <code>endpoint</code> → Process Activity (1007), <code>cloud_audit</code> → API Activity (6003), <code>authentication</code> → Authentication (3002, for Okta, LDAP and SAP audit logons), <code>dns</code> → DNS Activity (4003, for Infoblox, Corelight/Zeek, BIND, Microsoft DNS, Umbrella and Cloudflare Gateway) and <code>email</code> → Email Activity (4009, for Cisco ESA, Proofpoint, Postfix and FortiMail). The class comes from the <b>sample</b> when one is present, else from the sourcetype name — which is why Linux auditd lands on Process Activity even though its name suggests generic audit data, and SAP Security Audit Log lands on Authentication rather than a generic audit class.</p>
    <p><b>Windows picks the class per event.</b> One Windows channel spans many OCSF classes, so Security, Sysmon, PowerShell and System do not take one class for the whole log: the parser reads each event's EventID and assigns its class — 4624/4625 Authentication (3002), 4672 Authorize Session (3003), 4720 Account Change (3001), 4728 Group Management (3006), 4688 Process Activity (1007), 5156 Network Activity (4001), 4104/4103 Script Activity (1009), and so on; an EventID it has no class for becomes a Base Event (0) with everything kept under <code>unmapped</code>. The class check then only asks that every class in the output is one of those, so a Security sample of only process-creation events is not marked down for having no logons. DNS Client and Defender events have no per-event class yet, so they keep the DNS Activity / Process Activity class of their channel.</p>
    <p><b><code>metadata.product</code> names your source, not a template's.</b> Every class fills <code>metadata.product.vendor_name</code> and <code>.name</code> from the sourcetype's own vendor entry — CrowdStrike Falcon events say CrowdStrike, auditd says Linux, an Office 365 audit record says Microsoft, and <code>cloud.provider</code> follows the same vendor rather than defaulting to AWS. A CEF source is read from its own header instead, so a mixed CEF feed reports the device that actually sent each line. This matters beyond cosmetics: an OCSF post-processing rule's guard tests <code>metadata.product.vendor_name</code>, so a rule keyed on the real vendor would silently never match an event that claimed the wrong one.</p>
    <div class="note"><b>Two OCSF-specific mechanics.</b> A Cribl <code>eval</code> can only assign <code>src_endpoint.ip</code> once <code>src_endpoint</code> exists as an object, so the mapper creates the parent <code>{}</code> first — a missing parent silently drops the whole branch. And <code>class_uid</code>/<code>category_uid</code>/<code>type_uid</code>/<code>severity_id</code>/<code>time</code> are <b>added</b> values: they are excluded from the score's denominator (Chapter 7) and never counted as data you failed to extract. Known and legitimate: a multi-event-type source scores mid-range against OCSF because OCSF has no field for some vendor-specific values (ACL names, connection ids) — that is real signal, not a defect.</div>

    <h3 id="fmt-cef">CEF</h3>
    <p><b>What it is:</b> ArcSight Common Event Format — a single line, not a set of fields: <code>CEF:0|Vendor|Product|Version|SignatureID|Name|Severity|key=value…</code>. <b>How it works:</b> the golden spec builds the 7-part header and then ~40 extension keys (<code>src</code>, <code>spt</code>, <code>dst</code>, <code>dpt</code>, <code>proto</code>, <code>act</code>, <code>suser</code>, <code>in</code>/<code>out</code>, <code>request</code>…) from the canonical model, and <b>replaces <code>_raw</code></b> with the result. Extension keys are only emitted when their value exists, and the custom-string slots (<code>cs1</code>…) carry their own <code>cs1Label</code> so a receiver can name them.</p>
    <p><b>Severity is translated, not copied.</b> The two scales run in opposite directions: syslog severity 0 is most urgent, CEF severity 10 is. A value rule inverts it (syslog 0-1 → 10, 3 → 8, 5 → 4, 7 → 1) and defaults to 5 when the source carries no severity at all.</p>
    <div class="note"><b>Why the mapping is emitted in chunks.</b> CEF assembly is split across several <code>eval</code>s of 6-8 fields each. This is not stylistic — Cribl fails on one very large template literal, so merging the chunks breaks the pipeline. Two more contract details: there is <b>no leading host word</b> before <code>CEF:0</code> (a common hand-rolled mistake), and the pipe and equals characters inside values must stay escaped.</div>

    <h3 id="fmt-sentinel">Microsoft Sentinel</h3>
    <p><b>What it is:</b> a family, not a format — the tile opens a sub-selector of <b>50 native Sentinel tables</b> and the one you pick <i>is</i> the build target. Recommendations are pre-filtered from the sourcetype (an AWS VPC flow source offers <code>AWSVPCFlow</code>, <code>ASimNetworkSessionLogs</code>, <code>CommonSecurityLog</code>), and the chosen table shows its real column count.</p>
    <p><b>How it works:</b> <code>CommonSecurityLog</code> has a hand-verified golden mapping and takes it. Every other table is mapped by AI <b>grounded on that table's exact DCR column list</b> plus Microsoft's own official solution DCR transforms where they exist — so the field names come from the table definition rather than a plausible guess.</p>
    <div class="note"><b>Sentinel's contract is the exact opposite of CIM's.</b> A DCR accepts <b>only the table's own columns</b> as top-level fields and silently discards everything else (a 2xx, no error), so a Sentinel pipeline <i>must</i> ship the table's shape and nothing more — the shaping step is structural here, not an optimization you can switch off. Keeping <code>_time</code> needs an explicit exception, because the cleanup that removes <code>_*</code> would take it with it. Types are part of the contract too: a mistyped value lands as an <b>empty column</b>, so the pack casts each column it writes to the table's DCR type (ports and bytes to numbers, <code>LogSeverity</code> to a string; an unparseable value becomes null, never a made-up 0).</div>
    <div class="note"><b>A vendor-native table wants the vendor's own values.</b> When a table is named after the vendor's own log (<code>AWSVPCFlow</code>, <code>AWSCloudTrail</code>, <code>SecurityEvent</code>, <code>GCPAuditLogs</code>), its columns are the vendor's field names — so its <code>Action</code> column expects AWS's <code>ACCEPT</code>/<code>REJECT</code>, not the canonical <code>allowed</code>/<code>blocked</code>. Parsers normalize vocabulary in place, so the original token is preserved as <code>vendor_action</code> / <code>vendor_severity</code> (both real Splunk CIM field names) and preferred for those columns. <code>ASim*</code> tables carry Microsoft's <i>own</i> normalized vocabulary, and <code>CommonSecurityLog</code>/<code>Syslog</code> are generic containers — all three keep the canonical value.</div>

    <h3 id="fmt-cim">Splunk CIM</h3>
    <p><b>What it is:</b> the Splunk Common Information Model — the normalized field names Splunk's data models and dashboards search on (<code>src</code>, <code>dest</code>, <code>src_port</code>, <code>action</code>, <code>user</code>, <code>bytes_in</code>/<code>bytes_out</code>). The sub-selector offers all <b>27 CIM data models</b> (Network Traffic, Authentication, Endpoint, Change…), and the pick grounds the AI mapping on that model's real field list.</p>
    <p><b>How it works:</b> the golden spec maps ~59 canonical fields to their CIM names, then <b>serializes them into <code>_raw</code> as JSON</b> and strips the top level back to Splunk metadata only (<code>_raw</code>, <code>_time</code>, <code>index</code>, <code>source</code>, <code>sourcetype</code>, <code>host</code>). That is the shape a Splunk indexer expects — CIM fields are indexed <i>from</i> <code>_raw</code>, so leaving them at the top level as well duplicates every field. A stale mapping that serializes but forgets the cleanup is self-healed at build time.</p>
    <div class="note"><b>CIM's vocabulary is the canonical one.</b> This is the destination where <code>allowed</code>/<code>blocked</code> and <code>success</code>/<code>failure</code> are <i>correct</i>, and the vendor's original string belongs in <code>vendor_action</code> / <code>vendor_severity</code> — CIM defines both fields for exactly that purpose, and the spec fills them.</div>

    <h3 id="fmt-ecs">Elastic ECS</h3>
    <p><b>What it is:</b> the Elastic Common Schema — a nested tree in dot notation (<code>source.ip</code>, <code>destination.port</code>, <code>event.action</code>, <code>host.name</code>, <code>observer.vendor</code>) for Elasticsearch, Kibana and Elastic SIEM. <b>How it works:</b> like OCSF, ECS is first delegated to Cribl's schematizer, with the golden spec and grounded AI behind it. <code>event.kind</code>, <code>event.category</code> (as an array, the shape ECS defines) and <code>ecs.version</code> are set as literals, and <code>event.outcome</code> is derived from the canonical <code>action</code> by a value rule (anything matching deny/drop/block/fail → <code>failure</code>, else <code>success</code>). <code>@timestamp</code> is never written in the pipeline (a Cribl Eval cannot create a field starting with <code>@</code>) — the Elasticsearch destination writes it from <code>_time</code>.</p>
    <p><b>The original line survives.</b> Unlike OCSF and UDM, the ECS spec keeps the source text in <code>message</code> — so an ECS pipeline stays searchable on the raw event even where the schema has no field for a given value.</p>
    <div class="note"><b>Graded against the real ECS schema (build 870).</b> The app carries a pinned copy of Elastic's own field list (ECS 9.5.0: every field's Elasticsearch type, which fields are arrays, and the allowed values for <code>event.kind</code>/<code>category</code>/<code>type</code>/<code>outcome</code>). Three things lower the score, because each is something Elasticsearch or Elastic Security actually does with the event: a <b>mapping conflict</b> (a plain string where ECS defines an object — Cribl's own <code>source</code> metadata or a vendor <code>rule</code> string against ECS <code>source.*</code>/<code>rule.*</code>) makes Elasticsearch <b>reject the whole document</b>, capped at <b>25</b>; a <b>categorization value outside ECS's allowed set</b> indexes but is invisible to Elastic Security's rules and views, capped at <b>55</b>; and a <b>malformed typed value</b> — a non-IP in an <code>ip</code> field, text in a port, epoch <i>seconds</i> in a date (Elasticsearch reads a number as milliseconds, so it lands in 1970), a date with a space instead of <code>T</code> — is dropped from the index, so the score is capped at the share that indexes. When only some events are affected, the cap is the share of clean events. Everything Elasticsearch accepts is reported as advice and never costs points: a numeric string (coerced), a single value where ECS expects an array, a missing <code>ecs.version</code>, an <code>event.type</code> unusual for its category, and unknown fields under an ECS name (with the likely intended field suggested — <code>destination.prot</code> → <code>destination.port</code>). A top-level <code>host</code> string is fine: the destination turns it into <code>host.name</code>. The ECS builders clear same-named source fields before mapping, so their own output passes these checks.</div>

    <h3 id="fmt-asim">Microsoft Sentinel ASIM</h3>
    <p><b>What it is:</b> Microsoft's Advanced Security Information Model — normalized, schema-versioned tables that sit <i>above</i> the native ones. Output is <b>flat</b> top-level columns (<code>TimeGenerated</code>, <code>EventType</code>, <code>EventResult</code>, <code>SrcIpAddr</code>, <code>DvcAction</code>…) plus the <code>EventSchema</code>/<code>EventSchemaVersion</code> literals that identify which ASim schema an event claims to be.</p>
    <p><b>How it works:</b> ASIM is <b>10 different schemas</b>, and the app ships a golden spec for each — Authentication, DNS, Web Session/Proxy, Network Session, Process/Endpoint, File, Registry, Audit, DHCP and User Management. The sub-selector defaults to <b>auto</b>, which resolves the schema from the source's data class, sniffed from the real sample where one exists; pick a schema explicitly to override it. Auto never guesses blindly: an unclassifiable source falls to Network Session, which is ASIM's own catch-all.</p>
    <div class="note"><b>ASIM keeps its own vocabulary.</b> <code>EventResult</code> is <code>Success</code>/<code>Failure</code> and <code>DvcAction</code> is Microsoft's normalized set — this is a normalized schema, so the vendor's raw token is <i>not</i> substituted back in the way a vendor-native table demands. <code>_raw</code> is preserved rather than dropped.</div>

    <h3 id="fmt-chronicle">Google Chronicle UDM</h3>
    <p><b>What it is:</b> Chronicle's Unified Data Model — a nested tree in dot notation with UDM's own principal/target framing (<code>principal.ip</code>, <code>principal.user.userid</code>, <code>target.ip</code>, <code>network.sent_bytes</code>, <code>security_result.action</code>). <b>How it works:</b> delegated to Cribl's schematizer (family <code>udm@</code>), with the golden spec behind it; <code>_raw</code> is dropped.</p>
    <div class="note"><b>UDM is strict about enum strings.</b> <code>metadata.event_type</code> must be one of Chronicle's own constants (<code>NETWORK_CONNECTION</code>, <code>USER_LOGIN</code>…) and <code>security_result.action</code> is an array of UDM Action constants — a value rule maps the canonical <code>action</code> onto <code>BLOCK</code>, <code>ALLOW</code> or, when the vendor's word is neither, <code>UNKNOWN_ACTION</code> rather than a guess. Protocol and authentication type/mechanism are gated to their enums the same way, repeated fields (<code>principal.ip</code>, <code>security_result</code>…) are emitted as arrays, and <code>metadata.event_timestamp</code> is set from <code>_time</code> as numeric <code>{seconds, nanos}</code>. Those are not cosmetic: the destination silently <b>drops</b> an event with no valid event type or timestamp (the Test tab still reports success), and a value outside an enum fails the whole batch with a 400. If your events describe activity the chosen event type doesn't cover, that mapping is worth validating against Google's UDM field list before you rely on it; the app flags this as a known risk rather than pretending it is verified.</div>

    <h3 id="fmt-xsiam">Cortex XSIAM</h3>
    <p><b>What it is:</b> the one destination that <b>deliberately does not normalize</b>. Cortex XSIAM ships its own content-pack parsers and XDM model, so re-shaping the event first would <i>destroy</i> the thing XSIAM knows how to read. The pipeline preserves <code>_raw</code> exactly and adds only the routing metadata XSIAM needs to select the right parser.</p>
    <p><b>How it works:</b> a catalog of <b>25 sources</b> — synchronized from Palo Alto's own Demisto content <code>.xif</code> contracts and data-source UUID table — supplies the tagging pattern per source: <code>tag_only</code>, <code>tag_vendor_product</code>, <code>cef_extract</code> or <code>zscaler_wrap</code>. It sets <code>__sourceIdentifier</code> (the data-source UUID) and, where the content pack requires them, the <b>exact</b> <code>__vendor</code>/<code>__product</code> strings. Exact means exact: XSIAM matches these literally, so a near-miss silently lands the data in the wrong dataset.</p>
    <div class="note"><b>An unknown source is marked, not faked.</b> When nothing in the catalog matches, the pack is still built with the generic collector UUID and a vendor/product guessed from the sourcetype name — but the guess is recorded as a high-severity finding and the score is <b>forced to zero</b> so an unverified routing contract can never look deployable. Scoring is also XSIAM-specific throughout: extraction checks that a native payload actually survived (and that JSON sources still parse, with the contract's expected paths present), mapping is an <b>all-or-nothing</b> contract check rather than a ratio (5-of-6 required tags is a failure, not 83%), and finalization verifies nothing was stripped that XSIAM needs.</div>

    <h3 id="fmt-passthrough">Passthrough (raw copy)</h3>
    <p><b>What it is:</b> the simplest possible destination — the pipeline transforms <b>nothing</b>. Every event is forwarded exactly as it arrived, with <code>_raw</code> preserved byte-for-byte. Use it when a customer wants to send a raw copy of the data to a Lake or a downstream destination that only wants <code>_raw</code>, with no parsing, no field mapping and no reduction.</p>
    <p><b>How it works:</b> the built pipeline carries a single <code>comment</code> marking intent and no processing functions at all — a valid Cribl pipeline that passes events through untouched. Unlike XSIAM it adds <i>no</i> routing tags and consults no catalog; it is a pure copy.</p>
    <div class="note"><b>How it scores.</b> It doesn't. A passthrough transforms nothing, so there is nothing to measure: <b>extraction, mapping and output shaping are all n/a</b>, and the overall score is <b>N/A</b> too — not a number. It used to report extraction 100, but that was a fake perfect score for doing no work: it inflated the average deployment score and read as validated transformation. A passthrough's job is 100% fidelity, which it always achieves by construction, so a score would only ever say "100" and tell you nothing. No golden sub-part is stored — there is no recipe to reuse, only the absence of one. (The completion event is still logged, with null scores, so the build is recorded but excluded from score averages.)</div>

    <h3 id="fmt-json">Clean JSON</h3>
    <p><b>What it is:</b> flat JSON with normalized, readable names — for Cribl Lake, S3, or any destination that just wants structured events. <b>How it works:</b> the golden spec is a rename-and-type pass over ~15 canonical fields (<code>src_ip</code>, <code>dest_port</code>, <code>protocol</code>, <code>action</code>, <code>user</code>, <code>bytes_in</code>/<code>bytes_out</code>, <code>host</code>, <code>severity</code>…), casting ports/bytes/duration to numbers, then drops <code>_raw</code>.</p>
    <div class="note"><b>Two consequences of having no target schema.</b> The <b>mapping card shows n/a</b>, not a score — there is no schema to be measured against, so reporting a number would be inventing one (Chapter 7's "not measurable ≠ failed"). And the extraction ladder <b>flips</b>: for JSON the Cribl Search stock parser is tried <i>first</i>, because its vendor-native field names are exactly what you want in the output, whereas a mapped schema needs the canonical-emitting parsers first. Note that a JSON-shaped pack aimed at Splunk tops out around 82 by design.</div>

    <div class="note" id="fmt-flow-only"><b>Build pack flow — destinations only that wizard offers (build 818).</b> The flow's destination picker lists the Cribl Lake options first (OCSF 1.9, Passthrough, <b>Raw + extracted fields</b>) and then every analytics tool alphabetically. <b>Raw + extracted fields</b> keeps the original <code>_raw</code> byte-for-byte and ships every extracted field top-level beside it — searchable as-is, and one Parquet column per field in the Lake; only parse scratch (<code>__*</code>, <code>msg_body</code>, <code>msg_format</code>) is removed. It has no target schema, so like Clean JSON the <b>mapping card shows n/a</b> and it uses the raw/JSON extraction class. <b>Splunk raw</b> and <b>Elastic integration</b> (for an ingest pipeline downstream) build exactly as Passthrough, and <b>Splunk JSON</b> / <b>Elastic JSON</b> exactly as Clean JSON — each keeps its own pipeline (<code>…_to_splunk_raw</code>, <code>…_to_elastic_json</code>…) so they can sit side by side, and each scores as its base format. <b>Splunk CIM</b> and <b>Elastic ECS</b> are the mapped equivalents. Post-processing offers the same split: Splunk raw / Splunk JSON and Elastic integration / Elastic JSON, where the JSON entries re-serialize the optimized OCSF event as real nested JSON.</div>

    <div class="note"><b>There is no "Custom / Other" destination.</b> Typing a free-text schema name used to be offered as an escape hatch, and it was removed (build 687) because it was the one destination nothing could verify: no golden spec, no column list, no validator, so mapping and the schema contract lint were skipped rather than measured, and the deployed pipeline had to be reviewed by hand. Every tile above is a <i>known</i> schema, which is what lets the pack be built and scored deterministically. For a genuinely bespoke internal schema, pick the closest real tile — "CommonSecurityLog" from the Sentinel tile gets you the hand-verified golden mapping — and adjust the deployed pipeline from there.</div>
  </section>

  <!-- ============================ CHAPTER 7 ============================ -->
  <section class="chap" id="ch7">
    <div class="chap-h"><div class="chap-n">7</div><div class="chap-t">How scoring works</div></div>
    <p>Every score answers one question: <b>“Of the information actually present in your sample, how much did the pipeline correctly extract and deliver to the destination?”</b> It is <b>source-relative</b> — a field the destination schema defines but your source never carries <b>cannot lower the score</b>. A sparse source that is fully captured still scores 100.</p>
    <div class="formula">score = round( distinct sample values that reach the OUTPUT ÷ distinct meaningful sample values × 100 )</div>
    <ul>
      <li><b>Meaningful values only.</b> Structural tokens and English prose ("Teardown", "connection") are filtered out so they don't pad the denominator.</li>
      <li><b>Enrichment is free.</b> Values the pipeline <i>adds</i> (<code>_time</code>, <code>severity</code>, protocol decode, OCSF <code>class_uid</code>) are output-only — excluded from the denominator and never penalized.</li>
      <li><b>A carried copy of the source never counts (build 786).</b> OCSF's optional “Keep original <code>_raw</code>” (Build pack flow) puts the untouched event in <code>raw_data</code>. Like <code>_raw</code>, <code>raw_data</code> is excluded from the output side of value coverage — otherwise every sample value would trivially “reach the output” and the score would say nothing about the mapping.</li>
      <li><b>Covered-elsewhere.</b> A multi-event sample maps different event types to different fields; a value is only "lost" if it reaches <b>no</b> output event.</li>
    </ul>

    <h2><span class="d"></span>Score bands</h2>
    <div class="bands">
      <span class="band g">85–100 · Good</span>
      <span class="band w">60–84 · Needs review</span>
      <span class="band f">0–59 · Broken</span>
    </div>

    <h2><span class="d"></span>The three stage checks</h2>
    <div class="stages">
      <div class="stage ex"><div class="sh">Extraction</div><div class="sb"><b>Did we pull the values out of <code>_raw</code>?</b> Value coverage against the extracted fields <i>only</i> — values still sitting in <code>_raw</code> do NOT count (a JSON parser that failed on a CSV extracts nothing and correctly scores low).</div></div>
      <div class="stage mp"><div class="sh">Mapping</div><div class="sb"><b>Did the extracted fields land in the destination schema?</b> Scored against the target format. For JSON/raw there is no schema → <b>N/A</b>.</div></div>
      <div class="stage op"><div class="sh">Output shaping</div><div class="sb"><b>Did destination cleanup preserve the mapped fields?</b> The structural finalizer is checked for regressions; it does not apply optional event suppression.</div></div>
    </div>

    <h3>Extraction score</h3>
    <div class="formula">score = value-coverage(sample → extracted fields), _raw excluded</div>
    <p>Example reason line: <code>42/55 meaningful source values were pulled out of _raw.</code></p>

    <h3>Mapping score</h3>
    <ul>
      <li><b>Nested schemas (OCSF)</b> — <i>golden-spec coverage</i>: of the schema fields whose parent object is present, how many are populated. <div class="formula">score = round( populated schema fields ÷ expected schema fields × 100 )</div> Pure enrichment literals (<code>class_uid</code>, <code>time</code>…) are excluded so they can't inflate it.</li>
      <li><b>Flat schemas (CIM · ECS · CommonSecurityLog · ASIM)</b> — <i>source-relative spec validation</i>: of the schema fields your source can actually fill, how many were populated.</li>
      <li><b>XSIAM</b> — a single hard routing/payload contract: native payload preserved + exact <code>__sourceIdentifier</code>/<code>__vendor</code>/<code>__product</code> tags. Partial = 0 until complete.</li>
      <li><b>JSON / raw</b> — no field mapping → <b>N/A</b>.</li>
    </ul>

    <h3>Output-shaping check</h3>
    <p>The finalizer is deterministic destination structure, not a user-selectable optimization. Its check protects mapped fields while cleanup and compaction run.</p>

    <h2><span class="d"></span>The overall "Pipeline Quality Check" score</h2>
    <p>The in-depth quality card (and the <code>deployment_score</code> logged to the dashboard) is the <b>end-to-end value coverage</b> of the final deployed pipeline against your sample — it runs the whole pipeline and measures how many sample values survive to the output.</p>
    <div class="note"><b>Why it can differ from the stage checks.</b> Each stage can pass its own checkpoint while the combined result still loses values <i>between</i> stages (e.g. a field extracted but demoted during mapping). The stage checks tell you <b>which stage to fix</b>; the overall score tells you the <b>real quality of the finished pipeline</b>. The gap is exactly the cross-stage issues listed in the findings.</div>
    <div class="note"><b>AI is advisory only.</b> The scores above are deterministic and computed from the real preview output — the AI never sets a score. Its findings and the specific lost values only feed the repair prompt.</div>
    <div class="note"><b>OCSF completeness gate.</b> OCSF is a <i>nested</i> schema, so a "flat" output — the right values under canonical names (<code>src_ip</code>, <code>user</code>…) but no nested objects — is not valid OCSF even though value coverage happily rewards those values. When an OCSF output has no <code>class_uid</code> or no populated nested content object (<code>src_endpoint</code>, <code>dst_endpoint</code>, <code>actor.user</code>, <code>device</code>, <code>connection_info</code>/<code>traffic</code>…), the score is capped into the <b>Broken</b> band so it can neither pass nor be stored as a golden, and repair is told to rebuild the nested envelope. A genuinely nested OCSF output (the deterministic golden path, or a good AI/static build) is never capped.</div>
    <div class="note"><b>OCSF class-correctness gate (build 698).</b> The completeness gate above asks whether the output is <i>shaped</i> like OCSF. This one asks whether it was mapped to the <b>right OCSF class</b> — a blind spot value coverage cannot see, because an event can carry every value from your sample and still be filed under the wrong class. A firewall log emitted as Email Activity, an SSL log as Email Activity, an EDR log left on Base Event: all "complete", all semantically wrong, and all useless to a SIEM that pivots on <code>class_uid</code>. When the source's data class maps to a <b>single unambiguous</b> OCSF class (network → Network Activity 4001, authentication → 3002, endpoint → Process Activity 1007, web proxy → HTTP Activity 4002, email → Email Activity 4009, DNS → 4003, cloud audit → API Activity 6003) and the output's <code>class_uid</code> never once carries it, the score is capped into the <b>Broken</b> band and repair is told which class to re-map to. Three deliberate limits keep it from ever false-capping: <code>audit</code> and <code>generic</code> sources are <b>excluded</b> (a device system log genuinely has no clean OCSF class, so there is nothing to enforce); a source that emits several classes is fine as long as its primary class appears somewhere; and the deterministic golden path cannot trip it, because it sets the class from the same data class the check expects. The related fix: a bare <code>subject</code> field no longer counts as strong evidence of an email source — it collides with a TLS certificate subject, which is what filed SSL logs as mail in the first place.</div>
    <div class="note"><b>Both OCSF gates now bound the staged Mapping score (build 789).</b> The staged builder creates every pack, and it grades an OCSF Mapping card with the real-schema oracle. The oracle grades the class the output <i>claims</i>, so it could not see a firewall filed as Email Activity, and a flat event scored against the guessed class still earned partial credit. The completeness gate (55) and the class-correctness gate (50) above are now one audit (<code>ocsfStructuralAudit</code>) that both the authoritative score and the staged Mapping card apply, so a wrong-class or flat candidate can no longer win the candidate loop, be accepted as the schematizer's combined build, or be stored as a golden. When a gate lowers the score, the card says so first (<i>OCSF capped at 50: this source is Network Activity (4001), the output emits class_uid 4009</i>) followed by the schema score it replaced. Each build's score event also records the class the output emits, the class the source should be, the schema score and the cap (<code>ocsf_class_uid</code>, <code>ocsf_expected_class_uid</code>, <code>ocsf_schema_score</code>, <code>ocsf_cap</code>).</div>
    <div class="note"><b>A zero has to be proven, not observed once (build 698).</b> The live preview endpoint serializes on the leader, so under concurrent scoring (a batch run, parallel worker groups, the quality-check runner) it can return <i>empty output</i> for a pipeline that transforms perfectly well — a false zero. Taken at face value that drives pointless repair rounds and can roll back a pipeline that was already good. So when the sample has input events but the preview yields none, the preview is re-run a few times with backoff and the first non-empty result wins; only a persistently empty output is treated as a real zero. Separately, score logging now <b>reports whether it landed</b> instead of failing silently — the Settings screen shows a per-session <i>logged / dropped</i> tally with the reason, so an empty dashboard dataset can no longer be discovered only by going to look at it.</div>
    <div class="note"><b>Reviewing a batch after the fact (build 787).</b> Every batch row keeps its <b>build trace</b> — the sample events it was built from, each candidate the builder tried, the stage scores and reasons, and the final pipeline functions. Download it per row (<i>Trace</i>) or hand it to the AI analysis (<i>Analyze</i>). When the batch finishes, <i>Download results</i> exports one record per pipeline as CSV or JSON: the stage scores, sources and reasons (including the OCSF schema check), the destination as resolved (e.g. <code>ocsf#network</code>), which tier supplied the sample and the wire format detected in it, and what the built pipeline is made of — how many Parser, <code>regex_extract</code> and code functions, and how many extractors run on every event with no filter. A row with more than one Parser or <code>regex_extract</code> is flagged on screen, because that usually means the same work is done twice. The same function counts are logged with each build's score event. Traces are kept only in memory, never in the resume checkpoint: a resumed run exports the rows it rebuilt with their traces, and the others from their on-screen results.</div>
    <div class="note"><b>Format-conformance caps (build 684).</b> Value coverage measures whether your <i>data</i> reached the output; it says nothing about whether the output is <b>shaped the way the destination requires</b>. A family of deterministic, offline format checkers runs after the coverage score and can only <b>lower</b> it — a correctly shaped event is scored exactly as before, so these caps never inflate anything:
      <ul>
        <li><b>CEF wire-format</b> — the single <code>_raw</code> line must carry the 7-part <code>CEF:0|…</code> header with no leading host word and properly escaped pipes/equals; a malformed header caps the score.</li>
        <li><b>CIM &amp; ASIM type conformance</b> — these ship real field <i>types</i>, so a field that must be numeric or boolean (a port, a byte count, <code>EventResult</code>'s companions) but is emitted as a string is the classic interop bug a Splunk data model or a Sentinel DCR rejects. Only the number and boolean families are enforced; string/timestamp/guid/dynamic stay lenient (mirrors the OCSF type check). A type violation costs at most a small haircut.</li>
        <li><b>ECS schema conformance (build 870)</b> — graded against a pinned copy of Elastic's ECS field list: a mapping conflict Elasticsearch rejects caps at <b>25</b>, a categorization value outside ECS's allowed set at <b>55</b>, malformed ip/number/date values at the share that indexes, and a flat blob fails the envelope check as before (details under <a href="#fmt-ecs">Elastic ECS</a>).</li>
        <li><b>Chronicle envelope</b> — the check is structural: the output must actually be nested into the expected namespaces (<code>metadata.*</code>/<code>principal.*</code>/<code>target.*</code>) rather than a flat blob with dotted key names. A flat blob claiming to be UDM is capped.</li>
        <li><b>Google SecOps UDM wire contract (build 841)</b> — the SecOps destination is stricter than the envelope: it silently <b>drops</b> an event whose <code>metadata.event_type</code> is not a UDM EventType or whose <code>metadata.event_timestamp</code> is not numeric <code>{seconds, nanos}</code>, and fails the whole batch with a 400 on a datatype mismatch (a scalar for a repeated field, a value outside an enum). When every event would be dropped the score is capped at <b>25</b>; a partial drop or any batch-400 violation caps it at <b>55</b>. Both sit under the golden bar, and the repair prompt is told which fields broke the contract. Raw + log type output is never graded here.</li>
        <li><b>JSON structural</b> — the output must be non-empty structured JSON, nothing more (there is no target schema to conform to).</li>
      </ul>
      All of these are computed by one engine (<code>auditSchemaConformance</code>) that is wired into the authoritative score: repair, post-processing and the <code>/pack-quality-check</code> re-score. The staged builder's stage cards (generate, batch, demo) grade with their own lenses; of these checks they apply the CEF wire-format gate, and not yet the CIM/ASIM type, ECS schema, Chronicle envelope or SecOps UDM wire-contract caps.</div>
    <div class="note"><b>XSIAM parse conformance — will XSIAM's own parser read this? (build 707).</b> Every other conformance check grades the output against a schema <i>we</i> map to. XSIAM is different in kind: it parses the vendor format itself, so the pack's whole job is to deliver a wire shape its content-pack rules accept. Tag correctness was already checked and says nothing about shape — and a shape problem is invisible from our side, because the pack deploys, the events arrive, and the dataset either sits <b>unparsed</b> or is <b>discarded</b>, in your tenant, silently.
      <p>This is now measurable offline, because the app mirrors XSIAM's own parsing rules from Palo Alto's Demisto content and <code>_raw_log</code> — the rule's name for the line as received — is our <code>_raw</code>. So the rule's own filter runs against our own output, with no emulation and no guessing. Two clauses can cap and one cannot:</p>
      <ul>
        <li><b>The rule's raw-line gate</b> caps. Juniper SRX, for instance, accepts a BSD timestamp <i>or</i> an RFC5424 header — so a pack that "helpfully" normalizes the timestamp to epoch satisfies neither and the dataset never parses, at a perfect tag score.</li>
        <li><b>A required key</b> caps, but only if <i>your sample already carried it</i>. FortiGate's rule reads the CEF extension <code>FTNTFGTeventtime</code>, so losing or renaming it is our doing; a rule reading <code>Message</code> names a field XSIAM's own syslog parser creates, and demanding that would false-fail a correct pack.</li>
        <li><b>Accepted timestamp formats</b> are reported but <b>never</b> capped — they mostly apply to fields the rule extracts internally, so a mismatch there is weak evidence about a field we may not even be looking at.</li>
      </ul>
      <p><b>How hard it caps depends on what it costs you, and on how much of the sample is affected.</b> Each rule records a <code>no_hit</code> disposition: some datasets <i>discard</i> a non-matching event (real data loss) and most <i>store it unparsed</i> (no XDM fields, no detections). If <b>every</b> event is rejected, the score is capped by that consequence — deeper for discard — well into the failing band, so it can neither pass nor be stored as a golden. If only <i>some</i> events fail, the cap is simply the share that XSIAM will parse: one malformed record in twenty is not a broken pack. And where the rule states something we genuinely cannot check, nothing is capped at all — an unmeasurable clause is reported, not counted against you.</div>
    <div class="note"><b>Build pack flow — optimization lives only in post-processing (build 786).</b> The “Build pack flow (including post-processing)” wizard builds the main pack exactly like Create new pack — no noise-drop or reduction rules, so OCSF is always full fidelity — and, when OCSF is a destination, builds <b>one post-processing pack per output format</b> in the same run (<code>&lt;name&gt;-&lt;format&gt;</code>, one per destination because a pack is attached per destination). Each output is either <b>Full copy</b> (the mapping only) or <b>Optimize by category</b> (adds the OCSF optimization rules). A Full copy also ships none of the optimization rules’ lookup CSVs (build 787). Only outputs that build are offered, and a post-processing band with no outputs blocks the step, so everything the screen shows gets built. Post-processing packs are curated deterministic transforms and are not quality-scored. Each post-processing pack is built and sampled from the <b>main OCSF pipeline’s own output</b> (build 815): exactly the events it emits, uploaded with every field kept and never re-wrapped (build 820) — so a source whose parser consumed <code>_raw</code> (Windows XML) arrives with no <code>_raw</code> and the original in <code>raw_data</code>. Only if that preview returns nothing does it fall back to the curated OCSF sample, and the build log says so.</div>
    <div class="note"><b>Raw outputs restore the original; every Splunk output carries host/source/sourcetype (build 820).</b> A raw post-processing output (Splunk raw, Elastic integration, XSIAM, CrowdStrike NG-SIEM) sends the <b>original</b> event: when the OCSF event carries <code>raw_data</code> (“Keep original <code>_raw</code>”) it is restored into <code>_raw</code>; with neither, the OCSF event is serialized into <code>_raw</code> and the build log warns. Every Splunk destination — CIM, Splunk raw and Splunk JSON in the main pack, and Splunk raw / Splunk JSON / CIM in post-processing — meets one <b>destination metadata contract</b>: <code>host</code> (the reporting device, else the worker), <code>source</code> and <code>sourcetype</code>. A restored vendor event gets the vendor's own Splunk identity (Windows Security → <code>XmlWinEventLog</code> / <code>XmlWinEventLog:Security</code>), an OCSF JSON <code>_raw</code> gets <code>ocsf</code> / <code>ocsf:&lt;source&gt;</code>, and Splunk raw/JSON post outputs strip every other field so Splunk HEC doesn't index the OCSF attributes.</div>
    <div class="note"><b>Elastic integration sets the Elastic <code>cribl</code> integration contract (build 840).</b> The <b>Elastic integration</b> card (and the Elastic integration post-processing output, on a restored vendor line) sends <code>message</code> = the original line, <code>_dataId</code> = the source's canonical name, <code>input.type: log</code> for the data streams that dispatch on it (system.auth, system.syslog), and removes <code>_raw</code>. The integration on <code>logs-cribl-default</code> reroutes on <code>_dataId</code> to the vendor integration, which parses <code>message</code>; the card shows the <code>route_entries</code> row to paste and whether your sample has the shape that integration parses. Sources only Elastic Agent can parse (Windows, CEF, Cisco Umbrella) get no <code>_dataId</code>, and the card recommends Elastic ECS instead. The output is the original line, so the score is unchanged: it is a passthrough and scores n/a.</div>
    <div class="note"><b>Google SecOps raw + log type (build 841).</b> The <b>Google SecOps raw (log type)</b> card (and the <b>Raw + log type (Google parser)</b> post-processing output, on a restored vendor line) is SecOps unstructured mode: <code>_raw</code> is sent byte-identical and <code>__logType</code> names Google's default parser for the source. The label comes only from a committed table of Google's supported default parsers, because an unknown or misspelled log type fails the <b>whole batch</b> with a 400; a source with no entry gets no label rather than a guess, and OCSF JSON gets none. The card is <b>Recommended</b> when Google's parser accepts your sample's wire format; when it doesn't (Windows PowerShell, Barracuda CloudGen, Zscaler web and Cisco ESA reference samples are in a format Google does not list), the card warns and recommends Chronicle UDM. The output is the original line, so it is a passthrough and scores n/a.</div>
    <div class="note"><b>Sentinel SecurityEvent and Syslog goldens (build 842).</b> The native <b>SecurityEvent</b> table (Windows Security channel) and the <b>Syslog</b> table now have hand-verified static mappings, so those packs build without AI. SecurityEvent maps each EventData field to its column by name and derives <code>Account</code> (<code>DOMAIN\\user</code>), <code>AccountType</code>, <code>Activity</code> and <code>LogonTypeName</code>; Syslog fills <code>Computer</code>, <code>ProcessName</code>, <code>ProcessID</code>, <code>SyslogMessage</code>, and <code>Facility</code>/<code>SeverityLevel</code> from the syslog <code>&lt;PRI&gt;</code>. Every column is cast to its DCR type. A year-less syslog timestamp (<code>Jun  9 16:17:01</code>) from Linux syslog and Linux secure now gets the current year instead of being read as 2001.</div>
    <div class="note"><b>Build pack flow — source noise reduction on non-OCSF cards (build 788).</b> A main-pack card other than OCSF, passthrough, XSIAM, JSON or Custom can be set to <b>Optimize</b> when the source has noise rules: the per-sourcetype drops retired from Create new pack plus the lookup-driven drops and suppression from the original Cribl packs (ASA <code>cisco_asa_drops.csv</code> / <code>cisco_asa_suppress.csv</code>, FortiGate <code>ftnt_events_drop.csv</code>, Palo Alto session-start logs, …). They run after mapping and before compaction, while the parser’s field names are still on the event; unticked rules ship switched off; a rule whose fields are missing is reported as “won’t fire”; a lookup rule ships only when its CSV is in the pack. <b>They do not move the Optimization score:</b> it is measured on a preview with every noise rule off, and the number of sample events the rules drop is reported as a separate reason. OCSF is never optimized in the main pack.</div>
    <div class="note"><b>Same-category noise rules and destination-aware AI advice (build 833).</b> A vendor noise rule is also offered, <b>switched off</b>, to every other source of the same category whose parser produces the fields it reads, marked “same-category rule”. Examples: the Palo Alto link-local and allowed-DNS drops and the ASA repeat-deny suppression for Juniper, Sophos, pfSense or SonicWall; the web static-asset drop for proxies; the CloudTrail read-only drop for GCP and Azure audit (secret, token and decrypt reads are always kept). A vendor’s own rule is never overridden, and IDS/threat feeds and bare CEF/LEEF get none. The AI advice and mapping prompts now carry the destination’s constraints (for example XSIAM and NG-SIEM parse <code>_raw</code> as received, so only whole-event reductions are safe; Sentinel drops a column whose type does not match the DCR) and the source’s wire format (key=value FortiGate condenses well, positional PAN-OS CSV does not). The reference docs are <code>docs/destination-specs/destination-constraints.md</code>, <code>docs/source-formats.md</code> and <code>docs/optimization-catalog.md</code>.</div>
    <div class="note"><b>OCSF → any format, without re-parsing (build 684).</b> The post-processing pipeline (already-structured OCSF in → SIEM wire format out) offers a target option for <b>every</b> output format, not just CEF. OCSF→CIM/ECS/ASIM/Sentinel&nbsp;CommonSecurityLog/Chronicle/JSON reuse the same canonical→destination golden mapping engine the raw-log flow uses: OCSF's nested objects are aliased to canonical names once, then handed to the destination's own <code>canonicalMap</code>. The OCSF-derived vendor/product survive rather than being reset to a per-sourcetype constant, and only CEF ships the editable class-dictionary lookup. Destination coverage matches the main pack flow (build 686): pick a specific Splunk CIM data model (all 14), a Microsoft ASIM schema (all 10) or a Chronicle event class — not just each family's default — and Microsoft Sentinel CommonSecurityLog is a first-class target.</div>
    <div class="note"><b>OCSF post-processing puts source values in real fields (build 881).</b> Each destination maps the OCSF attributes it has a field for (zones, interfaces, MACs, hostnames, users and domains, rule, session, ICMP, process and command line, DNS, HTTP, cloud) instead of leaving them to the leftover container. Measured over the curated OCSF samples and a Cisco ASA set, 75–99% of OCSF values now land in a proper field. Vendor <code>unmapped.*</code> data and anything else with no destination field goes to the leftover container (CommonSecurityLog <code>AdditionalExtensions</code>, ASIM <code>AdditionalFields</code>, Clean JSON <code>additional_fields</code>, extra keys in CIM's JSON <code>_raw</code>) as flat dot paths, never a dumped object. A value a destination field already carries is not repeated there. The URL is OCSF <code>url_string</code>, else it is composed from its parts. Chronicle maps the actor's process to <code>principal.process</code> and the launched process to <code>target.process</code>, with DNS questions as a repeated message. Chronicle has no leftover container, so zones, interfaces and vendor data with no UDM field are not carried. Raw-log flows are unchanged.</div>

    <h3>Quick reference</h3>
    <table>
      <tr><th>Number you see</th><th>What it measures</th><th>Formula</th></tr>
      <tr><td>Extraction (E)</td><td>Values pulled from <code>_raw</code> into named fields</td><td>covered ÷ meaningful sample values</td></tr>
      <tr><td>Mapping (M)</td><td>Fit to the destination schema (source-relative)</td><td>populated ÷ expected schema fields</td></tr>
      <tr><td>Output shaping</td><td>Destination cleanup preserved mapped fields</td><td>deterministic regression check</td></tr>
      <tr><td>Deployment score</td><td>End-to-end quality of the live pipeline</td><td>covered ÷ meaningful sample values (whole pipe)</td></tr>
    </table>
  </section>

  <!-- ============================ CHAPTER 8 ============================ -->
  <section class="chap" id="ch8">
    <div class="chap-h"><div class="chap-n">8</div><div class="chap-t">Knowledge-base stats</div></div>
    <p>The deterministic knowledge the app ships with — the more of this that fits your source, the less it needs the AI. These counts are read live from the app's bundled config.</p>

    <h3>Golden pipelines (verified, best-score-wins)</h3>
    <div class="stat-grid">
      <div class="stat"><div class="n">${d.goldenTotal}</div><div class="l">Golden entries</div><div class="s">total stored</div></div>
      <div class="stat"><div class="n">${d.goldenSourcetypes}</div><div class="l">Sourcetypes</div><div class="s">distinct covered</div></div>
      <div class="stat"><div class="n">${d.goldenFormats}</div><div class="l">Dest formats</div><div class="s">with a golden</div></div>
      <div class="stat"><div class="n">${d.goldenFull}</div><div class="l">Full pipelines</div><div class="s">end-to-end</div></div>
    </div>
    <table>
      <tr><th>Golden granularity</th><th>Count</th><th>What it is</th></tr>
      <tr><td>Full <code>sourcetype::format</code></td><td>${d.goldenFull}</td><td>Complete verified parse+map+shape pipeline</td></tr>
      <tr><td>Extraction sub-parts</td><td>${d.goldenExtraction}</td><td><code>::__extraction__</code> — reusable parse stage</td></tr>
      <tr><td>Mapping sub-parts</td><td>${d.goldenMapping}</td><td><code>::__mapping__</code> — reusable schema mapping</td></tr>
    </table>
    <div class="note"><b>A mapping sub-part is keyed on the CONCRETE schema.</b> A build resolves <code>OCSF</code> to one class (<code>ocsf#network</code>, <code>ocsf#authentication</code>, …) and <code>CIM</code> to one data model before it looks anything up, so a part stored under the bare family name — <code>&lt;source&gt;::ocsf::__mapping__</code> — is not what a build asks for. Those are read anyway, but only on <b>proof</b>: an OCSF mapping states its class in the event (<code>class_uid</code>), and the part is used only when that class is the one this build wants. Of the bare OCSF parts in the shipped store, 9 pass and 6 do not — one is an HTTP Activity mapping where the build wants Network Activity, another a Detection Finding, and one copies its class from the event and so proves nothing. Replaying any of those would produce a wrong-class pack that the class-correctness cap then penalises, so an unprovable part is left unused. CIM and ASIM parts record no data model anywhere, so a bare one is never promoted — the deterministic spec mapping runs instead.</div>

    <h3>The shared golden pool — how these counts grow</h3>
    <p>Goldens are not only what shipped with the app. When a pipeline clears its threshold on <b>real deployed output</b> it is stored locally, and — if you opted in under <b>Settings › Shared Golden Knowledge</b> — published to a shared pool held in a <b>public, goldens-only</b> GitHub repository (<code>wvdlinde-cribl/cribl-pack-goldens</code>, branch <code>shared-goldens</code>). Publishing is <b>create-only, first-writer-wins</b>: an existing shared golden is never overwritten by a later run. On startup the app checks the pool and shows a <b>star badge</b> with how many entries are new to you or score higher than yours; you pick which to import.</p>
    <div class="note"><b>Reading the pool costs nothing and needs nothing.</b> Every install may read it, anonymously, in both run modes — no token to configure, and nothing to leak, because the repository contains goldens and only goldens. Startup costs a single conditional read of the manifest, and an unchanged manifest answers "not modified". <b>Publishing</b> is the part that needs a credential: a GitHub token with write access, held server-side, so it runs in <b>standalone</b> mode only. That lane is metered — GitHub allows <b>5,000 requests/hour per user account</b>, shared across every token that user owns — so it is issued serially, bulk reads go through GraphQL (about <b>7</b> requests for the whole ${d.goldenTotal>=100?`600+`:`${d.goldenTotal}`}-entry pool rather than one per golden), and once the budget is spent the next call fails immediately with the reset time instead of retrying. The <b>Test GitHub access</b> button reports what is left.</div>
    <p style="font-size:11.5px;color:var(--mut)">So importing goldens works inside the Cribl UI exactly as it does on localhost; only publishing back to the pool is standalone-only. Everything else in this document works identically in both modes.</p>

    <h3>Cribl Search stock parsers (matched by name or sample shape)</h3>
    <div class="stat-grid">
      <div class="stat"><div class="n">${d.searchParsers}</div><div class="l">Search parsers</div><div class="s">datatype library</div></div>
      <div class="stat"><div class="n">${d.searchRaw}</div><div class="l">raw / regex</div><div class="s">text log formats</div></div>
      <div class="stat"><div class="n">${d.searchDelimited}</div><div class="l">delimited</div><div class="s">CSV / TSV</div></div>
      <div class="stat"><div class="n">${d.searchKvp}</div><div class="l">key=value</div><div class="s">kvp formats</div></div>
    </div>
    <p style="font-size:11.5px;color:var(--mut)">This library tracks the live Cribl Search datatypes: the <b>datatype-coverage</b> button in the header audits your Search group against it and reports what is new, changed or withdrawn upstream, and <b>Sync</b> imports the difference. It works in both run modes — on localhost the import is written to the app's parser file, and inside the Cribl UI it is stored with <i>this</i> app installation as a layer over the built-in library, so an imported parser is available to the wizard immediately and survives a reload without changing anything the app ships with.</p>

    <h3>Real log samples (resolution tiers 3-4 — see Chapter 3)</h3>
    <div class="stat-grid">
      <div class="stat"><div class="n">${d.sourceSamples+d.vendorSamples}</div><div class="l">Sources with a real log</div><div class="s">no AI needed to see the format</div></div>
      <div class="stat"><div class="n">${d.vendorEvents}</div><div class="l">Real event lines</div><div class="s">harvested vendor corpus</div></div>
      <div class="stat"><div class="n">${d.vendorAtFloor}</div><div class="l">Ready as-is</div><div class="s">&ge;10 events, no extension</div></div>
      <div class="stat"><div class="n">${d.vendorMerged}</div><div class="l">Multi-fixture</div><div class="s">several real shapes merged</div></div>
    </div>
    <p style="font-size:11.5px;color:var(--mut)">Harvested docs keep their upstream repo, commit and paths so every line stays traceable to its source, and ${d.vendorVerified} of them are <b>parser-verified</b> (the rest are sources we ship no parser for, kept on structure or provenance). Anything below 10 events is extended at request time, never in the store.</p>

    <h3>Destination format specs</h3>
    <div class="stat-grid">
      <div class="stat"><div class="n">${d.formatSpecs}</div><div class="l">Format specs</div><div class="s">golden-formats.json</div></div>
      <div class="stat"><div class="n">${d.formatFamilies}</div><div class="l">Families</div><div class="s">OCSF·CIM·ECS·ASIM·…</div></div>
      <div class="stat"><div class="n">${d.asimSchemas}</div><div class="l">ASIM schemas</div><div class="s">data-class variants</div></div>
      <div class="stat"><div class="n">${d.ocsfClasses}</div><div class="l">OCSF classes</div><div class="s">data-class variants</div></div>
    </div>
    <p style="font-size:11.5px;color:var(--mut)">Format families include CEF, CommonSecurityLog, CIM, OCSF, ECS, ASIM, Chronicle UDM, JSON and XSIAM — each with data-class variants — plus CrowdStrike NG SIEM, which has none (it ships the original <code>_raw</code>) (e.g. <code>ocsf#network</code>, <code>asim#dns</code>, <code>cim#endpoint</code>) chosen from the sample's data class.</p>
  </section>

  <footer>Cribl Pack Generator${` · build ${f}`} · onboarding &amp; scoring reference. This document mirrors the deterministic logic in the app (value coverage + golden-spec coverage + sample-shape matching). Stats are computed live from the bundled config; reasons shown on each card cite the exact values that were or weren't covered. <b>Download</b> saves this page as a single self-contained HTML file (no external assets) — the browser's own Save Page (Ctrl/Cmd+S) does the same.</footer>
</div>
<a class="totop" href="#contents">&uarr; Contents</a>
<script>
  // Progressive enhancement only: every jump link above is a plain anchor and works
  // with scripting disabled. The two buttons need script, so they stay hidden until
  // this runs — a dead button is worse than no button.
  (function () {
    var tools = document.getElementById('tools');
    if (tools) tools.style.display = 'flex';
    var dl = document.getElementById('dl');
    if (dl) dl.addEventListener('click', function () {
      // Serialize the live document: styles are inline and there are no external
      // assets, so the saved file is the whole reference, offline and shareable.
      var html = '<!DOCTYPE html>\\n' + document.documentElement.outerHTML;
      var url = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
      var a = document.createElement('a');
      a.href = url;
      a.download = ${JSON.stringify(`pack-generator-reference${`-build-${f}`}.html`)};
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url) }, 10000);
    });
    var pr = document.getElementById('pr');
    if (pr) pr.addEventListener('click', function () { window.print() });
  })();
<\/script>
</body></html>`;export{p as SCORING_DOC_HTML};