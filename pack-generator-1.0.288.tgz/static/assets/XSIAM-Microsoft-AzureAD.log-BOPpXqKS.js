var e=[{_raw:`{
    "data": {
      "CreationTime": "2026-01-19T13:18:18",
      "Id": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX",
      "Operation": "UserLoggedIn",
      "OrganizationId": "XXXXXXXXX-XXXX-XXXX-XXXXXXX-XXXXXXXXXXX",
      "RecordType": 15,
      "ResultStatus": "Success",
      "UserKey": "XXXXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXX",
      "UserType": 0,
      "Version": 1,
      "Workload": "AzureActiveDirectory",
      "ClientIP": "XXX.XXX.XXX.XXX",
      "ObjectId": "00000002-0000-0000-c000-000000000000",
      "UserId": "XXXXXXXXX@XXXXXXXXX.XXXXXXXXX.XXX",
      "AzureActiveDirectoryEventType": 1,
      "ExtendedProperties": [
        {
          "Name": "ResultStatusDetail",
          "Value": "Redirect"
        },
        {
          "Name": "UserAgent",
          "Value": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36"
        },
        {
          "Name": "RequestType",
          "Value": "Consent:Set"
        }
      ],
      "ModifiedProperties": [],
      "Actor": [
        {
          "ID": "XXXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXX",
          "Type": 0
        },
        {
          "ID": "XXXXXXXXX@XXXXXXXXX.XXXXXXXXX.XXX",
          "Type": 5
        }
      ],
      "ActorContextId": "XXXXXXXX-XXXX-XXXX-XXXXX-XXXXXXX",
      "ActorIpAddress": "XXX.XXX.XXX.XXX",
      "InterSystemsId": "XXXXXX-XXXX-XXXX-XXXX-XXXXXXX",
      "IntraSystemId": "XXXXXXX-XXXX-XXXX-XXXX-XXXXXX",
      "SupportTicketId": "",
      "Target": [
        {
          "ID": "00000002-0000-0000-c000-000000000000",
          "Type": 0
        }
      ],
      "TargetContextId": "XXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXX",
      "ApplicationId": "XXXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXX",
      "DeviceProperties": [
        {
          "Name": "OS",
          "Value": "MacOs"
        },
        {
          "Name": "BrowserType",
          "Value": "Chrome"
        },
        {
          "Name": "IsCompliant",
          "Value": "False"
        },
        {
          "Name": "IsCompliantAndManaged",
          "Value": "False"
        },
        {
          "Name": "SessionId",
          "Value": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
        }
      ],
      "ErrorNumber": "0"
    },
    "collector_ms": 1768828698000
  }`,_time:1768857498,cribl_breaker:`Break on newlines`}];export{e as default};