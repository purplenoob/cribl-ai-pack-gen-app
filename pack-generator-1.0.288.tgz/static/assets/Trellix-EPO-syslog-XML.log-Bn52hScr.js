var e=[{_raw:`<EPOEvent>
	<MachineInfo>
		<MachineName>THEGRANDTOUR</MachineName>
		<AgentGUID>{1234abcd-12ab-12ab-12ab-123456abcdef}</AgentGUID>
		<IPAddress>127.0.0.1</IPAddress>
		<OSName>Windows 11</OSName>
		<UserName>%rHammond%</UserName>
		<TimeZoneBias>000</TimeZoneBias>
		<RawMACAddress>0000000000AA</RawMACAddress>
	</MachineInfo>
	<SoftwareInfo ProductName=\\"Trellix Endpoint Security\\" ProductVersion=\\"10.7\\" ProductFamily=\\"TVD\\">
		<CommonFields>
			<Analyzer>JERM_CLAR_KSON</Analyzer>
			<AnalyzerName>Trellix Endpoint Security</AnalyzerName>
			<AnalyzerVersion>1.0</AnalyzerVersion>
			<AnalyzerHostName>XXXXXXFV18333</AnalyzerHostName>
			<AnalyzerDATVersion>0000.0</AnalyzerDATVersion>
			<AnalyzerEngineVersion>0000.0000</AnalyzerEngineVersion>
		</CommonFields>
		<Event>
			<EventID>21624</EventID>
			<Severity>0</Severity>
			<GMTTime>2024-02-16T02:06:00</GMTTime>
			<CommonFields>
				<AnalyzerDetectionMethod>Web Control download scanner task</AnalyzerDetectionMethod>
				<ThreatName>_</ThreatName>
				<ThreatType></ThreatType>
				<ThreatCategory>petrol.lory.exploxed</ThreatCategory>
				<ThreatHandled>0</ThreatHandled>
				<ThreatActionTaken>fled</ThreatActionTaken>
				<ThreatSeverity>9</ThreatSeverity>
			</CommonFields>
		</Event>
	</SoftwareInfo>
</EPOEvent>`,_time:1708049160,cribl_breaker:`EPO XML Events`},{_raw:`<DLPAGENT11111>
	<MachineInfo>
		<AgentGUID>{1234abcd-12ab-12ab-12ab-123456abcdef}</AgentGUID>
		<MachineName>THEGRANDTOUR</MachineName>
		<RawMACAddress>0000000000AA</RawMACAddress>
		<IPAddress>127.0.0.1</IPAddress>
		<AgentVersion>1.0.0.000</AgentVersion>
		<OSName>Windows 11</OSName>
		<TimeZoneBias>000</TimeZoneBias>
		<UserName>rhammond</UserName>
	</MachineInfo>
	<EventList ProductFamily=\\"Secure\\" ProductVersion=\\"1.1.1.1\\" ProductName=\\"McAfee DLP Endpoint\\">
		<Event>
			<EventID>021624</EventID>
			<Severity>0</Severity>
			<GMTTime>2024-01-17T01:07:00</GMTTime>
			<OPGData>db011598fabe10b54bf66dd334f620d6c448f6e7527cfda137e222e1b93ad0e09dc4e16265adf8edc583e41fa577b17627740721c4c1958d04a78e0fc82d14df</OPGData>
			<UserInfo>d3f86547a2caa4ad05c25818a3cd50054051a80f24f83352375eab6ab7a6ea466f4f2b845cc1060111634a38ee1b8552142783d8e79bed0539622283a32fb514</UserInfo>
			<ThreatName>TGT - Final Season</ThreatName>
			<PolicyName>The Sand Job</PolicyName>
			<TimeSZone>Eastern Daylight Time</TimeSZone>
		</Event>
	</EventList>
</DLPAGENT11111>  \\r"}`,_time:1705453620,cribl_breaker:`EPO XML Events`}];export{e as default};