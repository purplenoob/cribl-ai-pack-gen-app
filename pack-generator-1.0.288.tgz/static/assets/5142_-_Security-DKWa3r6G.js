var e=[{_time:1653637315,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 01:11:55 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5142
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=File Share
OpCode=Info
RecordNumber=665273364
Keywords=Audit Success
Message=A network share object was added.\r
	\r
Subject:\r
	Security ID:		SomeId\\SomeAccount\r
	Account Name:		SomeName\r
	Account Domain:		ACME\r
	Logon ID:		0x33693278\r
\r
Share Information:	\r
	Share Name:		\\\\*\\some_share\r
	Share Path:		C:\\someinstall`}];export{e as default};