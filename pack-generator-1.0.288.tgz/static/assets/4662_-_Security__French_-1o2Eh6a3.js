var e=[{_time:1653699275,cribl_breaker:`Break on newlines`,_raw:`05/28/2022 06:24:35 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4662
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Autres événements d’accès à l’objet
OpCode=Informations
RecordNumber=7821235029
Keywords=Succès de l’audit
Message=Une opération a été effectuée sur un objet.\r
\r
Sujet\xA0:\r
	ID de sécurité\xA0:		AUTORITE NT\\Système\r
	Nom du compte\xA0:		MYHOST$\r
	Domaine du compte\xA0:		ACME.COM\r
	ID d’ouverture de session\xA0:		0x3e7\r
\r
Objet\xA0:\r
	Serveur de l’objet\xA0:		WMI\r
	Type d’objet\xA0:		WMI Namespace\r
	Nom de l’objet\xA0:		ROOT\\CIMV2\\Security\\MicrosoftTpm\r
	ID du handle\xA0:		0x0\r
\r
Opération\xA0:\r
	Type d’opération\xA0:		Object Access\r
	Accès\xA0:		Accès spécifique inconnu (bit 0)\r
				\r
	Masque d’accès\xA0:		0x1\r
	Propriétés\xA0:		-\r
\r
Informations supplémentaires\xA0:\r
	Paramètre 1:		Local Read (GetObject)\r
	Paramètre 2\xA0:		ROOT\\CIMV2\\Security\\MicrosoftTpm:__ExtendedStatus`}];export{e as default};