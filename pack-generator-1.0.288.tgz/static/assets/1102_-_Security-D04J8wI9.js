var e=[{_time:1652990417,_raw:`05/20/2022 01:30:17 AM
LogName=Security
SourceName=Microsoft-Windows-Eventlog
EventCode=1102
EventType=4
Type=Information
ComputerName=MYHOST.acme.com
TaskCategory=Log clear
OpCode=Info
RecordNumber=100310011
Keywords=Audit Success
Message=The audit log was cleared.
Subject:
	Security ID:	DOMAIN\\jsmith
	Account Name:	jsmith
	Domain Name:	ACME
	Logon ID:	0x1234cc`}];export{e as default};