var e=[{_time:1653661195,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 07:49:55 PM
LogName=Application
SourceName=ShoreWare
EventCode=264
EventType=4
Type=Information
ComputerName=myhost.acme.com
TaskCategory=TMS
OpCode=None
RecordNumber=848226
Keywords=Classic
Message=A rogue IP Phone Call Agent has been detected that has established a control connection with an IP Phone.\r
IP Phone Details:\r
	IP Address:	10.1.2.3\r
	MAC Address:	DD0061E956C8\r
Call Agent Details:\r
	Config'd Agent:	10.1.2.3\r
	Rogue Agent:	10.1.2.3\r
The IP Phone in question may perioodically exhibit unexpected behavior due to this error condition.  This error can occur when a Call Agent switch has been replaced and the previous switch is still on-line, or possibly if an IP Phone has been moved from one ShoreWare IP Phone System to another.  To correct this the IP Phone should be deconfigured from the rogue Call Agent or the rogue Call Agent should be taken off-line.`}];export{e as default};