var e=[{_time:1653589903,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 12:01:43 AM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=4953\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
TaskCategory=MPSSVC Rule-Level Policy Change\r
OpCode=Info\r
RecordNumber=1232533028\r
Keywords=Audit Failure\r
Message=Windows Firewall ignored a rule because it could not be parsed.\r\r
	\r\r
Profile:	All\r\r
\r\r
Reason for Rejection:	A rule must include a valid direction\r\r
\r\r
Rule:\r\r
	ID:	SNMP-3\r\r
	Name:	Block any other traffic to and from SNMP service`}];export{e as default};