var e=[{_raw:` `,_lookup:`The kv.csv lookup table under the Pack's Knowledge/Lookups.  Select, '... Show more' to see it.
   KEY1                           KEY2             KEY3             KEY4
1: row1_column_1                  row1_column_2    row1_column_3    row1_column_4
2: Row2_Column_1                  Row2_Column_2    Row2_Column_3    Row2_Column_4
3: ROW3_COLUMN_1                  ROW3_COLUMN_2    ROW3_COLUMN_3    ROW3_COLUMN_4
4: row\\d+_.+                      row4_column_2    row4_column_3    row4_column_4
5: ro+                            Row5_Column_2    Row5_Column_3    Row5_Column_4
6: row\\d+_column_\\d+              ROW6_COLUMN_2    ROW6_COLUMN_3    ROW6_COLUMN_4
7: (?<KEY3>ROW\\d+_column_3)       ROW7_column_2    ROW7_column_3    ROW7_column_4`,_time:1697467265.798},{_raw:`Oct 24 2023 14:08:08 SNL-ASA-VPN-A01 : %ASA-6-302016: Teardown UDP connection 110577675 for Outside:10.123.123.123/53723(LOCAL\\Elastic) to Inside:10.233.123.123/53 duration 0:00:00 bytes 148 (zzzzzz)`,_time:1587157688,sourcetype:`cisco:asa`,cribl_breaker:`Break on newlines`}];export{e as default};