var e=[{_time:1665369041,cribl_breaker:`Break on newlines`,_raw:`10/10/2022 08:00:41 AM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=5633\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
TaskCategory=Other Logon/Logoff Events\r
OpCode=Info\r
RecordNumber=1235400\r
Keywords=Audit Success\r
Message=A request was made to authenticate to a wired network.\r\r
\r\r
Subject:\r\r
	Security ID:		-\r\r
	Account Name:		-\r\r
	Account Domain:		-\r\r
	Logon ID:		0x0\r\r
\r\r
Interface:\r\r
	Name:			Intel(R) Ethernet Connection (5) I219-LM\r\r
\r\r
Additional Information\r\r
	Reason Code:		The network does not support authentication (0x70003)\r\r
	Error Code:		0x0`}];export{e as default};