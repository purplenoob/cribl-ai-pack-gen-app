var e=[{_raw:`{
      "timestamp": 1765589102,
      "type": "admin_audit_logs",
      "user": "mscore@afos.io",
      "severity_level": 2,
      "audit_log_event": "SSO Login Successful",
      "supporting_data": {
        "data_type": "user",
        "data_values": [
          "mscore@afos.io"
        ]
      },
      "organization_unit": "AFOS",
      "ur_normalized": "mscore@afos.io",
      "count": 1,
      "_id": "0000018b7fd5e2534eaa00aaa",
      "details": [],
      "sAMAccountName": "",
      "ccl": "",
      "userPrincipalName": "Mike Score"
    }`,_time:1765589102,cribl_breaker:`Netskope API Ruleset`}];export{e as default};