var e=[{_time:1653631391,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 11:33:11 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4723
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=User Account Management
OpCode=Info
RecordNumber=316219169
Keywords=Audit Success
Message=An attempt was made to change an account's password.\r
\r
Subject:\r
	Security ID:		ACME\\12317890\r
	Account Name:		12317890\r
	Account Domain:		ACME\r
	Logon ID:		0x1FC18DFC\r
\r
Target Account:\r
	Security ID:		ACME\\12317890\r
	Account Name:		12317890\r
	Account Domain:		ACME\r
\r
Additional Information:\r
	Privileges		-`}];export{e as default};