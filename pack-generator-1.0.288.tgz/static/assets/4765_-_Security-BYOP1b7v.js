var e=[{_time:1665595313,cribl_breaker:`Break on newlines`,_raw:`10/12/2022 10:51:53 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4765
EventType=0
Type=Information
ComputerName=hyhost.acme.com
TaskCategory=User Account Management
OpCode=Info
RecordNumber=44789860288
Keywords=Audit Success
Message=SID History was added to an account.\r
\r
Subject:\r
	Security ID:		S-1-5-21-1234843080-1574357790-3623606500-222113\r
	Account Name:		SomeUser\r
	Account Domain:		ACME\r
	Logon ID:		0x123231D5A\r
\r
Target Account:\r
	Security ID:		S-1-5-21-1234843080-1574357790-3623606500-409141\r
	Account Name:		SomeUser\r
	Account Domain:		ACME\r
\r
Source Account:\r
	Security ID:		S-1-0-0\r
	Account Name:		acme.com\\SomeUser\r
\r
Additional Information:\r
	Privileges:		-\r
	SID List:			\r
		ACME\\SomeUser`}];export{e as default};