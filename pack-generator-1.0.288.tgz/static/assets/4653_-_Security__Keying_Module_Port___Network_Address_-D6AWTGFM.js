var e=[{_time:1653057437,cribl_breaker:[`Break on newlines`,`Break on newlines`],_raw:`05/20/2022 09:37:17 AM
LogName=Security
EventCode=4653
EventType=0
ComputerName=myhost.acme.com
SourceName=Microsoft Windows security auditing.
Type=Information
RecordNumber=203011263
Keywords=Audit Failure
TaskCategory=IPsec Main Mode
OpCode=Info
Message=An IPsec main mode negotiation failed.\r
\r
Local Endpoint:\r
	Local Principal Name:	-\r
	Network Address:	1.2.3.4\r
	Keying Module Port:	500\r
\r
Remote Endpoint:\r
	Principal Name:		-\r
	Network Address:	10.1.2.3\r
	Keying Module Port:	500\r
\r
Additional Information:\r
	Keying Module Name:	AuthIP\r
	Authentication Method:	Unknown authentication\r
	Role:			Responder\r
	Impersonation State:	Not enabled\r
	Main Mode Filter ID:	0\r
\r
Failure Information:\r
	Failure Point:		Local computer\r
	Failure Reason:		No policy configured\r
\r
	State:			No state\r
	Initiator Cookie:		6107f77b4ee9548a\r
	Responder Cookie:	bcb91236b9cb1e82`}];export{e as default};