var e=[{_time:1653647399,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 03:59:59 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5448
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Filtering Platform Policy Change
OpCode=Info
RecordNumber=1235911
Keywords=Audit Success
Message=A Windows Filtering Platform provider has been changed.\r
	\r
Subject:\r
	Security ID:		NT AUTHORITY\\SYSTEM\r
	Account Name:		NT AUTHORITY\\SYSTEM\r
\r
Process Information:\r
	Process ID:	1544\r
\r
Change Information:\r
	Change Type:	Add\r
\r
Provider Information:\r
	ID:		{B28AD79B-00BD-1234-95A6-8CF5E87AD934}\r
	Name:		Microsoft Corporation\r
	Type:		Not persistent`}];export{e as default};