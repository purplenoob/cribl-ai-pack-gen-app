var e=[{_time:1661886167,cribl_breaker:`Break on newlines`,_raw:`08/30/2022 12:02:47 PM\r
LogName=Security\r
SourceName=AD FS Auditing\r
EventCode=412\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
User=NOT_TRANSLATED\r
Sid=S-1-5-21-359538278-52765162-2211038576-184163\r
SidType=0\r
TaskCategory=Printers\r
OpCode=Info\r
RecordNumber=68106999\r
Keywords=Audit Success, Classic\r
Message=A token of type 'http://schemas.microsoft.com/ws/2006/05/servicemodel/tokens/SecureConversation' for relying party 'https://manage.acme.com/WarpAuthAPI' was successfully authenticated.  See audit 501 with the same Instance ID for caller identity. \r\r
\r\r
Instance ID: 8ab39d6a-76f6-40d9-8ed4-0f29d123d914 \r\r
\r\r
Activity ID: f42c9d36-b836-123a-311d-0080011000d4`,source:`WinEventLog:Security`,host:`myhost.acme.com`,sourcetype:`WinEventLog:Security`,index:`wineventlog`}];export{e as default};