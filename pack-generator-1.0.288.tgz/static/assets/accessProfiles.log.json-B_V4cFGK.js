var e=[{_raw:`{
    "id": "13b856dd9a264206954b63ecbb57a853",
    "name": "Cloud Eng",
    "description": "Cloud Eng",
    "source": {
      "id": "5c71ff71195b4794a0b87e7cf36fb017",
      "name": "Active Directory"
    },
    "entitlements": [
      {
        "hasPermissions": false,
        "attribute": "memberOf",
        "value": "CN=Cloud Engineering,DC=sailpoint,DC=com",
        "schema": "group",
        "privileged": false,
        "id": "7372eaddd75749bd89a2e76a363eb891",
        "name": "Cloud Engineering",
        "description": "Cloud Engineering"
      }
    ],
    "entitlementCount": 1,
    "segments": [],
    "segmentCount": 0,
    "apps": [],
    "created": "2024-09-16T17:41:25.000Z",
    "modified": "2024-09-16T19:30:54.000Z",
    "synced": "2025-02-12T06:32:40.156Z",
    "enabled": true,
    "requestable": true,
    "requestCommentsRequired": false,
    "owner": {
      "id": "ff8081815757d36a015757d42e56031e",
      "name": "SailPoint Support",
      "type": "IDENTITY",
      "email": "cloud-support@sailpoint.com"
    },
    "tags": [
      "TAG_1",
      "TAG_2"
    ],
    "_type": "accessprofile",
    "type": "accessprofile",
    "pod": "pod01-useast1",
    "org": "org-name",
    "_version": "v2"
  }`,_time:1760744443.16,cribl_breaker:[`json`,`ndjson`]}];export{e as default};