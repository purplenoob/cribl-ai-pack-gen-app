var e=[{_raw:`{
    "device_id": "XXXXXXXXX",
    "cid": "XXXXXXXXX",
    "agent_load_flags": "16",
    "agent_local_time": "2026-01-20T05:29:37.281Z",
    "agent_version": "7.32.20403.0",
    "bios_manufacturer": "VMware, Inc.",
    "bios_version": "VMW71.00V.21100432.B64.2301110304",
    "build_number": "22631",
    "config_id_base": "65994767",
    "config_id_build": "20403",
    "config_id_platform": "3",
    "cpu_signature": "263921",
    "cpu_vendor": "0",
    "external_ip": "XXX.XXX.XXX.XXX",
    "mac_address": "XX-XX-XX-XX-XX-XX",
    "hostname": "XXXXXXXXX",
    "filesystem_containment_status": "normal",
    "first_seen": "2024-09-25T19:02:00Z",
    "last_login_timestamp": "2025-01-15T05:05:20Z",
    "last_login_user": "XXXXXXXXX",
    "last_login_user_sid": "S-1-5-21-XXXXXXXXXX-XXXXXXXX-XXXXXXXXX-XXXX",
    "last_seen": "2026-01-21T16:50:11Z",
    "local_ip": "XXX.XXX.XXX.XXX",
    "machine_domain": "",
    "major_version": "10",
    "minor_version": "0",
    "os_version": "Windows 11",
    "os_build": "22631",
    "platform_id": "0",
    "platform_name": "Windows",
    "policies": [
      {
        "policy_type": "prevention",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXX",
        "assigned_date": "2025-02-04T19:59:48.365054525Z",
        "applied_date": "2025-02-04T20:00:52.164236745Z",
        "rule_groups": []
      }
    ],
    "reduced_functionality_mode": "no",
    "rtr_state": "enabled",
    "device_policies": {
      "prevention": {
        "policy_type": "prevention",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXX",
        "assigned_date": "2025-02-04T19:59:48.365054525Z",
        "applied_date": "2025-02-04T20:00:52.164236745Z",
        "rule_groups": []
      },
      "sensor_update": {
        "policy_type": "sensor-update",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "tagged|11;0",
        "assigned_date": "2026-01-20T13:27:42.36963262Z",
        "applied_date": "2026-01-20T13:31:05.323377035Z",
        "uninstall_protection": "DISABLED"
      },
      "device_control": {
        "policy_type": "device-control",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": false,
        "settings_hash": "XXXXXXXX",
        "assigned_date": "2025-01-09T17:56:48.606244667Z",
        "applied_date": null
      },
      "global_config": {
        "policy_type": "globalconfig",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXX",
        "assigned_date": "2026-01-20T13:27:42.369536676Z",
        "applied_date": "2026-01-20T13:35:39.207767777Z"
      },
      "remote_response": {
        "policy_type": "remote-response",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXX",
        "assigned_date": "2024-09-25T19:03:55.708455026Z",
        "applied_date": "2024-09-25T19:05:09.127541459Z"
      },
      "firewall": {
        "policy_type": "firewall",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXX",
        "assigned_date": "2024-09-25T19:03:55.708696242Z",
        "applied_date": "2024-09-25T19:05:09.489437223Z",
        "rule_set_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
      },
      "system-tray": {
        "policy_type": "system-tray",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2024-09-25T20:04:32.041690686Z",
        "applied_date": "2024-09-25T20:07:06.60429873Z"
      },
      "sca": {
        "policy_type": "sca",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2025-10-08T11:51:53.378976943Z",
        "applied_date": "2025-10-08T11:52:28.022418907Z"
      },
      "data-protection": {
        "policy_type": "data-protection",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2025-12-10T16:07:01.520667683Z",
        "applied_date": "2025-12-10T16:08:40.446875368Z"
      },
      "it-automation": {
        "policy_type": "it-automation",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2026-01-08T13:42:40.082808159Z",
        "applied_date": "2026-01-08T13:47:12.631788228Z"
      },
      "host-retention": {
        "policy_type": "host-retention",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2024-09-25T19:03:55.708748602Z",
        "applied_date": "2024-09-25T19:05:09.527763106Z"
      },
      "browser-extension": {
        "policy_type": "browser-extension",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2026-01-21T13:14:11.70857975Z",
        "applied_date": "2026-01-21T13:43:22.480119569Z"
      },
      "network-scan-content": {
        "policy_type": "network-scan-content",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2025-10-08T11:51:53.378846364Z",
        "applied_date": "2025-10-08T11:52:28.280815464Z"
      },
      "content-update": {
        "policy_type": "content-update",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXX",
        "assigned_date": "2025-04-17T01:49:27.954336741Z",
        "applied_date": "2025-04-17T01:49:27.954336741Z"
      },
      "exposure-management": {
        "policy_type": "exposure-management",
        "policy_id": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "applied": true,
        "settings_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "assigned_date": "2026-01-21T13:14:11.708273767Z",
        "applied_date": "2026-01-21T13:43:22.337150334Z"
      }
    },
    "groups": [
      "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    ],
    "group_hash": "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    "product_type": "1",
    "product_type_desc": "Workstation",
    "provision_status": "Provisioned",
    "serial_number": "XXXXXXXXX",
    "service_pack_minor": "0",
    "pointer_size": "8",
    "status": "normal",
    "system_manufacturer": "VMware, Inc.",
    "system_product_name": "VMware7,1",
    "tags": [],
    "modified_timestamp": "2026-01-21T17:05:01Z",
    "meta": {
      "version": "66111",
      "version_string": "2:397047388"
    },
    "kernel_version": "10.0.22631.6199",
    "os_product_name": "Windows 11 Pro",
    "chassis_type": "1",
    "chassis_type_desc": "Other",
    "last_reboot": "2025-12-11T01:33:00Z",
    "pod_labels": [],
    "pod_annotations": [],
    "connection_ip": "XXX.XXX.XXX.XXX",
    "default_gateway_ip": "XXX.XXX.XXX.XXX",
    "connection_mac_address": "XX-XX-XX-XX-XX-XX"
  }`,_time:1768886977.281,cribl_breaker:`Break on newlines`}];export{e as default};