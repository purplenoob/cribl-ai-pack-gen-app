var e=[{_time:1653662109,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 08:05:09 PM
LogName=Application
SourceName=ShadowProtectSvc
EventCode=1121
EventType=2
Type=Error
ComputerName=myhost.acme.com
User=NOT_TRANSLATED
Sid=S-1-5-18
SidType=0
TaskCategory=The operation completed successfully.
OpCode=None
RecordNumber=28535917
Keywords=Classic
Message=Backup status: failed\r
Image file: \\\\ab-back01\\Backups\\Servers\\SY-FS01\\MYHOST_C_VOL\r
Log file: C:\\Program Files (x86)\\StorageCraft\\ShadowProtect\\Logs\\{98BFAA1C-6D88-4DB5-9EE9-DBCBA9F0123F}.txt\r
Start time: 27/05/2022 8:05:00 PM\r
Module: service\r
Code: 509\r
Message: Cannot get access to destination object`}];export{e as default};