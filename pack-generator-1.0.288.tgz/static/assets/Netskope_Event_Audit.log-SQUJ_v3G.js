var e=[{_raw:`{
      "type": "admin_audit_logs",
      "supporting_data": {
        "data_values": [
          400,
          "POST",
          "/api/v2/steering/ipsec/tunnels",
          "trid=ceeoed298edji6dbe9qg"
        ],
        "data_type": "steering"
      },
      "timestamp": 1711378583,
      "severity_level": 2,
      "user": "Alliance-EU Token",
      "audit_log_event": "Rest API V2 Call",
      "organization_unit": "",
      "ur_normalized": "alliance-eu token",
      "count": 1,
      "_id": "395c302cc6ff02d2538fbe3d",
      "details": [],
      "sAMAccountName": "",
      "ccl": "",
      "userPrincipalName": ""
    }`,_time:1711378583,cribl_breaker:`netskope`},{_raw:`{
      "type": "admin_audit_logs",
      "supporting_data": {
        "data_values": [
          201,
          "POST",
          "/api/v2/steering/ipsec/tunnels",
          "trid=ceeoeh9ghfjeae51euu0"
        ],
        "data_type": "steering"
      },
      "timestamp": 1711378601,
      "severity_level": 2,
      "user": "Alliance-EU Token",
      "audit_log_event": "Rest API V2 Call",
      "organization_unit": "",
      "ur_normalized": "alliance-eu token",
      "count": 1,
      "_id": "f963839068fb07adbd63d836",
      "details": [],
      "sAMAccountName": "",
      "ccl": "",
      "userPrincipalName": ""
    }`,_time:1711378601,cribl_breaker:`netskope`},{_raw:`{
      "timestamp": 1711381120,
      "type": "admin_audit_logs",
      "user": "xtesta@networks.com",
      "severity_level": 2,
      "audit_log_event": "Logout Successful",
      "supporting_data": {
        "data_type": "reason",
        "data_values": [
          "Logged out due to inactivity"
        ]
      },
      "organization_unit": "",
      "ur_normalized": "xtesta@networks.com",
      "count": 1,
      "_id": "0ccd09d7aeb88475054cbd34",
      "details": [],
      "sAMAccountName": "",
      "ccl": "",
      "userPrincipalName": ""
    }`,_time:1711381120,cribl_breaker:`netskope`},{_raw:`{
      "timestamp": 1711387341,
      "type": "admin_audit_logs",
      "user": "leeroy.jenkins@test.com",
      "severity_level": 2,
      "audit_log_event": "SSO Login Successful",
      "supporting_data": {
        "data_type": "user",
        "data_values": [
          "leeroy.jenkins@test.com"
        ]
      },
      "organization_unit": "",
      "ur_normalized": "leeroy.jenkins@test.com",
      "count": 1,
      "_id": "1efbb18b7fd5e2534e5300ce",
      "details": [],
      "sAMAccountName": "",
      "ccl": "",
      "userPrincipalName": ""
    }`,_time:1711387341,cribl_breaker:`netskope`}];export{e as default};