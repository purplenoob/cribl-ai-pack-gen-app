var e=[{_time:1654412446,cribl_breaker:`Break on newlines`,_raw:`06/05/2022 12:30:46 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5888
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=System Integrity
OpCode=Info
RecordNumber=123987855
Keywords=Audit Success
Message=An object in the COM+ Catalog was modified.\r
\r
Subject:\r
	Security ID:		ABC001\\jsmith\r
	Account Name:		jsmith\r
	Account Domain:		ABC001\r
	Logon ID:		0x123F9470\r
\r
Object:\r
	COM+ Catalog Collection:	LocalComputer\r
	Object Name:			\r
		Name = ABC001\r
	Object Properties Modified:	\r
		<null>`}];export{e as default};