var e=[{_raw:`{
   "device_id": "6baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
   "cid": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
   "agent_load_flags": "1",
   "agent_local_time": "2025-07-03T13:35:04.682Z",
   "agent_version": "7.25.19706.0",
   "bios_manufacturer": "Dell Inc.",
   "bios_version": "A20",
   "build_number": "19045",
   "config_id_base": "65994767",
   "config_id_build": "19706",
   "config_id_platform": "3",
   "cpu_signature": "198339",
   "cpu_vendor": "0",
   "external_ip": "10.10.10.10",
   "mac_address": "bb-bb-bb-bb-bb-81",
   "hostname": "HOSTY",
   "host_hidden_status": "visible",
   "filesystem_containment_status": "normal",
   "first_seen": "2021-03-04T07:27:11Z",
   "last_login_timestamp": "2025-07-03T17:35:24Z",
   "last_login_user": "user1",
   "last_login_user_sid": "S-1-5-21-111-111-111-1111",
   "last_seen": "2025-07-03T17:35:12Z",
   "local_ip": "10.10.10.10",
   "machine_domain": "ds.companyname.com",
   "major_version": "10",
   "minor_version": "0",
   "os_version": "Windows 10",
   "os_build": "19045",
   "ou": [
    "Computers",
    "City_Name",
    "MachineAccounts"
   ],
   "platform_id": "0",
   "platform_name": "Windows",
   "policies": [
    {
     "policy_type": "prevention",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbba1",
     "applied": true,
     "settings_hash": "2cf956e6",
     "assigned_date": "2024-12-05T00:07:15.289026084Z",
     "applied_date": "2024-12-05T00:13:13.803257562Z",
     "rule_groups": []
    }
   ],
   "reduced_functionality_mode": "no",
   "rtr_state": "enabled",
   "device_policies": {
    "prevention": {
     "policy_type": "prevention",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbba1",
     "applied": true,
     "settings_hash": "2cf956e6",
     "assigned_date": "2024-12-05T00:07:15.289026084Z",
     "applied_date": "2024-12-05T00:13:13.803257562Z",
     "rule_groups": []
    },
    "sensor_update": {
     "policy_type": "sensor-update",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbb2",
     "applied": true,
     "settings_hash": "tagged|1;101",
     "assigned_date": "2025-06-19T11:21:25.882366186Z",
     "applied_date": "2025-06-19T11:27:15.65724673Z",
     "uninstall_protection": "ENABLED"
    },
    "device_control": {
     "policy_type": "device-control",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbb21",
     "applied": true,
     "settings_hash": "41f96d0f",
     "assigned_date": "2025-04-03T13:08:26.260066028Z",
     "applied_date": "2025-06-05T18:07:26.769583755Z"
    },
    "global_config": {
     "policy_type": "globalconfig",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbb11",
     "applied": false,
     "settings_hash": "93d411c8",
     "assigned_date": "2025-06-24T13:29:55.348621171Z",
     "applied_date": null
    },
    "remote_response": {
     "policy_type": "remote-response",
     "policy_id": "0000000000000001",
     "applied": true,
     "settings_hash": "f472bd8e",
     "assigned_date": "2024-02-06T03:58:56.801778859Z",
     "applied_date": "2024-02-06T03:59:38.907423614Z"
    },
    "firewall": {
     "policy_type": "firewall",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbb111",
     "applied": true,
     "settings_hash": "50994d5a",
     "assigned_date": "2024-05-19T19:54:17.217388119Z",
     "applied_date": "2024-05-19T20:03:31.242625427Z",
     "rule_set_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbb111"
    },
    "jumpcloud": {
     "policy_type": "jumpcloud",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
     "applied": true,
     "settings_hash": "0aec295a677907c6e4de672edf1f172d2cefcc5ca96ed2b5e56f4d6745289694",
     "assigned_date": "2022-07-15T18:09:12.962796969Z",
     "applied_date": "2023-08-15T00:04:35.893830646Z"
    },
    "system-tray": {
     "policy_type": "system-tray",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
     "applied": true,
     "settings_hash": "d85de5cdab609fc07504cc24a67b61a3b23aea0c26dbcc0bb9e34dc8f79d716b",
     "assigned_date": "2023-08-01T23:13:52.374235545Z",
     "applied_date": "2023-08-01T23:16:04.615777746Z"
    },
    "it-automation": {
     "policy_type": "it-automation",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbbb1",
     "applied": true,
     "settings_hash": "2afb36a4d294afef605e9cb02740c2ea36250edef2c074d4a250ef039b88ea98",
     "assigned_date": "2025-02-02T05:59:39.543445966Z",
     "applied_date": "2025-02-02T06:02:33.632846165Z"
    },
    "host-retention": {
     "policy_type": "host-retention",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbbb2",
     "applied": true,
     "settings_hash": "c43a9c6a3265800539e5576356076755250c237d2eb214a7314007bfb2c1026a",
     "assigned_date": "2025-03-18T14:28:01.555576616Z",
     "applied_date": "2025-03-18T14:55:15.656237083Z"
    },
    "content-update": {
     "policy_type": "content-update",
     "policy_id": "abbbbbbbbbbbbbbbbbbbbbbbbbbbbb3",
     "applied": true,
     "settings_hash": "6877622580887221275",
     "assigned_date": "2025-04-17T00:21:01.225845064Z",
     "applied_date": "2025-04-17T00:21:01.225845064Z"
    }
   },
   "groups": [
    "0000000000000001"
   ],
   "group_hash": "6a50b0452e1616496537259e11db64765383cfece76904f6be5e5cfd72508e85",
   "product_type": "1",
   "product_type_desc": "Workstation",
   "provision_status": "Provisioned",
   "serial_number": "B42A42",
   "service_pack_major": "0",
   "service_pack_minor": "0",
   "pointer_size": "8",
   "site_name": "DOMAIN",
   "status": "normal",
   "system_manufacturer": "Dell Inc.",
   "system_product_name": "OptiPlex 8088 AIO",
   "tags": [
    "FalconGroupingTags/DiagnosticCenter"
   ],
   "modified_timestamp": "2025-07-03T17:36:42Z",
   "meta": {
    "version": "89913",
    "version_string": "8:29104736232"
   },
   "kernel_version": "10.0.19045.5965",
   "os_product_name": "Windows 10 Enterprise",
   "chassis_type": "13",
   "chassis_type_desc": "Desktop",
   "last_reboot": "2025-07-03T17:34:49Z",
   "pod_labels": [],
   "pod_annotations": [],
   "connection_ip": "10.10.10.10",
   "default_gateway_ip": "10.10.10.1",
   "connection_mac_address": "bb-bb-bb-bb-bb-81"
  }`,_time:1755133767.72,cribl_breaker:`ndjson`}];export{e as default};