var e=[{_raw:`{
      "object": "organization.project",
      "id": "proj_srN6lHLnKo5rN7l7aqwlBsKn",
      "name": "Default project",
      "created_at": 1721414463,
      "archived_at": null,
      "status": "active"
    }`,host:`ip-10-255-9-252`,source:`https://api.openai.com/v1/organization/projects`,_time:1721414463,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]},{_raw:`{
      "object": "organization.project",
      "id": "proj_aabR3lVvwrXsubDm4h7hQ3Dl",
      "name": "SDET",
      "created_at": 1742852060,
      "archived_at": null,
      "status": "active"
    }`,host:`ip-10-255-9-252`,source:`https://api.openai.com/v1/organization/projects`,_time:1742852060,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]}];export{e as default};