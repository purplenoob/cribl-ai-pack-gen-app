var e=[{_time:1661886168,cribl_breaker:`Break on newlines`,_raw:`08/30/2022 12:02:48 PM\r
LogName=Security\r
SourceName=AD FS Auditing\r
EventCode=501\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
User=NOT_TRANSLATED\r
Sid=S-1-5-21-359538278-52765162-2211038576-184163\r
SidType=0\r
TaskCategory=Printers\r
OpCode=Info\r
RecordNumber=68107057\r
Keywords=Audit Success, Classic\r
Message=More information for the event entry with Instance ID 1a36f933-7376-12d8-910a-511e1e955afb. There may be more events with the same Instance ID with more information. \r\r
\r\r
Instance ID: \r\r
1a36f933-7376-44d8-910a-511e1e955afb \r\r
 \r\r
Caller identity: \r\r
http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant \r\r
2022-08-30T19:02:48.425Z \r\r
http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod \r\r
http://schemas.microsoft.com/ws/2008/06/identity/authenticationmethod/password \r\r
http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier \r\r
f9b31a3c-9d79-49df-a3cc-a49574d32e32 \r\r
http://schemas.microsoft.com/ws/2014/01/identity/claims/anchorclaimtype \r\r
http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier \r\r
http://schemas.microsoft.com/2014/01/clientcontext/claims/appid \r\r
f9b31a3c-9d79-49df-a3cc-a49574d32e32 \r\r
http://schemas.microsoft.com/2014/01/clientcontext/claims/apptype \r\r
Confidential \r\r
http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-endpoint-absolute-path \r\r
/adfs/oauth2/token \r\r
http://schemas.microsoft.com/ws/2012/01/insidecorporatenetwork \r\r
true \r\r
http://schemas.microsoft.com/2012/01/requestcontext/claims/client-request-id \r\r
6e61ee28-df98-4ba4-ed08-00800124003f \r\r
http://schemas.microsoft.com/2012/01/requestcontext/claims/x-ms-client-ip \r\r
10.1.2.3`,source:`WinEventLog:Security`,host:`myhost.acme.com`,sourcetype:`WinEventLog:Security`,index:`wineventlog`}];export{e as default};