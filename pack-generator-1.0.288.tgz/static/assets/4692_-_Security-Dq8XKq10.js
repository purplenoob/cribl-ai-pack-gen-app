var e=[{_time:1658548053,cribl_breaker:`Break on newlines`,_raw:`07/23/2022 09:17:33 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4692
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=DPAPI Activity
OpCode=Info
RecordNumber=2405640610
Keywords=Audit Failure
Message=Backup of data protection master key was attempted.\r
\r
Subject:\r
	Security ID:		ACME\\SomeUser\r
	Account Name:		SomeAccount\r
	Account Domain:		ACME\r
	Logon ID:		0xa6bc467d\r
\r
Key Information:\r
	Key Identifier:	512e581b-c1ab-4eca-a09f-b123e0fe8a2f\r
	Recovery Server:	\r
	Recovery Key ID:	\r
\r
Status Information:\r
	Status Code:	0x5`}];export{e as default};