var e=[{_time:1653530680,cribl_breaker:`Break on newlines`,_raw:`05/26/2022 07:34:40 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5441
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Filtering Platform Policy Change
OpCode=Info
RecordNumber=2202413
Keywords=Audit Success
Message=The following filter was present when the Windows Filtering Platform Base Filtering Engine started.\r
\r
Provider Information:	\r
	ID:		{AB12A9D2-1233-497A-B84E-A1C47AB952D5}\r
	Name:		CrowdStrike WFP Provider\r
\r
Filter Information:\r
	ID:		{A1236155-FD4E-4838-0F00-000000000000}\r
	Name:		CrowdStrike WFP Filter\r
	Type:		Boot-time\r
	Run-Time ID:	123731\r
\r
Layer Information:\r
	ID:		{C12D57D1-05A7-4C12-904F-7FBCEEE60E82}\r
	Name:		ALE Connect v4 Layer\r
	Run-Time ID:	48\r
	Weight:		1235843009213693958\r
	\r
Additional Information:\r
	Conditions:	
	Condition ID:	{0c1ba1af-1234-453f-af22-a8f123ac775b}
	Match value:	In range
	Condition value:	0xc1ea - 0xc1ea

	Condition ID:	{1231ef2b-623e-4f9a-8cb1-6e79b806b9a7}
	Match value:	Equal to
	Condition value:	0x06

	Condition ID:	{123ce23b-5167-435c-86d7-e123684aa80c}
	Match value:	No flags set
	Condition value:	0x00000001
\r
	Filter Action:	Permit\r
	Callout ID:	{00000000-0000-0000-0000-000000000000}\r
	Callout Name:	-`}];export{e as default};