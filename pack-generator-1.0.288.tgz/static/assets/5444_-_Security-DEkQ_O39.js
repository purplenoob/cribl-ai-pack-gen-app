var e=[{_time:1653530680,cribl_breaker:`Break on newlines`,_raw:`05/26/2022 07:34:40 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5444
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Filtering Platform Policy Change
OpCode=Info
RecordNumber=1232441
Keywords=Audit Success
Message=The following sub-layer was present when the Windows Filtering Platform Base Filtering Engine started.\r
	\r
Provider ID:	{00000000-0000-0000-0000-000000000000}\r
Provider Name:	-\r
Sub-layer ID:	{C1236155-FD4E-4838-A051-33FFC83F5407}\r
Sub-layer Name:	CSSUB99\r
Sub-layer Type:	Persistent\r
Weight:		12365`}];export{e as default};