var e=[{_time:1653636838,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 01:03:58 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4947
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=MPSSVC Rule-Level Policy Change
OpCode=Info
RecordNumber=655613381
Keywords=Audit Success
Message=A change was made to the Windows Firewall exception list. A rule was modified.\r
	\r
Profile Changed:	Domain\r
\r
Modified Rule:\r
	Rule ID:	{FF841234-D7ED-4394-85C8-9AF72470F10A}\r
	Rule Name:	@FirewallAPI.dll,-12303`}];export{e as default};