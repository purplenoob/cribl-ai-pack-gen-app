var e=[{_time:1661886167,cribl_breaker:`Break on newlines`,_raw:`08/30/2022 12:02:47 PM\r
LogName=Security\r
SourceName=AD FS Auditing\r
EventCode=1031\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
User=NOT_TRANSLATED\r
Sid=S-1-5-21-359538278-52765162-1231038576-184163\r
SidType=0\r
TaskCategory=Printers\r
OpCode=Info\r
RecordNumber=68107009\r
Keywords=Audit Success, Classic\r
Message=An OAuth access token response using Client Credentials flow was successfully issued to client '72e8f123-66c6-47e0-a5fe-db08dfbed491' for the relying party 'https://myhost.acme.com/WarpAuthAPI'. \r\r
\r\r
Activity ID: f42c9d36-b836-445a-123d-0080011000d4 \r\r
\r\r
Request Details: \r\r
    Date And Time: 2022-08-30 19:02:47 \r\r
    Client IP: 10.183.99.235 \r\r
    Client Identifier: 72e8f008-66c6-47e0-a5fe-db08dfbed123 \r\r
    Resource: https://manage.acme.com/WarpAuthAPI`,source:`WinEventLog:Security`,host:`myhost.acme.com`,sourcetype:`WinEventLog:Security`,index:`wineventlog`}];export{e as default};