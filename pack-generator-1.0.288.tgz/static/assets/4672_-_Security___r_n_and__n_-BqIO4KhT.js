var e=[{_time:1653073056,cribl_breaker:`Break on newlines`,_raw:`05/20/2022 01:57:36 PM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4672
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Special Logon
OpCode=Info
RecordNumber=102091836
Keywords=Audit Success
Message=Special privileges assigned to new logon.\r
\r
Subject:\r
	Security ID:		NT AUTHORITY\\SYSTEM\r
	Account Name:		SomeAccount\r
	Account Domain:		ACME\r
	Logon ID:		0x39B762EF\r
\r
Privileges:		SeSecurityPrivilege\r
			SeBackupPrivilege\r
			SeRestorePrivilege\r
			SeTakeOwnershipPrivilege\r
			SeDebugPrivilege\r
			SeSystemEnvironmentPrivilege\r
			SeLoadDriverPrivilege\r
			SeImpersonatePrivilege`},{_time:1663278711,cribl_breaker:`Break on newlines`,_raw:`09/15/2022 02:51:51 PM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=4672\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
TaskCategory=Special Logon\r
OpCode=Info\r
RecordNumber=100818187\r
Keywords=Audit Success\r
Message=Special privileges assigned to new logon.\r\r
\r\r
Subject:\r\r
	Security ID:		NT AUTHORITY\\SYSTEM\r\r
	Account Name:		SomeAccount$\r\r
	Account Domain:		ACME\r\r
	Logon ID:		0x5E36BE9\r\r
\r\r
Privileges:		SeSecurityPrivilege\r\r
			SeBackupPrivilege\r\r
			SeRestorePrivilege\r\r
			SeTakeOwnershipPrivilege\r\r
			SeDebugPrivilege\r\r
			SeSystemEnvironmentPrivilege\r\r
			SeLoadDriverPrivilege\r\r
			SeImpersonatePrivilege\r\r
			SeDelegateSessionUserImpersonatePrivilege`}];export{e as default};