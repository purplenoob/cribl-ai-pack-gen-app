var e=[{_raw:`[
  {
    "actor": {
      "applicationInfo": {
        "impersonation": true,
        "oauthClientId": "XXXXXXXXXXX"
      },
      "callerType": "USER",
      "email": "XXXXXXXXX@XXXXXXXXX.XXX",
      "profileId": "XXXXXXXXXXXXXXXXXXXX"
    },
    "etag": "\\"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\\"",
    "events": [
      {
        "name": "delete_group",
        "parameters": [
          {
            "name": "group_id",
            "value": "XXXXXXXXX@XXXXXXXXX.XXX"
          }
        ],
        "resourceIds": [
          "groups/XXXXXXXXX"
        ],
        "type": "moderator_action"
      }
    ],
    "id": {
      "applicationName": "groups_enterprise",
      "customerId": "XXXXXXXXX",
      "time": "2026-01-21T21:19:22.839Z",
      "uniqueQualifier": "XXXXXXXXXXXXXXXXXXXXXX"
    },
    "ipAddress": "XXX.XXX.XXX.XXX",
    "kind": "admin#reports#activity",
    "networkInfo": {
      "ipAsn": [
        0,
        15169
      ],
      "regionCode": "US",
      "subdivisionCode": "US-IA"
    },
    "resourceDetails": [
      {
        "id": "groups/XXXXXXXXX",
        "title": "XXXXXXXXX@XXXXXXXXX.XXX",
        "type": "GROUP"
      }
    ]
  }`,_time:1773857992.383,cribl_breaker:`Break on newlines`},{_raw:`]`,_time:1773857992.383,cribl_breaker:`Break on newlines`}];export{e as default};