var e=[{_time:1653424947,cribl_breaker:`Break on newlines`,_raw:`05/25/2022 08:44:23 AM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=5137\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
TaskCategory=Directory Service Changes\r
OpCode=Info\r
RecordNumber=1234507823\r
Keywords=Audit Success\r
Message=A directory service object was created.\r\r
	\r\r
Subject:\r\r
	Security ID:		ACME\\SOMEWORD$\r\r
	Account Name:		SOMENAME$\r\r
	Account Domain:		ACME\r\r
	Logon ID:		0x33D29C029\r\r
	\r\r
Directory Service:\r\r
	Name:	acme.com\r\r
	Type:	Active Directory Domain Services\r\r
	\r\r
Object:\r\r
DN:	CN=2022-05-24T14:42:27-06:00{77CD2307-8E3F-4B91-9D28-D6108F3F36BC}CN=ACME,OU=Workstations,OU=Someplace,DC=acme,DC=com\r
GUID:	CN=2022-05-24T14:42:27-06:00{77CD2307-8E3F-4B91-9D28-D6108F3F36BC}CN=SOMEWORD,OU=Workstations,OU=Someplace,DC=acme,DC=com\r
	Class:	msFVE-RecoveryInformation\r\r
	\r\r
Operation:\r\r
	Correlation ID:	{3AC2BC7D-3056-4937-84C0-8B2B4EFBFB81}\r
	Application Correlation ID:	-`}];export{e as default};