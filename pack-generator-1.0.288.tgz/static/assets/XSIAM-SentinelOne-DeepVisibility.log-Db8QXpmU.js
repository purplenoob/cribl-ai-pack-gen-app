var e=[{_raw:`{
    "eventVersion": "1.08",
    "userIdentity": {
      "type": "AssumedRole",
      "principalId": "XXXXXXXXXXXXXXXXXXXXX:XXXXXXXXX",
      "arn": "arn:aws:sts::XXXXXXXXXXXX:assumed-role/XXXXXXXXX/XXXXXXXXX",
      "accountId": "XXXXXXXXXXXX",
      "accessKeyId": "XXXXXXXXXXXXXXXXXXXXX",
      "sessionContext": {
        "sessionIssuer": {
          "type": "Role",
          "principalId": "XXXXXXXXXXXXXXXXXXXXX",
          "arn": "arn:aws:iam::XXXXXXXXXXXX:role/XXXXXXXXX",
          "accountId": "XXXXXXXXXXXX",
          "userName": "XXXXXXXXX"
        },
        "webIdFederationData": {},
        "attributes": {
          "creationDate": "2026-01-27T00:45:13Z",
          "mfaAuthenticated": "false"
        }
      }
    },
    "eventTime": "2026-01-27T01:48:54Z",
    "eventSource": "XXXXXXXXX.amazonaws.com",
    "eventName": "ListRepositories",
    "awsRegion": "eu-west-1",
    "sourceIPAddress": "XXX.XXX.XXX.XXX",
    "userAgent": "Vert.x-WebClient/4.5.13",
    "requestParameters": null,
    "responseElements": null,
    "requestID": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX",
    "eventID": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXX",
    "readOnly": true,
    "eventType": "AwsApiCall",
    "managementEvent": true,
    "recipientAccountId": "XXXXXXXXXXXX",
    "eventCategory": "Management",
    "tlsDetails": {
      "tlsVersion": "TLSv1.3",
      "cipherSuite": "TLS_AES_128_GCM_SHA256",
      "clientProvidedHostHeader": "XXXXXXXXX.eu-west-1.amazonaws.com"
    }
  }`,_time:1773861540.264,cribl_breaker:`Break on newlines`}];export{e as default};