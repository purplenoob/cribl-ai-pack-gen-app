var e=[{_time:1653057277,cribl_breaker:`Break on newlines`,_raw:`05/20/2022 09:34:37 AM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=5140\r
EventType=0\r
Type=Information\r
ComputerName=MYHOST.acme.com\r
TaskCategory=File Share\r
OpCode=Info\r
RecordNumber=1235623872\r
Keywords=Audit Success\r
Message=A network share object was accessed.\r\r
	\r\r
Subject:\r\r
	Security ID:		ACME\\SomeId$\r\r
	Account Name:		SomeName$\r\r
	Account Domain:		ACME\r\r
	Logon ID:		0x23A15F362\r\r
\r\r
Network Information:	\r\r
	Object Type:		File\r\r
	Source Address:		10.1.2.3\r\r
	Source Port:		51417\r\r
	\r\r
Share Information:\r\r
	Share Name:		\\\\*\\IPC$\r\r
	Share Path:		\r\r
\r\r
Access Request Information:\r\r
	Access Mask:		0x1\r\r
	Accesses:		ReadData (or ListDirectory)`}];export{e as default};