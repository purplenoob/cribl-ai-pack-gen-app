var e=[{_time:1655125042,cribl_breaker:`Break on newlines`,_raw:`06/13/2022 07:57:22 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=4741
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Computer Account Management
OpCode=Info
RecordNumber=110112806
Keywords=Audit Success
Message=A computer account was created.\r
\r
Subject:\r
	Security ID:		ACME\\SomeUser\r
	Account Name:		SomeUser\r
	Account Domain:		ACME\r
	Logon ID:		0x6FA974C7\r
\r
New Computer Account:\r
	Security ID:		ACME\\SomeUser$\r
	Account Name:		SomeUser$\r
	Account Domain:		ACME\r
\r
Attributes:\r
	SAM Account Name:	SomeUser$\r
	Display Name:		-\r
	User Principal Name:	-\r
	Home Directory:		-\r
	Home Drive:		-\r
	Script Path:		-\r
	Profile Path:		-\r
	User Workstations:	-\r
	Password Last Set:	<never>\r
	Account Expires:		<never>\r
	Primary Group ID:	515\r
	AllowedToDelegateTo:	-\r
	Old UAC Value:		0x0\r
	New UAC Value:		0x85\r
	User Account Control:	\r
		Account Disabled\r
		'Password Not Required' - Enabled\r
		'Workstation Trust Account' - Enabled\r
	User Parameters:	-\r
	SID History:		-\r
	Logon Hours:		<value not set>\r
	DNS Host Name:		-\r
	Service Principal Names:	-\r
\r
Additional Information:\r
	Privileges		-`}];export{e as default};