var e=[{_raw:`{
      "object": "organization.user",
      "id": "user-RaLMdpTvACy9lQrCXsBoPBAo",
      "email": "userb@afos.io",
      "name": "Mike Score",
      "role": "owner",
      "added_at": 1675873831
    }`,host:`ip-10-255-0-219`,source:`https://api.openai.com/v1/organization/users`,_time:1760634292.884,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]},{_raw:`{
      "object": "organization.user",
      "id": "user-llEuC1kgS2OVZ45pJcNULTJ7",
      "email": "userac@afos.io",
      "name": "Geddy L",
      "role": "owner",
      "added_at": 1677776210
    }`,host:`ip-10-255-0-219`,source:`https://api.openai.com/v1/organization/users`,_time:1760634292.884,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]},{_raw:`{
      "object": "organization.user",
      "id": "user-kRFLunwrISLlbwqLp9rGvyBF",
      "email": "usereel@afos.io",
      "name": "D Gilmour",
      "role": "owner",
      "added_at": 1677787153
    }`,host:`ip-10-255-0-219`,source:`https://api.openai.com/v1/organization/users`,_time:1760634292.884,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]},{_raw:`{
      "object": "organization.user",
      "id": "user-xZ7Jk0Ih5Y2bXyr51CE5EzwL",
      "email": "usernmu@afos.io",
      "name": "B May",
      "role": "owner",
      "added_at": 1679716393
    }`,host:`ip-10-255-0-219`,source:`https://api.openai.com/v1/organization/users`,_time:1760634292.884,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]},{_raw:`{
      "object": "organization.user",
      "id": "user-F8TRpLrf1TelOebXqx3BBGwG",
      "email": "useruz@afos.io",
      "name": "F Mendelssohn",
      "role": "owner",
      "added_at": 1682705509
    }`,host:`ip-10-255-0-219`,source:`https://api.openai.com/v1/organization/users`,_time:1760634292.884,cribl_breaker:[`OpenAI API Ruleset:other_logs`,`ndjson`]}];export{e as default};