var e=[{_time:1653530680,cribl_breaker:`Break on newlines`,_raw:`05/26/2022 07:34:40 AM
LogName=Security
SourceName=Microsoft Windows security auditing.
EventCode=5440
EventType=0
Type=Information
ComputerName=myhost.acme.com
TaskCategory=Filtering Platform Policy Change
OpCode=Info
RecordNumber=2202435
Keywords=Audit Success
Message=The following callout was present when the Windows Filtering Platform Base Filtering Engine started.\r
\r
Provider Information:	\r
	ID:		{00000000-0000-0000-0000-000000000000}\r
	Name:		-\r
\r
Callout Information:\r
	ID:		{C1236155-FD4E-4838-AF43-57976AC3BAD7}\r
	Name:		SomeName\r
	Type:		Persistent\r
	Run-Time ID:	305\r
\r
Layer Information:\r
	ID:		{1231D2B3-DFA4-406E-AFEB-6AFAF7E70EFD}\r
	Name:		Some Message Established v6 Layer\r
	Run-Time ID:	54`}];export{e as default};