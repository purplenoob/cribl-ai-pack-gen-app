var e=[{_time:1654578245,cribl_breaker:`Break on newlines`,_raw:`06/07/2022 10:34:05 AM
LogName=System
SourceName=HP Sensor
EventCode=1007
EventType=4
Type=Information
ComputerName=myhost.acme.com
TaskCategory=System Power
OpCode=None
RecordNumber=1542187
Keywords=Classic
Message=A fault tolerant power supply has been added to a power redundancy set. (Power Redundancy Set 1)\r
 \r
User Action \r
No action is recommended.\r
 \r
WBEM Indication Properties \r
AlertingElementFormat: 2 0x2 (CIMObjectPath)\r
AlertingManagedElement: "\\\\myhost\\root\\HPQ:HP_WinPowerRedundancySet.InstanceID="HPQ:HP_WinPowerRedundancySet:1""\r
AlertType: 5 0x5 (Device Alert)\r
Description: "A fault tolerant power supply has been added to a power redundancy set. (Power Redundancy Set 1)"\r
EventCategory: 16 0x10 (System Power)\r
EventID: "7"\r
EventTime: "20220607083405.012000+000"\r
ImpactedDomain: 4 0x4 (System)\r
IndicationIdentifier: "{648B6C2B-FA23-1231-8C56-6B5A11BC8844}"\r
IndicationTime: "20220607103351.543000+120"\r
NetworkAddresses[0]: "10.1.2.3"\r
OSType: 116 0x74 (Microsoft Windows Server 2012 R2)\r
OSVersion: "6.3.9600"\r
PerceivedSeverity: 2 0x2 (Information)\r
ProbableCause: 1 0x1 (Other)\r
ProbableCauseDescription: "Power Redundancy has been Gained"\r
ProviderName: "HP Power"\r
ProviderVersion: "10.70.0.0"\r
RecommendedActions[0]: "No action is recommended."\r
Summary: "Power redundancy gained"\r
SystemCreationClassName: "HP_WinComputerSystem"\r
SystemFirmwareVersion[0]: "2.72_03-25-2019"\r
SystemFirmwareVersion[1]: "2.56 _01-22-2018"\r
SystemGUID: "30393137-3436-5A43-4A35-123130465959"\r
SystemModel: "ProLiant DL380 Gen9"\r
SystemName: "myhost.acme.com"\r
SystemProductID: "719064-B21"\r
SystemSerialNumber: "CZJ5210FYY"\r
TIME_CREATED: 132990644450120414 0x1d87a4958e652de\r
 \r
For more information, please contact HPE Support.`}];export{e as default};