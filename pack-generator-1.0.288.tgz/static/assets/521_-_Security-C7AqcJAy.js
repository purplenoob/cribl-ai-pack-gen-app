var e=[{_time:1653682004,cribl_breaker:`Break on newlines`,_raw:`05/28/2022 01:36:44 AM\r
LogName=Security\r
SourceName=Security\r
EventCode=521\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
User=SYSTEM\r
Sid=S-1-5-18\r
SidType=1\r
TaskCategory=System Event\r
OpCode=Info\r
RecordNumber=22441534\r
Keywords=Audit Success, Classic\r
Message=Unable to log events to security log:\r\r
 	Status code:		0x0\r\r
 	Value of CrashOnAuditFail:	0\r\r
 	Number of failed audits:	102`}];export{e as default};