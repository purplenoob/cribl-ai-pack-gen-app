var e=[{_time:1653607653,cribl_breaker:`Break on newlines`,_raw:`05/27/2022 04:57:33 AM\r
LogName=Security\r
SourceName=Microsoft Windows security auditing.\r
EventCode=4661\r
EventType=0\r
Type=Information\r
ComputerName=myhost.acme.com\r
TaskCategory=Other Object Access Events\r
OpCode=Info\r
RecordNumber=1239241302\r
Keywords=Audit Success\r
Message=A handle to an object was requested.\r\r
\r\r
Subject :\r\r
	Security ID:		NT AUTHORITY\\SYSTEM\r\r
	Account Name:		MYHOST$\r\r
	Account Domain:		ACME\r\r
	Logon ID:		0x3E7\r\r
\r\r
Object:\r\r
	Object Server:	LSA\r\r
	Object Type:	TrustedDomainObject\r\r
	Object Name:	acme.com\r\r
	Handle ID:	0x123f941730\r\r
\r\r
Process Information:\r\r
	Process ID:	0x23c\r\r
	Process Name:	C:\\Windows\\System32\\lsass.exe\r\r
\r\r
Access Request Information:\r\r
	Transaction ID:	{00000000-0000-0000-0000-000000000000}\r\r
	Accesses:	DELETE\r\r
				READ_CONTROL\r\r
				WRITE_DAC\r\r
				WRITE_OWNER\r\r
				Query trusted domain name/SID\r\r
				Retrieve the controllers in the trusted domain\r\r
				Change the controllers in the trusted domain\r\r
				Query the Posix ID offset assigned to the trusted domain\r\r
				Change the Posix ID offset assigned to the trusted domain\r\r
				Undefined Access (no effect) Bit 5\r\r
				Undefined Access (no effect) Bit 6\r\r
				Undefined Access (no effect) Bit 7\r\r
				Undefined Access (no effect) Bit 8\r\r
				\r\r
	Access Reasons:		-\r\r
	Access Mask:	0xF01FF\r\r
	Privileges Used for Access Check:	-\r\r
	Properties:	---\r\r
	{bf967ab8-0de6-11d0-a285-00aa003049e2}\r\r
DELETE\r\r
READ_CONTROL\r\r
WRITE_DAC\r\r
WRITE_OWNER\r\r
Query trusted domain name/SID\r\r
Retrieve the controllers in the trusted domain\r\r
Change the controllers in the trusted domain\r\r
Query the Posix ID offset assigned to the trusted domain\r\r
Change the Posix ID offset assigned to the trusted domain\r\r
Undefined Access (no effect) Bit 5\r\r
Undefined Access (no effect) Bit 6\r\r
Undefined Access (no effect) Bit 7\r\r
Undefined Access (no effect) Bit 8\r\r
		{4886566c-af31-11d2-b7df-00805f48caeb}\r\r
			{b7b13117-b82e-11d0-afee-0000f80367c1}\r\r
			{bf967a2f-0de6-11d0-a285-00aa003049e2}\r\r
			{80a67e5a-9f22-11d0-afdd-00c04fd930c9}\r\r
			{bf967a5c-0de6-11d0-a285-00aa003049e2}\r\r
			{bf967a5d-0de6-11d0-a285-00aa003049e2}\r\r
			{bf967a60-0de6-11d0-a285-00aa003049e2}\r\r
		{736e4812-af31-11d2-b7df-00805f48caeb}\r\r
			{52458023-ca6a-11d0-afff-0000f80367c1}\r\r
			{52458024-ca6a-11d0-afff-0000f80367c1}\r\r
			{bf967a59-0de6-11d0-a285-00aa003049e2}\r\r
			{bf967a5f-0de6-11d0-a285-00aa003049e2}\r\r
		{9567ca92-af31-11d2-b7df-00805f48caeb}\r\r
			{bf967a5e-0de6-11d0-a285-00aa003049e2}\r\r
\r\r
	Restricted SID Count:	0`}];export{e as default};