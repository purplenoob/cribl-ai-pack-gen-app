var e=[{_time:1653679824,cribl_breaker:`Break on newlines`,_raw:`05/28/2022 01:00:24 AM
LogName=System
SourceName=Microsoft Antimalware
EventCode=5007
EventType=4
Type=Information
ComputerName=myhost.acme.com
TaskCategory=None
OpCode=Info
RecordNumber=642796
Keywords=Classic
Message=Microsoft Antimalware Configuration has changed. If this is an unexpected event you should review the settings as this may be the result of malware.\r
 	Old value: \r
 	New value: HKLM\\SOFTWARE\\Microsoft\\Microsoft Antimalware\\MpEngine\\MpCampRing = 0x4`}];export{e as default};