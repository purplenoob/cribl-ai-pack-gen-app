var e=[{_time:1659604502,cribl_breaker:`Break on newlines`,_raw:`08/04/2022 02:45:02 PM
LogName=Security
EventCode=4726
EventType=0
ComputerName=myhost.acme.com
SourceName=Microsoft Windows security auditing.
Type=Information
RecordNumber=1980145950
Keywords=Audit Success
TaskCategory=User Account Management
OpCode=Info
Message=A user account was deleted.\r
\r
Subject:\r
	Security ID:		ACME\\SomeId\r
	Account Name:		SomeName\r
	Account Domain:		ACME\r
	Logon ID:		0xF83F0079\r
\r
Target Account:\r
	Security ID:		S-1-5-21-2184843080-1234357790-3623606500-403642\r
	Account Name:		12386246\r
	Account Domain:		ACME\r
\r
Additional Information:\r
	Privileges	-`}];export{e as default};