# Cribl Pipeline Visualizer

A Cribl App that opens an existing pipeline (in a pack or directly in a worker group) in an editor that looks and works like Cribl's own, and adds one thing Cribl lacks: a **before and after preview for each function**. Click any function to see the events just before it (IN) and just after it (OUT), with the changes highlighted. Then step through the pipeline one function at a time with ◀ ▶.

It is useful for demoing what a single function does, and for finding the function that breaks your data.

## Features

- **Pick a pipeline.** Under **Source**, choose **Packs** (the default) for Worker Group → Pack → Pipeline, or **Pipelines** for the worker group's own pipelines. Only Stream groups are listed.
- **Pipelines overview.** Once a pack (or worker group) is chosen, its pipelines are listed as on Cribl's Pipelines page: Route / Source, f(x), Destination, Description and the In / Out / Err event counts of the last 15 minutes. Filter the list, then click a pipeline to open it. **← Pipelines** (or the browser's Back button) returns to the list, so you can work through a pack one pipeline at a time.
- **Links into the app.** The current place is kept in the URL, so you can bookmark or share it, and other tools can link straight to a pack or a pipeline (see [Deep links](#deep-links)).
- **Edit it like in Cribl.** You get:
  - Numbered function list, comment rows, enable toggles, Final marker and Filter column.
  - Drag to reorder, plus Insert / Copy / Disable / Delete from the ⋯ menu.
  - Add Function ▾ and a { } JSON view.
- **Function settings forms.** These are generated from each function's schema, so they match Cribl's own forms. That includes the Parser library picker, Code editor and Advanced sections.
- **Preview.** The right pane has:
  - Sample data file picker and Run button. Picking another function, or switching between one function and the whole pipeline, runs the preview straight away.
  - **Before & after one function** (the default): IN │ OUT side by side, highlighted diff (added / removed / changed / dropped) and per-function stats.
  - **Whole pipeline**: Cribl's Simple Preview, with field and byte % stats.
- **Draggable splitter** between the editor and the preview. Double-click it to reset.
- **Save / Cancel** at the bottom of the editor. Your edits stay in the app until you press Save. Save writes the pipeline to the pack, but nothing is committed or deployed. Commit and deploy from Cribl when you are ready.

### How preview works

Cribl's preview API only runs saved pipelines. So when you press Run, the app writes your edits to a scratch pipeline called `ppc_scratch_preview` in the same pack (or worker group, for a group pipeline), and previews that. The real pipeline isn't touched until you press Save. You can remove the scratch pipeline from the preview pane. If you don't, the next Run reuses it.

## Install (for colleagues)

You need a Cribl Cloud workspace (or a Leader) on version 4.19 or later, with App Platform enabled.

1. Download `cribl-pipeline-visualizer-<version>.tgz` from the [latest release](https://github.com/wvdlinde-cribl/cribl-pipeline-visualizer/releases/latest).
2. In Cribl, open **Apps → Add App → Import from File** and select the `.tgz`.
3. Review the API permissions it asks for (listed below) and install.
4. Grant access under **Apps → Cribl Pipeline Visualizer → Settings → Members & Teams**.
5. Open the app, pick a worker group and pack, click a pipeline, choose a sample file and press **Run**.

To upgrade, import a newer `.tgz` the same way.

### Deep links

Open the app at a specific pack or pipeline by adding a path to its URL. The paths follow Cribl's own URLs:

| Link | Opens |
|---|---|
| `/apps/a/cribl-pipeline-visualizer/groups/<group>/packs/<pack>` | The pipelines overview of a pack |
| `/apps/a/cribl-pipeline-visualizer/groups/<group>/packs/<pack>/pipelines/<pipeline>` | That pipeline in the pack |
| `/apps/a/cribl-pipeline-visualizer/groups/<group>/pipelines` | The worker group's own pipelines |
| `/apps/a/cribl-pipeline-visualizer/groups/<group>/pipelines/<pipeline>` | One of the worker group's own pipelines |

Pack ids are matched case-insensitively. From another Cribl App, open the link with `<a href="/apps/a/cribl-pipeline-visualizer/groups/…" target="_blank">`. Pressing the browser's Back button in a pipeline returns to the overview. The place is kept in the path, not the query string, because Cribl passes only the path to the app when the user goes Back. The older `?group=<group>&pack=<pack>&pipeline=<pipeline>` links still work and are rewritten to the path form.

### Permissions it asks for

These are declared in [config/policies.yml](config/policies.yml):

| API | Why |
|---|---|
| `GET /master/groups`, `GET /m/*/packs` | Worker group and pack pickers |
| `GET/POST /m/*/p/*/pipelines`, `GET/PATCH/DELETE /m/*/p/*/pipelines/*` | Open and save the pipeline. Create and remove the scratch pipeline |
| `GET /m/*/p/*/functions`, `GET /m/*/p/*/lib/parsers` | Function catalogue, schemas and the Parser library |
| `GET /m/*/p/*/lib/breakers`, `/m/*/p/*/system/lookups`, `/m/*/system/certificates`, `/timezoneInfo` | Dropdown choices in function settings (read-only) |
| `GET /m/*/system/samples…`, `GET /m/*/p/*/system/samples…` | Sample data files (group and pack) |
| The same paths without `/p/*` (`/m/*/pipelines…`, `/m/*/functions`, `/m/*/preview`, …) | The worker group's own pipelines, when **Source** is **Pipelines** |
| `POST /m/*/p/*/preview` | Run the preview |
| `GET /m/*/p/*/routes`, `GET /m/*/p/*/system/inputs` (and without `/p/*`) | Route / Source and Destination columns of the pipelines overview (read-only) |
| `POST /system/metrics/query` | In / Out / Err counts of the overview (read-only query) |

The app makes no external calls and stores nothing in the browser.

## Development

Requirements: Node 20+ and npm.

```bash
npm install
cp local.env.example local.env   # fill in your workspace URL and an API client ID/secret
npm run dev:standalone           # http://127.0.0.1:5190
```

In standalone mode, a Vite plugin ([scripts/standalone-plugin.mjs](scripts/standalone-plugin.mjs)) proxies API calls to your workspace. It uses the OAuth client in `local.env`, which never leaves your machine and is git-ignored.

| Script | What it does |
|---|---|
| `npm run dev:standalone` | Dev server against the workspace in `local.env` |
| `npm test` | Unit tests (schema form logic, pipeline and overview helpers, deep links) |
| `npm run lint` | ESLint |
| `npm run package` | Type-check, build and write `build/cribl-pipeline-visualizer-<version>.tgz`. Bumps the patch version (`-- --minor`, `-- --major`, `-- --version X.Y.Z`) |
| `npm run deploy` | Upload that `.tgz` to the workspace in `local.env`. Installs it, or upgrades it in place |

The code lives in `src/`:

- [src/App.tsx](src/App.tsx): layout, pickers, save and preview orchestration.
- [src/components/](src/components/): pipelines overview, function list, settings forms, preview pane.
- [src/lib/](src/lib/): API client, schema → form logic, pipeline and overview helpers, URL state.

App Platform conventions are documented in [AGENTS.md](AGENTS.md). The requirements are in [APP_DEFINITION.md](APP_DEFINITION.md) and [APP_BRIEF.md](APP_BRIEF.md).

## Limitations

- The app opens existing pipelines only; it doesn't create new ones.
- Save doesn't commit or deploy.
- Preview needs at least one sample file in the worker group.
