var e=[{_raw:`{
      "time": "2023-03-06T22:00:00.0000000Z",
      "systemId": "a0fca5ce-022c-47b1-9735-89943b42f2fa",
      "category": "NetworkSecurityGroupFlowEvent",
      "resourceId": "/SUBSCRIPTIONS/00000000-0000-0000-0000-000000000000/RESOURCEGROUPS/FABRIKAMRG/PROVIDERS/MICROSOFT.NETWORK/NETWORKSECURITYGROUPS/FABRIAKMVM1-NSG",
      "operationName": "NetworkSecurityGroupFlowEvents",
      "properties": {
        "Version": 2,
        "flows": [
          {
            "rule": "DefaultRule_DenyAllInBound",
            "flows": [
              {
                "mac": "000D3AF87856",
                "flowTuples": [
                  "1542110402,94.102.49.190,10.5.16.4,28746,443,U,I,D,B,,,,",
                  "1542110424,176.119.4.10,10.5.16.4,56509,59336,T,I,D,B,,,,",
                  "1542110432,167.99.86.8,10.5.16.4,48495,8088,T,I,D,B,,,,"
                ]
              }
            ]
          },
          {
            "rule": "DefaultRule_AllowInternetOutBound",
            "flows": [
              {
                "mac": "000D3AF87856",
                "flowTuples": [
                  "1542110377,10.5.16.4,13.67.143.118,59831,443,T,O,A,B,,,,",
                  "1542110379,10.5.16.4,13.67.143.117,59932,443,T,O,A,E,1,66,1,66",
                  "1542110379,10.5.16.4,13.67.143.115,44931,443,T,O,A,C,30,16978,24,14008",
                  "1542110406,10.5.16.4,40.71.12.225,59929,443,T,O,A,E,15,8489,12,7054"
                ]
              }
            ]
          }
        ]
      }
    }`,_time:167814e4},{_raw:`{
      "time": "2023-03-06T22:00:00.0000000Z",
      "systemId": "a0fca5ce-022c-47b1-9735-89943b42f2fa",
      "category": "NetworkSecurityGroupFlowEvent",
      "resourceId": "/SUBSCRIPTIONS/00000000-0000-0000-0000-000000000000/RESOURCEGROUPS/FABRIKAMRG/PROVIDERS/MICROSOFT.NETWORK/NETWORKSECURITYGROUPS/FABRIAKMVM1-NSG",
      "operationName": "NetworkSecurityGroupFlowEvents",
      "properties": {
        "Version": 2,
        "flows": [
          {
            "rule": "DefaultRule_DenyAllInBound",
            "flows": [
              {
                "mac": "000D3AF87856",
                "flowTuples": [
                  "1542110437,125.64.94.197,10.5.16.4,59752,18264,T,I,D,B,,,,",
                  "1542110475,80.211.72.221,10.5.16.4,37433,8088,T,I,D,B,,,,",
                  "1542110487,46.101.199.124,10.5.16.4,60577,8088,T,I,D,B,,,,",
                  "1542110490,176.119.4.30,10.5.16.4,57067,52801,T,I,D,B,,,,"
                ]
              }
            ]
          }
        ]
      }
    }`,_time:167814e4}];export{e as default};