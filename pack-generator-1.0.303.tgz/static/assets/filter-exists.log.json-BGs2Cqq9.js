var e=[{_raw:`{
    "name": "Cory Henry",
    "firstName": "Cory",
    "lastName": "Henry",
    "displayName": "Cory Henry",
    "id": "026bb65ed1f54fcd89197ca986e9acac",
    "email": "Cory.Henry@sailpointdemo.com",
    "created": "2024-04-04T21:32:46.844Z",
    "inactive": false,
    "protected": false,
    "status": "UNREGISTERED",
    "employeeNumber": "10090",
    "manager": {
      "id": "903349b85746471a9a898722206109bb",
      "name": "Layla Hendricks",
      "displayName": "Layla Hendricks"
    },
    "isManager": true,
    "identityProfile": {
      "id": "00a2bc6244b34f4a88d985f035f2b68b",
      "name": "HR Global"
    },
    "source": {
      "id": "524f8d986f9b4192865269516d169eb0",
      "name": "HR Global"
    },
    "attributes": {
      "city": "Austin",
      "cloudAuthoritativeSource": "524f8d986f9b4192865269516d169eb0",
      "cloudLifecycleState": "active",
      "cloudStatus": "UNREGISTERED",
      "country": "US",
      "department": "Revenue Operations",
      "displayName": "Cory Henry",
      "email": "Cory.Henry@sailpointdemo.com",
      "firstname": "Cory",
      "identificationNumber": "10090",
      "identityState": "ACTIVE",
      "internalCloudStatus": "UNREGISTERED",
      "jobTitle": "Manager,  System Operations",
      "lastname": "Henry",
      "location": "AMS",
      "uid": "10090",
      "visibleSegments": [
        "d75ae486-044b-4eba-8113-0cdacb5341df",
        "8ea4e957-f2f1-4cba-b202-54cc702528d1"
      ]
    },
    "disabled": false,
    "locked": false,
    "accounts": [
      {
        "id": "a02142f41ad1407884da04a7bfa586d4",
        "name": "Cory Henry",
        "accountId": "10090",
        "source": {
          "id": "524f8d986f9b4192865269516d169eb0",
          "name": "HR Global",
          "type": "DelimitedFile"
        },
        "disabled": false,
        "locked": false,
        "privileged": false,
        "manuallyCorrelated": false,
        "entitlementAttributes": {},
        "created": "2024-04-04T21:32:46.844Z",
        "supportsPasswordChange": false
      },
      {
        "id": "f30019e125c74684acee7da3f1643d2a",
        "name": "$LUJ300-P3QNVHE6R7FB",
        "accountId": "CN=Cory Henry,OU=Demo,DC=seri,DC=sailpointdemo,DC=com",
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory",
          "type": "Active Directory - Direct"
        },
        "disabled": false,
        "locked": false,
        "privileged": false,
        "manuallyCorrelated": true,
        "passwordLastSet": "2024-04-04T21:33:34.488Z",
        "entitlementAttributes": {
          "memberOf": [
            "CN=Benefits,OU=Groups,OU=Demo,DC=seri,DC=sailpointdemo,DC=com"
          ]
        },
        "created": "2024-04-04T21:37:03.481Z",
        "supportsPasswordChange": true
      },
      {
        "id": "7fe340119c5d4b00a9b85d55b18a6416",
        "name": "Cory Henry",
        "accountId": "Cory Henry",
        "source": {
          "id": "af4686d6482841ac96d793901372ad9b",
          "name": "IdentityNow",
          "type": "IdentityNowConnector"
        },
        "disabled": false,
        "locked": false,
        "privileged": false,
        "manuallyCorrelated": false,
        "entitlementAttributes": {},
        "created": "2024-04-04T21:37:03.536Z",
        "supportsPasswordChange": true,
        "accountAttributes": {}
      }
    ],
    "accountCount": 2,
    "apps": [
      {
        "id": "20003",
        "name": "Active Directory",
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory"
        },
        "account": {
          "id": "f30019e125c74684acee7da3f1643d2a",
          "accountId": "CN=Cory Henry,OU=Demo,DC=seri,DC=sailpointdemo,DC=com"
        }
      },
      {
        "id": "20013",
        "name": "AD test",
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory"
        },
        "account": {
          "id": "f30019e125c74684acee7da3f1643d2a",
          "accountId": "CN=Cory Henry,OU=Demo,DC=seri,DC=sailpointdemo,DC=com"
        }
      },
      {
        "id": "20014",
        "name": "Test AD",
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory"
        },
        "account": {
          "id": "f30019e125c74684acee7da3f1643d2a",
          "accountId": "CN=Cory Henry,OU=Demo,DC=seri,DC=sailpointdemo,DC=com"
        }
      },
      {
        "id": "5092",
        "name": "Accounting",
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory"
        },
        "account": {
          "id": "f30019e125c74684acee7da3f1643d2a",
          "accountId": "CN=Cory Henry,OU=Demo,DC=seri,DC=sailpointdemo,DC=com"
        }
      },
      {
        "id": "5822114389092541705",
        "name": "IdentityNow app",
        "source": {
          "id": "af4686d6482841ac96d793901372ad9b",
          "name": "IdentityNow"
        },
        "account": {
          "id": "7fe340119c5d4b00a9b85d55b18a6416",
          "accountId": "Cory Henry"
        }
      }
    ],
    "appCount": 5,
    "access": [
      {
        "id": "ad7025c956734455b28fa35e315e77fe",
        "name": "Benefits Common Access",
        "displayName": "Benefits Common Access",
        "type": "ROLE",
        "description": "Testing AD provisioning with birthright access",
        "enabled": false,
        "requestable": false,
        "requestCommentsRequired": false,
        "owner": {
          "id": "322c6bce405a495a8e841a014b7d8410",
          "name": "tina.smith",
          "displayName": "tina.smith"
        },
        "disabled": false,
        "privileged": false,
        "standalone": false,
        "revocable": false,
        "cloudEligible": false,
        "cloudGoverned": false
      },
      {
        "id": "7e277d102c874560becc464cdfe33a86",
        "name": "Benefits Employees",
        "displayName": "Benefits Employees",
        "type": "ACCESS_PROFILE",
        "description": "Access for Benefits Employees. Distribution group and File share access.",
        "enabled": false,
        "requestable": false,
        "requestCommentsRequired": false,
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory"
        },
        "owner": {
          "id": "278f8a1859df48d2a0adb204257b26a2",
          "name": "Jerry.Bennett",
          "displayName": "Jerry.Bennett"
        },
        "disabled": false,
        "privileged": false,
        "standalone": false,
        "revocable": false,
        "cloudEligible": false,
        "cloudGoverned": false
      },
      {
        "id": "4919721c3c1a4ca484469b85f0fd9ba1",
        "name": "Benefits",
        "displayName": "Benefits",
        "type": "ENTITLEMENT",
        "enabled": false,
        "requestable": false,
        "requestCommentsRequired": false,
        "source": {
          "id": "5c71ff71195b4794a0b87e7cf36fb017",
          "name": "Active Directory"
        },
        "disabled": false,
        "privileged": false,
        "attribute": "memberOf",
        "value": "CN=Benefits,OU=Groups,OU=Demo,DC=seri,DC=sailpointdemo,DC=com",
        "standalone": false,
        "cloudEligible": false,
        "cloudGoverned": false,
        "schema": "group"
      }
    ],
    "accessCount": 3,
    "accessProfileCount": 1,
    "entitlementCount": 1,
    "roleCount": 1,
    "modified": "2024-12-13T02:49:19.214Z",
    "visibleSegments": [
      "All Employees",
      "Austin Employees"
    ],
    "visibleSegmentCount": 2,
    "tagCount": 0,
    "pod": "pod01-useast1",
    "org": "org-name",
    "synced": "2024-12-13T06:10:29.734Z",
    "_type": "identity",
    "type": "identity",
    "_version": "v2"
  }`,_time:1760745064.058,cribl_breaker:[`Break on newlines`,`ndjson`]}];export{e as default};